var K=Object.defineProperty;var b=(o,e)=>{for(var t in e)K(o,t,{get:e[t],enumerable:!0})};var M={};b(M,{DEFAULT_VIEW:()=>H,NodeConnectionsPanel:()=>D,NodeConnectionsView:()=>h});import"../../../ui/components/lists/lists.js";import"../../../ui/kit/kit.js";import*as c from"../../../core/host/host.js";import*as T from"../../../core/i18n/i18n.js";import*as S from"../../../ui/components/buttons/buttons.js";import*as m from"../../../ui/legacy/legacy.js";import{html as g,i18nTemplate as L,render as P}from"../../../ui/lit/lit.js";var C=`.add-network-target-button{margin:10px 25px;align-self:center}.network-discovery-list{flex:none;max-width:600px;max-height:202px;margin:var(--sys-size-9) 0 5px}.network-discovery-list-empty{flex:auto;height:30px;display:flex;align-items:center;justify-content:center}.network-discovery-list-item{padding:3px 5px;height:30px;display:flex;align-items:center;position:relative;flex:auto 1 1}.network-discovery-value{flex:3 1 0}.list-item .network-discovery-value{white-space:nowrap;text-overflow:ellipsis;user-select:none;color:var(--sys-color-on-surface);overflow:hidden}.network-discovery-footer{margin:0;overflow:hidden;max-width:500px;padding:3px}.network-discovery-footer > *{white-space:pre-wrap}.node-panel{align-items:center;justify-content:flex-start;overflow-y:auto}.network-discovery-view{min-width:400px;text-align:left}:host-context(.node-frontend) .network-discovery-list-empty{height:var(--sys-size-14)}:host-context(.node-frontend) .network-discovery-list-item{padding:3px 15px;height:var(--sys-size-14)}.node-panel-center{max-width:600px;padding-top:50px;text-align:center}.node-panel-logo{width:400px;margin-bottom:50px}
/*# sourceURL=${import.meta.resolve("./nodeConnectionsPanel.css")} */`;var{widget:N}=m.Widget,d={nodejsDebuggingGuide:"Node.js debugging guide",specifyNetworkEndpointAnd:"Specify network endpoint and DevTools will connect to it automatically. Read {PH1} to learn more.",noConnectionsSpecified:"No connections specified",addConnection:"Add connection",networkAddressEgLocalhost:"Network address (e.g. localhost:9229)"},A=T.i18n.registerUIStrings("entrypoints/node_app/app/NodeConnectionsPanel.ts",d),p=T.i18n.getLocalizedString.bind(void 0,A),j=new URL("../../../Images/node-stack-icon.svg",import.meta.url).toString(),_=(o,e,t)=>{P(g`
    <style>${C}</style>
    <div class="node-panel vbox flex-auto" tabindex="0" autofocus>
      <div class="node-panel-center">
        <img class="node-panel-logo" src=${j} alt="">
        ${N(h,{discoveryConfig:o.discoveryConfig,callback:o.onDiscoveryConfigChanged})}
      </div>
    </div>
  `,t)},D=class extends m.Panel.Panel{#o;#t;constructor(e=_){super("node-connection"),this.#t=e,c.InspectorFrontendHost.InspectorFrontendHostInstance.events.addEventListener(c.InspectorFrontendHostAPI.Events.DevicesDiscoveryConfigChanged,this.#n,this),c.InspectorFrontendHost.InspectorFrontendHostInstance.setDevicesUpdatesEnabled(!1),c.InspectorFrontendHost.InspectorFrontendHostInstance.setDevicesUpdatesEnabled(!0),this.performUpdate()}performUpdate(){this.#t({discoveryConfig:this.#o?.networkDiscoveryConfig??[],onDiscoveryConfigChanged:this.#e},void 0,this.contentElement)}#e=e=>{this.#o&&(this.#o.networkDiscoveryConfig=e,c.InspectorFrontendHost.InspectorFrontendHostInstance.setDevicesDiscoveryConfig(this.#o))};#n({data:e}){this.#o=e,this.requestUpdate()}},H=(o,e,t)=>{let n=g`
    <devtools-link href="https://nodejs.org/learn/getting-started/debugging"
                   jslogcontext="node-js-debugging">
      ${p(d.nodejsDebuggingGuide)}
    </devtools-link>`,s=o.editingIndex===o.connections.length?[...o.connections,""]:o.connections;P(g`
    <style>${C}</style>
    <div class="vbox network-discovery-view node-frontend">
      <div class="network-discovery-footer">
        ${L(A,d.specifyNetworkEndpointAnd,{PH1:n})}
      </div>
      ${s.length===0?g`
        <div class="network-discovery-list-empty">${p(d.noConnectionsSpecified)}</div>
      `:g`
        <devtools-list
          class="network-discovery-list"
          .editable=${!0}
          .deletable=${!0}
          @edit=${i=>o.onBeginEdit(i.detail.index)}
          @delete=${i=>o.onDelete(i.detail.index)}>
          ${s.map((i,v)=>{let w=o.editingIndex===v;return g`
              <div slot="slot-${v}" class="network-discovery-list-item">
                <devtools-prompt
                  class="network-discovery-value network-discovery-address"
                  placeholder=${p(d.networkAddressEgLocalhost)}
                  value=${i}
                  ?editing=${w}
                  .validator=${o.validator}
                  @click=${l=>{w||(o.onBeginEdit(v),l.consume(!0))}}
                  @keydown=${l=>{!w&&l.key==="Enter"&&(o.onBeginEdit(v),l.consume(!0))}}
                  @commit=${l=>o.onCommitEdit(v,l.detail)}
                  @cancel=${o.onCancelEdit}>
                  ${i}
                </devtools-prompt>
              </div>
            `})}
        </devtools-list>
      `}
      <devtools-button
          class="add-network-target-button"
          .variant=${S.Button.Variant.PRIMARY}
          .jslogContext=${"add-network-target"}
          @click=${o.onAddClick}>
        ${p(d.addConnection)}
      </devtools-button>
    </div>
  `,t)},h=class o extends m.Widget.VBox{#o;#t=[];#e=null;#n;constructor(e,t=H){super(e),this.#n=t,this.performUpdate()}static validateAddress(e){let t=e.trim().match(/^([a-zA-Z0-9\.\-_]+):(\d+)$/);return t&&parseInt(t[2],10)<=65535?null:p(d.networkAddressEgLocalhost)}set callback(e){this.#o=e}set discoveryConfig(e){this.discoveryConfigChanged(e)}performUpdate(){this.#n({connections:this.#t,editingIndex:this.#e,onAddClick:this.#s.bind(this),onBeginEdit:this.#r.bind(this),onCommitEdit:this.#a.bind(this),onCancelEdit:this.#d.bind(this),onDelete:this.#c.bind(this),validator:o.validateAddress},void 0,this.element)}#i(){this.#o?.call(null,[...this.#t])}#s(){this.#e=this.#t.length,this.requestUpdate()}#r(e){this.#e=e,this.requestUpdate()}#a(e,t){let n=t.trim();e===this.#t.length?this.#t.push(n):e>=0&&e<this.#t.length&&(this.#t[e]=n),this.#e=null,this.requestUpdate(),this.#i()}#d(){this.#e=null,this.requestUpdate()}#c(e){this.#t.splice(e,1),this.#e!==null&&(this.#e===e?this.#e=null:this.#e>e&&this.#e--),this.requestUpdate(),this.#i()}discoveryConfigChanged(e){this.#t=[...e],this.#e=null,this.requestUpdate()}};var $={};b($,{NodeChildTargetManager:()=>f,NodeConnection:()=>y,NodeMainImpl:()=>E});import*as a from"../../../core/host/host.js";import*as I from"../../../core/i18n/i18n.js";import*as U from"../../../core/protocol_client/protocol_client.js";import*as r from"../../../core/sdk/sdk.js";import*as F from"../../../ui/legacy/components/utils/utils.js";var u={main:"Main",nodejsS:"Node.js: {PH1}",NodejsTitleS:"DevTools - Node.js: {PH1}"},R=I.i18n.registerUIStrings("entrypoints/node_app/app/NodeMain.ts",u),x=I.i18n.getLocalizedString.bind(void 0,R),k,E=class o{static instance(e={forceNew:null}){let{forceNew:t}=e;return(!k||t)&&(k=new o),k}async run(){a.userMetrics.actionTaken(a.UserMetrics.Action.ConnectToNodeJSFromFrontend),r.Connections.initMainConnection(async()=>{r.TargetManager.TargetManager.instance().createTarget("main",x(u.main),r.Target.Type.BROWSER,null).setInspectedURL("Node.js")},F.TargetDetachedDialog.TargetDetachedDialog.connectionLost)}},f=class extends r.SDKModel.SDKModel{#o;#t;#e;#n=new Map;#i=new Map;constructor(e){super(e),this.#o=e.targetManager(),this.#t=e,this.#e=e.targetAgent(),e.registerTargetDispatcher(this),this.#e.invoke_setDiscoverTargets({discover:!0}),a.InspectorFrontendHost.InspectorFrontendHostInstance.events.addEventListener(a.InspectorFrontendHostAPI.Events.DevicesDiscoveryConfigChanged,this.#s,this),a.InspectorFrontendHost.InspectorFrontendHostInstance.setDevicesUpdatesEnabled(!1),a.InspectorFrontendHost.InspectorFrontendHostInstance.setDevicesUpdatesEnabled(!0)}#s({data:e}){let t=[];for(let n of e.networkDiscoveryConfig){let s=n.split(":"),i=parseInt(s[1],10);s[0]&&i&&t.push({host:s[0],port:i})}this.#e.invoke_setRemoteLocations({locations:t})}dispose(){a.InspectorFrontendHost.InspectorFrontendHostInstance.events.removeEventListener(a.InspectorFrontendHostAPI.Events.DevicesDiscoveryConfigChanged,this.#s,this);for(let e of this.#n.keys())this.detachedFromTarget({sessionId:e})}targetCreated({targetInfo:e}){e.type==="node"&&!e.attached?this.#e.invoke_attachToTarget({targetId:e.targetId,flatten:!1}):e.type==="node_worker"&&this.#e.invoke_setAutoAttach({autoAttach:!0,waitForDebuggerOnStart:!1})}async attachedToTarget({sessionId:e,targetInfo:t}){let n;if(t.type==="node_worker")n=this.#o.createTarget(t.targetId,t.title,r.Target.Type.NODE_WORKER,this.#t,e,!0,void 0,t);else{let s=x(u.nodejsS,{PH1:t.url});document.title=x(u.NodejsTitleS,{PH1:t.url});let i=new y(this.#e,e);this.#i.set(e,i),n=this.#o.createTarget(t.targetId,s,r.Target.Type.NODE,null,void 0,void 0,new U.DevToolsCDPConnection.DevToolsCDPConnection(i))}this.#n.set(e,n),n.runtimeAgent().invoke_runIfWaitingForDebugger(),await this.#r(n)}async#r(e){let n=await e.storageAgent().invoke_getStorageKey({}),s=n.storageKey;if(n.getError()||!s){console.error(`Failed to get storage key for target ${e.id()}: ${n.getError()}`);return}let i=e.model(r.StorageKeyManager.StorageKeyManager);i&&(i.setMainStorageKey(s),i.updateStorageKeys(new Set([s])))}detachedFromTarget({sessionId:e}){let t=this.#n.get(e);t&&t.dispose("target terminated"),this.#n.delete(e),this.#i.delete(e)}receivedMessageFromTarget({sessionId:e,message:t}){let n=this.#i.get(e),s=n?n.onMessage:null;s&&s.call(null,t)}},y=class{#o;#t;onMessage;#e;constructor(e,t){this.#o=e,this.#t=t,this.onMessage=null,this.#e=null}setOnMessage(e){this.onMessage=e}setOnDisconnect(e){this.#e=e}sendRawMessage(e){this.#o.invoke_sendMessageToTarget({message:e,sessionId:this.#t})}async disconnect(){this.#e&&this.#e.call(null,"force disconnect"),this.#e=null,this.onMessage=null,await this.#o.invoke_detachFromTarget({sessionId:this.#t})}};r.SDKModel.SDKModel.register(f,{capabilities:r.Target.Capability.TARGET,autostart:!0});export{M as NodeConnectionsPanel,$ as NodeMain};
//# sourceMappingURL=app.js.map
