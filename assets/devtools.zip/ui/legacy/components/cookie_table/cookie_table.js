var x=Object.defineProperty;var w=(n,e)=>{for(var s in e)x(n,s,{get:e[s],enumerable:!0})};var $={};w($,{CookiesTable:()=>A,DEFAULT_VIEW:()=>y});import"../data_grid/data_grid.js";import"../../../components/buttons/buttons.js";import"../../../kit/kit.js";import*as k from"../../../../core/common/common.js";import*as S from"../../../../core/i18n/i18n.js";import*as v from"../../../../core/root/root.js";import*as t from"../../../../core/sdk/sdk.js";import*as b from"../../../../models/issues_manager/issues_manager.js";import*as g from"../../../../panels/network/forward/forward.js";import{Directives as B,html as C,nothing as h,render as M}from"../../../lit/lit.js";import*as I from"../../legacy.js";var f=`.data-grid-data-grid-node .ai-button-container{display:none;float:right;devtools-floating-button{position:absolute;z-index:999;margin-left:-17px}}.data-grid-data-grid-node:hover .ai-button-container{display:inline-flex}
/*# sourceURL=${import.meta.resolve("./dataGridAiButton.css")} */`;var K=`devtools-data-grid{flex:auto}.cookies-table devtools-icon{margin-right:var(--sys-size-3)}
/*# sourceURL=${import.meta.resolve("./cookiesTable.css")} */`;var{repeat:P,ifDefined:m}=B,r={session:"Session",name:"Name",value:"Value",size:"Size",domain:"Domain",path:"Path",secure:"Secure",partitionKeySite:"Partition key site",priority:"Priority",editableCookies:"Editable cookies",cookies:"Cookies",na:"N/A",showRequestsWithThisCookie:"Show requests with this cookie",showIssueAssociatedWithThis:"Show issue associated with this cookie",sourcePortTooltip:"Shows the source port (range 1-65535) the cookie was set on. If the port is unknown, this shows -1.",sourceSchemeTooltip:"Shows the source scheme (`Secure`, `NonSecure`) the cookie was set on. If the scheme is unknown, this shows `Unset`.",timeAfter:"after {date}",timeAfterTooltip:"The expiration timestamp is {seconds}, which corresponds to a date after {date}",opaquePartitionKey:"(opaque)",httpOnlyCookiesCannotBeAdded:"HttpOnly cookies can\u2019t be added as context"},R=S.i18n.registerUIStrings("ui/legacy/components/cookie_table/CookiesTable.ts",r),l=S.i18n.getLocalizedString.bind(void 0,R),U=S.i18n.getLazilyComputedLocalizedString.bind(void 0,R),p=U(r.session);function T(n){return n===t.Cookie.Attribute.HTTP_ONLY||n===t.Cookie.Attribute.SECURE}function D(n){return n===void 0?h:C`<devtools-icon name="info" class="small" title=${n}></devtools-icon>`}var y=(n,e,s)=>{M(C`
    <style>${K}</style>
    <devtools-data-grid
         name=${n.editable?l(r.editableCookies):l(r.cookies)}
         id="cookies-table"
         striped
         ?inline=${n.renderInline}
         ?deletable=${n.deletable}
         @create=${i=>n.onCreate(i.detail)}
         @refresh=${n.onRefresh}
         @deselect=${()=>n.onSelect(void 0)}
    >
      <table>
        ${n.showAiButton?C`<style>${f}</style>`:h}
         <tr>
           <th id=${t.Cookie.Attribute.NAME} sortable ?disclosure=${n.editable} ?editable=${n.editable} long weight="24">
             ${l(r.name)}
           </th>
           <th id=${t.Cookie.Attribute.VALUE} sortable ?editable=${n.editable} long weight="34">
             ${l(r.value)}
           </th>
           <th id=${t.Cookie.Attribute.DOMAIN} sortable weight="7" ?editable=${n.editable}>
             ${l(r.domain)}
           </th>
           <th id=${t.Cookie.Attribute.PATH} sortable weight="7" ?editable=${n.editable}>
             ${l(r.path)}
           </th>
           <th id=${t.Cookie.Attribute.EXPIRES} sortable weight="7" ?editable=${n.editable}>
             Expires / Max-Age
           </th>
           <th id=${t.Cookie.Attribute.SIZE} sortable align="right" weight="7">
             ${l(r.size)}
           </th>
           <th id=${t.Cookie.Attribute.HTTP_ONLY} sortable align="center" weight="7" ?editable=${n.editable} type="boolean">
             HttpOnly
           </th>
           <th id=${t.Cookie.Attribute.SECURE} sortable align="center" weight="7" ?editable=${n.editable} type="boolean">
             ${l(r.secure)}
           </th>
           <th id=${t.Cookie.Attribute.SAME_SITE} sortable weight="7" ?editable=${n.editable}>
             SameSite
           </th>
           <th id=${t.Cookie.Attribute.PARTITION_KEY_SITE} sortable weight="7" ?editable=${n.editable}>
             ${l(r.partitionKeySite)}
           </th>
           <th id=${t.Cookie.Attribute.HAS_CROSS_SITE_ANCESTOR} sortable align="center" weight="7" ?editable=${n.editable} type="boolean">
             Cross Site
           </th>
           <th id=${t.Cookie.Attribute.PRIORITY} sortable weight="7" ?editable=${n.editable}>
             ${l(r.priority)}
           </th>
           ${n.schemeBindingEnabled?C`
           <th id=${t.Cookie.Attribute.SOURCE_SCHEME} sortable align="center" weight="7" ?editable=${n.editable} type="string">
             SourceScheme
           </th>`:h}
           ${n.portBindingEnabled?C`
          <th id=${t.Cookie.Attribute.SOURCE_PORT} sortable align="center" weight="7" ?editable=${n.editable} type="number">
             SourcePort
          </th>`:h}
        </tr>
        ${P(n.data,i=>i.key,i=>{let o=!!i["http-only"];return C`
          <tr ?selected=${i.key===n.selectedKey}
              ?inactive=${i.inactive}
              ?dirty=${i.dirty}
              ?highlighted=${i.flagged}
              @edit=${a=>n.onEdit(i,a.detail.columnId,a.detail.valueBeforeEditing,a.detail.newText)}
              @delete=${()=>n.onDelete(i)}
              @contextmenu=${a=>n.onContextMenu(i,a.detail)}
              @select=${()=>n.onSelect(i.key)}>
            <td>${n.showAiButton?C`
                <span class="ai-button-container">
                  <devtools-floating-button
                    icon-name="smart-assistant"
                    title=${m(o?l(r.httpOnlyCookiesCannotBeAdded):n.aiButtonTitle)}
                    ?disabled=${o}
                    @click=${a=>!o&&n.onAiButtonClick?.(i,a)}
                  ></devtools-floating-button>
                </span>
              `:h}${D(i.iconTitles?.name)}${i.name}</td>
            <td>${i.value}</td>
            <td>${D(i.iconTitles?.domain)}${i.domain}</td>
            <td>${D(i.iconTitles?.path)}${i.path}</td>
            <td title=${m(i.expiresTooltip)}>${i.expires}</td>
            <td>${i.size}</td>
            <td data-value=${o}></td>
            <td data-value=${!!i.secure}>${D(i.iconTitles?.secure)}</td>
            <td>${D(i.iconTitles?.["same-site"])}${i["same-site"]}</td>
            <td>${i["partition-key-site"]}</td>
            <td data-value=${!!i["has-cross-site-ancestor"]}></td>
            <td data-value=${m(i.priorityValue)}>${i.priority}</td>
            ${n.schemeBindingEnabled?C`
              <td title=${l(r.sourceSchemeTooltip)}>${i["source-scheme"]}</td>`:h}
            ${n.portBindingEnabled?C`
              <td title=${l(r.sourcePortTooltip)}>${i["source-port"]}</td>`:h}
          </tr>`})}
          ${n.editable?C`<tr placeholder></tr>`:h}
        </table>
      </devtools-data-grid>`,s,{container:{classes:["cookies-table"]}})},A=class extends I.Widget.VBox{#i;#o;#n;#e;#t=!1;#r;#l;#d;lastEditedColumnId;data=[];cookies=[];#s;cookieToBlockedReasons;cookieToExemptionReason;view;selectedKey;#a;renderInline;schemeBindingEnabled;portBindingEnabled;constructor(e,s,i,o,a,d,u=y){super(e),this.#i=i,this.#o=o,this.#e=d,this.#a=!!i;let{devToolsEnableOriginBoundCookies:c}=v.Runtime.hostConfig;this.schemeBindingEnabled=!!c?.schemeBindingEnabled,this.portBindingEnabled=!!c?.portBindingEnabled,this.view=u,this.renderInline=!!s,this.#n=a,this.lastEditedColumnId=null,this.data=[],this.#s="",this.cookieToBlockedReasons=null,this.cookieToExemptionReason=null,this.requestUpdate()}set cookiesData(e){this.setCookies(e.cookies,e.cookieToBlockedReasons,e.cookieToExemptionReason)}set saveCallback(e){this.#i=e}set refreshCallback(e){this.#o=e}set selectedCallback(e){this.#n=e}set aiButtonIsEnabled(e){this.#t=e}get aiButtonIsEnabled(){return this.#t}set onAiButtonClick(e){this.#r=e}set onPopulateAiContextMenu(e){this.#l=e}set aiButtonTitle(e){this.#d=e}set deleteCallback(e){this.#e=e}set editable(e){this.#a=e}set inline(e){this.renderInline=e,this.requestUpdate()}setCookies(e,s,i){this.cookieToBlockedReasons=s||null,this.cookieToExemptionReason=i||null,this.cookies=e;let o=this.data.find(d=>d.key===this.selectedKey),a=this.cookies.find(d=>d.key()===this.selectedKey);this.data=e.sort((d,u)=>d.name().localeCompare(u.name())).map(this.createCookieData.bind(this)),o&&this.lastEditedColumnId&&!a&&(o.inactive=!0,this.data.push(o)),this.requestUpdate()}set cookieDomain(e){this.#s=e}selectedCookie(){return this.cookies.find(e=>e.key()===this.selectedKey)||null}willHide(){super.willHide(),this.lastEditedColumnId=null}performUpdate(){let e=this.#r,s={data:this.data,selectedKey:this.selectedKey,editable:this.#a,deletable:!!this.#e,renderInline:this.renderInline,schemeBindingEnabled:this.schemeBindingEnabled,portBindingEnabled:this.portBindingEnabled,onEdit:this.onUpdateCookie.bind(this),onCreate:this.onCreateCookie.bind(this),onRefresh:this.refresh.bind(this),onDelete:this.onDeleteCookie.bind(this),onSelect:this.onSelect.bind(this),onContextMenu:this.populateContextMenu.bind(this),showAiButton:this.#t,aiButtonTitle:this.#t?this.#d:void 0,onAiButtonClick:this.#t&&e?(i,o)=>{o.stopPropagation();let a=this.cookies.find(d=>d.key()===i.key);a&&e(a,o)}:void 0};this.view(s,void 0,this.contentElement)}onSelect(e){this.selectedKey=e,this.#n?.(this.selectedCookie())}onDeleteCookie(e){let s=this.cookies.find(i=>i.key()===e.key);s&&this.#e&&this.#e(s,()=>this.refresh())}onUpdateCookie(e,s,i,o){let a=this.cookies.find(u=>u.key()===e.key);if(!a)return;let d={...e,[s]:o};if(!this.isValidCookieData(d)){d.dirty=!0,this.requestUpdate();return}this.lastEditedColumnId=s,this.saveCookie(d,a)}onCreateCookie(e){this.setDefaults(e),this.isValidCookieData(e)?this.saveCookie(e):(e.dirty=!0,this.requestUpdate())}setDefaults(e){e[t.Cookie.Attribute.NAME]===void 0&&(e[t.Cookie.Attribute.NAME]=""),e[t.Cookie.Attribute.VALUE]===void 0&&(e[t.Cookie.Attribute.VALUE]=""),e[t.Cookie.Attribute.DOMAIN]===void 0&&(e[t.Cookie.Attribute.DOMAIN]=this.#s),e[t.Cookie.Attribute.PATH]===void 0&&(e[t.Cookie.Attribute.PATH]="/"),e[t.Cookie.Attribute.EXPIRES]===void 0&&(e[t.Cookie.Attribute.EXPIRES]=p()),e[t.Cookie.Attribute.PARTITION_KEY]===void 0&&(e[t.Cookie.Attribute.PARTITION_KEY]="")}saveCookie(e,s){if(!this.#i)return;let i=this.createCookieFromData(e);this.#i(i,s??null).then(o=>{o||(e.dirty=!0),this.refresh()})}createCookieFromData(e){let s=new t.Cookie.Cookie(e[t.Cookie.Attribute.NAME]||"",e[t.Cookie.Attribute.VALUE]||"",null,e[t.Cookie.Attribute.PRIORITY]);for(let i of[t.Cookie.Attribute.DOMAIN,t.Cookie.Attribute.PATH,t.Cookie.Attribute.HTTP_ONLY,t.Cookie.Attribute.SECURE,t.Cookie.Attribute.SAME_SITE,t.Cookie.Attribute.SOURCE_SCHEME])if(i in e){let o=e[i];T(i)?o===!0&&s.addAttribute(i):s.addAttribute(i,o)}return e.expires&&e.expires!==p()&&s.addAttribute(t.Cookie.Attribute.EXPIRES,new Date(e[t.Cookie.Attribute.EXPIRES]).toUTCString()),t.Cookie.Attribute.SOURCE_PORT in e&&s.addAttribute(t.Cookie.Attribute.SOURCE_PORT,Number.parseInt(e[t.Cookie.Attribute.SOURCE_PORT]||"",10)||void 0),e[t.Cookie.Attribute.PARTITION_KEY_SITE]&&s.setPartitionKey(e[t.Cookie.Attribute.PARTITION_KEY_SITE],e[t.Cookie.Attribute.HAS_CROSS_SITE_ANCESTOR]===!0),s.setSize(e[t.Cookie.Attribute.NAME].length+e[t.Cookie.Attribute.VALUE].length),s}createCookieData(e){let i=e.type()===t.Cookie.Type.REQUEST,o={name:e.name(),value:e.value()};for(let u of[t.Cookie.Attribute.HTTP_ONLY,t.Cookie.Attribute.SECURE,t.Cookie.Attribute.SAME_SITE,t.Cookie.Attribute.SOURCE_SCHEME,t.Cookie.Attribute.SOURCE_PORT])e.hasAttribute(u)&&(T(u)?o[u]=!0:o[u]=String(e.getAttribute(u)??!0));o[t.Cookie.Attribute.DOMAIN]=e.domain()||(i?l(r.na):""),o[t.Cookie.Attribute.PATH]=e.path()||(i?l(r.na):""),o[t.Cookie.Attribute.EXPIRES]=e.maxAge()?S.TimeUtilities.secondsToString(Math.floor(e.maxAge())):e.expires()<0?p():e.expires()>864e13?l(r.timeAfter,{date:new Date(864e13).toISOString()}):e.expires()>0?new Date(e.expires()).toISOString():i?l(r.na):p(),e.expires()>864e13&&(o.expiresTooltip=l(r.timeAfterTooltip,{seconds:e.expires(),date:new Date(864e13).toISOString()})),o[t.Cookie.Attribute.PARTITION_KEY_SITE]=e.partitionKeyOpaque()?l(r.opaquePartitionKey).toString():e.topLevelSite(),o[t.Cookie.Attribute.HAS_CROSS_SITE_ANCESTOR]=e.hasCrossSiteAncestor(),o[t.Cookie.Attribute.SIZE]=String(e.size()),o[t.Cookie.Attribute.PRIORITY]=e.priority(),o.priorityValue=["Low","Medium","High"].indexOf(e.priority());let a=this.cookieToBlockedReasons?.get(e)||[];for(let u of a){o.flagged=!0;let c=u.attribute||t.Cookie.Attribute.NAME;o.iconTitles=o.iconTitles||{};let E=o.iconTitles[c];o.iconTitles[c]=E===void 0?u.uiString:E+`
`+u.uiString}let d=this.cookieToExemptionReason?.get(e)?.uiString;return d&&(o.iconTitles=o.iconTitles||{},o.flagged=!0,o.iconTitles.name=d),o.key=e.key(),o}isValidCookieData(e){return(!!e.name||!!e.value)&&this.isValidDomain(e.domain)&&this.isValidPath(e.path)&&this.isValidDate(e.expires)&&this.isValidPartitionKey(e[t.Cookie.Attribute.PARTITION_KEY_SITE])}isValidDomain(e){if(!e)return!0;let s=k.ParsedURL.ParsedURL.fromString("http://"+e);return s!==null&&s.domain()===e}isValidPath(e){if(!e)return!0;let s=k.ParsedURL.ParsedURL.fromString("http://example.com"+e);return s!==null&&s.path===e}isValidDate(e){return!e||e===p()||!isNaN(Date.parse(e))}isValidPartitionKey(e){return e?k.ParsedURL.ParsedURL.fromString(e)!==null:!0}refresh(){this.#o&&this.#o()}populateContextMenu(e,s){let i=this.cookies.find(a=>a.key()===e.key);if(!i)return;let o=i;this.#l?.(o,s),s.revealSection().appendItem(l(r.showRequestsWithThisCookie),()=>{let a=g.UIFilter.UIRequestFilter.filters([{filterType:g.UIFilter.FilterType.CookieDomain,filterValue:o.domain()},{filterType:g.UIFilter.FilterType.CookieName,filterValue:o.name()}]);k.Revealer.reveal(a)},{jslogContext:"show-requests-with-this-cookie"}),b.RelatedIssue.hasIssues(o,b.IssuesManager.IssuesManager.instance())&&s.revealSection().appendItem(l(r.showIssueAssociatedWithThis),()=>{b.RelatedIssue.reveal(o,b.IssuesManager.IssuesManager.instance())},{jslogContext:"show-issue-associated-with-this"})}};export{$ as CookiesTable};
//# sourceMappingURL=cookie_table.js.map
