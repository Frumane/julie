var p=Object.defineProperty;var f=(n,t)=>{for(var e in t)p(n,e,{get:t[e],enumerable:!0})};var g={};f(g,{ItemEditEvent:()=>d,ItemRemoveEvent:()=>c,List:()=>b});import*as v from"../../../core/i18n/i18n.js";import{Directives as y,html as o,nothing as l,render as x}from"../../lit/lit.js";import*as u from"../buttons/buttons.js";var m=`:host{width:100%;flex:auto 0 1;overflow-y:auto;flex-direction:column;--override-background-list-item-color:var(--sys-color-cdt-base-container)}:host(.square-corners) li{border-radius:0}:host([hidden]){display:none}ul{list-style:none;margin:0;padding:0}li{flex:none;min-height:30px;display:flex;align-items:center;position:relative;overflow:hidden;border-radius:var(--sys-shape-corner-extra-small);&:hover{.controls-gradient{background-image:linear-gradient(90deg,transparent,var(--sys-color-cdt-base-container))}.controls-buttons{visibility:visible}}&:focus-within:not(:active),
  &:focus-visible{background-color:var(--sys-color-state-hover-on-subtle);--override-background-list-item-color:var(--sys-color-neutral-container);outline:none;.controls-gradient{background-image:linear-gradient(90deg,transparent,var(--override-background-list-item-color))}.controls-buttons{background-color:var(--override-background-list-item-color);visibility:visible}}}.controls-container{display:flex;flex-direction:row;justify-content:flex-end;align-items:stretch;pointer-events:none;position:absolute;right:0;top:0;bottom:0}.controls-gradient{width:var(--sys-size-16)}.controls-buttons{flex:none;display:flex;flex-direction:row;align-items:center;pointer-events:auto;visibility:hidden;background-color:var(--sys-color-cdt-base-container)}
/*# sourceURL=${import.meta.resolve("./list.css")} */`;var r={edit:"Edit",remove:"Remove"},$=v.i18n.registerUIStrings("ui/components/lists/List.ts",r),a=v.i18n.getLocalizedString.bind(void 0,$),d=class extends CustomEvent{constructor(t){super("edit",{bubbles:!0,composed:!0,detail:t})}},c=class extends CustomEvent{constructor(t){super("delete",{bubbles:!0,composed:!0,detail:t})}},b=class extends HTMLElement{static observedAttributes=["editable","deletable","disable-li-focus"];#i;#e;#s=!1;#o=!1;#r;constructor(){super(),this.attachShadow({mode:"open"}),this.#i=new MutationObserver(()=>{this.#t()}),this.#e=new MutationObserver(()=>{this.#t()})}set editable(t){this.#s!==t&&(this.#s=t,this.#t())}set deletable(t){this.#o!==t&&(this.#o=t,this.#t())}set disableListItemFocus(t){this.#r!==t&&(this.#r=t,this.#t())}attributeChangedCallback(t,e,i){let s=i!==null;t==="editable"?this.editable=s:t==="deletable"?this.deletable=s:t==="disable-li-focus"&&(this.disableListItemFocus=s)}connectedCallback(){this.#i.observe(this,{childList:!0}),this.#t()}disconnectedCallback(){this.#i.disconnect(),this.#e.disconnect()}createSlottedListItem(t,e){let i=e?.hasAttribute("editable")?e.getAttribute("editable")!=="false":this.#s,s=e?.hasAttribute("deletable")?e.getAttribute("deletable")!=="false":this.#o;return o`
    <li
      role='listitem'
      tabindex=${this.#r?"-1":"0"}
      @keydown=${s?this.#l.bind(this,t):l}>
    <slot name='slot-${t}'></slot>
    ${i||s?o`
    <div class='controls-container'>
              <div class='controls-gradient'></div>
              <div class='controls-buttons'>
                ${i?o`
            <devtools-button
              title=${a(r.edit)}
              aria-label=${a(r.edit)}
              .iconName=${"edit"}
              .jslogContext=${"edit-item"}
              .variant=${u.Button.Variant.ICON}
              @click=${this.#a.bind(this,t)}
            ></devtools-button>
          `:l}
                ${s?o`
            <devtools-button
              title=${a(r.remove)}
              aria-label=${a(r.remove)}
              .iconName=${"bin"}
              .jslogContext=${"remove-item"}
              .variant=${u.Button.Variant.ICON}
              @click=${this.#n.bind(this,t)}
            ></devtools-button>
          `:l}
              </div>
            </div>`:l}
            </li>`}#t(){if(this.shadowRoot){this.#e.disconnect();let e=[...this.children].map((i,s)=>{this.#e.observe(i,{attributes:!0,attributeFilter:["editable","deletable"]});let h=`slot-${s}`;return i.getAttribute("slot")!==h&&i.setAttribute("slot",h),{index:s,item:i}});x(o`
    <style>${m}</style>
    <ul role='list'>
    ${y.repeat(e,i=>i.item,i=>this.createSlottedListItem(i.index,i.item))}
    </ul>
  `,this.shadowRoot)}}#n(t){this.dispatchEvent(new c({index:t}))}#l(t,e){e.target!==e.currentTarget||e.key!=="Delete"&&e.key!=="Backspace"||(e.preventDefault(),this.#n(t))}#a(t){this.dispatchEvent(new d({index:t}))}};customElements.define("devtools-list",b);export{g as List};
//# sourceMappingURL=lists.js.map
