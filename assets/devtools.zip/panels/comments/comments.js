var q=Object.defineProperty;var I=(o,e)=>{for(var t in e)q(o,t,{get:e[t],enumerable:!0})};var A={};I(A,{CommentsPane:()=>z,DEFAULT_VIEW:()=>V});import"../../ui/components/spinners/spinners.js";import"../../ui/components/tooltips/tooltips.js";import*as S from"../../core/common/common.js";import*as x from"../../core/i18n/i18n.js";import*as v from"../../models/comment_manager/comment_manager.js";import*as C from"../../ui/components/buttons/buttons.js";import*as b from"../../ui/legacy/legacy.js";import*as p from"../../ui/lit/lit.js";import*as c from"../../ui/visual_logging/visual_logging.js";import*as k from"../common/common.js";var $=`@scope to (devtools-widget > *){.comments-container{display:flex;flex-direction:column;height:100%;width:100%;overflow:hidden}.comments-toolbar{display:flex;align-items:center;justify-content:space-between;height:var(--sys-size-13);padding:0 var(--sys-size-5);border-bottom:var(--sys-size-1) solid var(--sys-color-divider);background-color:var(--sys-color-surface1);flex-shrink:0}.toolbar-left{display:flex;align-items:center;height:100%;gap:var(--sys-size-8);padding-left:var(--sys-size-3)}.tab-button{position:relative;display:flex;align-items:center;height:100%;padding:0 var(--sys-size-2);border:none;background:transparent;color:var(--sys-color-on-surface-subtle);font-size:var(--sys-typescale-body4-size);font-weight:var(--ref-typeface-weight-regular);cursor:pointer}.tab-button:hover{color:var(--sys-color-on-surface)}.tab-button:focus-visible{outline:var(--sys-size-2) solid var(--sys-color-state-focus-ring);outline-offset:calc(-1 * var(--sys-size-2))}.tab-button.active{color:var(--sys-color-primary);font-weight:var(--ref-typeface-weight-bold)}.tab-button.active::after{content:"";position:absolute;bottom:0;left:0;right:0;height:var(--sys-size-2);background-color:var(--sys-color-primary);border-radius:var(--sys-shape-corner-full) var(--sys-shape-corner-full) 0 0}.toolbar-button{display:flex;align-items:center;justify-content:center;width:var(--sys-size-11);height:var(--sys-size-11);padding:0;border:none;background:transparent;border-radius:var(--sys-shape-corner-extra-small);cursor:pointer;color:var(--sys-color-on-surface-subtle)}.toolbar-button:hover{background-color:var(--sys-color-state-hover-on-subtle);color:var(--sys-color-on-surface)}.toolbar-button:active{background-color:var(--sys-color-state-ripple-neutral-on-subtle)}.comments-scroll-container{position:relative;flex:1;min-height:0;overflow-y:auto}.comments-queued-section{display:flex;flex-direction:column}.comments-list{margin:0;padding:0;list-style:none}.comments-sent-section{margin-top:var(--sys-size-11);min-height:100%}.comments-sent-separator{padding:var(--sys-size-3) var(--sys-size-5);border-top:var(--sys-size-1) solid var(--sys-color-divider);border-bottom:var(--sys-size-1) solid var(--sys-color-divider);background-color:var(--sys-color-surface1);color:var(--sys-color-on-surface-subtle);font-size:var(--sys-typescale-body4-size);line-height:var(--sys-typescale-body4-line-height)}.comment-thread-item{display:flex;align-items:center;gap:var(--sys-size-5);padding:var(--sys-size-5) var(--sys-size-8);border-bottom:var(--sys-size-1) solid var(--sys-color-divider);cursor:pointer;transition:background-color var(--sys-motion-duration-short4) var(--sys-motion-easing-emphasized)}.comment-thread-item:hover{background-color:var(--sys-color-state-hover-on-subtle)}.comment-thread-item:focus-visible{background-color:var(--sys-color-state-hover-on-subtle);outline:var(--sys-size-2) solid var(--sys-color-state-focus-ring);outline-offset:calc(-1 * var(--sys-size-2))}.comment-pin-badge{box-sizing:border-box;width:var(--sys-size-9);height:var(--sys-size-9);margin-right:var(--sys-size-2);border-radius:var(--sys-shape-corner-full) var(--sys-shape-corner-full) var(--sys-shape-corner-full) var(--sys-shape-corner-extra-small);border:var(--sys-size-2) solid var(--sys-color-primary);background-color:var(--sys-color-cdt-base-container);flex-shrink:0}.comment-pin-badge.resolved{border:none;background-color:var(--sys-color-primary)}.comment-thread-item.orphaned .comment-pin-badge{border-color:var(--sys-color-surface-variant)}.comment-thread-item.orphaned .comment-pin-badge.resolved{background-color:var(--sys-color-surface-variant)}.anchor-chip{display:flex;height:calc(var(--sys-size-8) + var(--sys-size-2));padding:var(--sys-size-2) var(--sys-size-4) var(--sys-size-2) var(--sys-size-3);align-items:center;border-radius:var(--sys-shape-corner-extra-small);border:var(--sys-size-1) solid var(--sys-color-divider);background:var(--sys-color-surface2);font-family:var(--source-code-font-family);font-size:var(--monospace-font-size);color:var(--sys-color-token-tag);overflow:hidden;max-width:var(--sys-size-24);min-width:0;flex-shrink:0;pointer-events:none}.anchor-chip.orphaned{border-style:dashed;border-color:var(--sys-color-neutral-outline);background:transparent;color:var(--sys-color-state-disabled);gap:var(--sys-size-3)}.anchor-chip.orphaned .anchor-chip-text{color:var(--sys-color-state-disabled)}.orphaned-label{flex-shrink:0;color:var(--sys-color-on-surface-subtle);font-family:var(--default-font-family);font-size:var(--sys-typescale-body5-size);font-style:italic}.anchor-chip devtools-widget,
  .anchor-chip-text{display:block;flex:0 1 auto;min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.comment-text{flex:1;font-size:var(--sys-typescale-body4-size);line-height:var(--sys-typescale-body4-line-height);color:var(--sys-color-on-surface);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.thread-status-working,
  .thread-status-sent{display:flex;align-items:center;gap:var(--sys-size-4);color:var(--sys-color-on-surface-subtle);font-size:var(--sys-typescale-body4-size);line-height:var(--sys-typescale-body4-line-height);font-weight:var(--ref-typeface-weight-medium);white-space:nowrap}.thread-status-sent{gap:var(--sys-size-2)}.check-icon{width:var(--sys-size-8);height:var(--sys-size-8);color:var(--sys-color-on-surface-subtle)}.see-response-button{margin-right:calc(-1 * var(--sys-size-6))}.comments-empty-state{display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1;padding:var(--sys-size-13) var(--sys-size-8);text-align:center}.comments-empty-state-title{margin-bottom:var(--sys-size-4);color:var(--sys-color-on-surface);font-size:var(--sys-typescale-headline5-size);line-height:var(--sys-typescale-headline5-line-height);font-weight:var(--ref-typeface-weight-medium)}.comments-empty-state-description{max-width:var(--sys-size-29);color:var(--sys-color-on-surface-subtle);font-size:var(--sys-typescale-body3-size);line-height:var(--sys-typescale-body3-line-height);text-wrap:balance}.comments-empty-state-icon{width:var(--sys-size-8);height:var(--sys-size-8);vertical-align:text-bottom;color:var(--sys-color-on-surface-subtle)}.comments-empty-state-link{margin-top:var(--sys-size-3)}.comments-footer{position:sticky;bottom:0;z-index:1;display:flex;align-items:center;justify-content:flex-end;gap:var(--sys-size-5);margin-top:calc(-1 * var(--sys-size-1));padding:var(--sys-size-5) var(--sys-size-8);border-top:var(--sys-size-1) solid var(--sys-color-divider);background-color:var(--sys-color-cdt-base-container);flex-shrink:0}.info-icon{color:var(--sys-color-on-surface-subtle);cursor:pointer}.info-tooltip-container{max-width:var(--sys-size-28);padding:var(--sys-size-4) var(--sys-size-5)}.send-agent-button{background-color:var(--sys-color-primary);color:var(--sys-color-on-primary);border:none;border-radius:var(--sys-shape-corner-full);padding:var(--sys-size-4) var(--sys-size-8);font-size:var(--sys-typescale-body4-size);font-weight:var(--ref-typeface-weight-medium);cursor:pointer;transition:background-color var(--sys-motion-duration-short4) var(--sys-motion-easing-emphasized),box-shadow var(--sys-motion-duration-short4) var(--sys-motion-easing-emphasized)}.send-agent-button:hover{background-color:var(--sys-color-primary-bright);box-shadow:var(--sys-elevation-level1)}}
/*# sourceURL=${import.meta.resolve("./commentsPane.css")} */`;var{html:r,render:O,i18nTemplate:P,Directives:{classMap:R,ref:E,repeat:B}}=p,{widget:H}=b.Widget,{computeCommentTitle:N,inputDisclaimer:U}=k.CommentThreadWidget,n={clearComments:"Clear all comments",noQueuedComments:"No queued comments",noComments:"No comments",emptyStateDescription:"Use {PH1} to select an element and send tasks, questions, and context to your coding agent",commentModeIcon:"Comment mode",addComment:"Add a comment",deleteComment:"Delete comment",sendToAgent:"Send to agent",working:"Working",sentStatus:"Sent",sentCheckmark:"Sent checkmark",seeResponse:"See response",queued:"Queued",sent:"Sent",removed:"removed",sentComments:"Sent comments"},L=x.i18n.registerUIStrings("panels/comments/CommentsPane.ts",n),a=x.i18n.getLocalizedString.bind(void 0,L),M="comments.toggle-comment-mode";function j(o,e){switch(o.status){case"SENT_TO_AGENT":return o.transmitted?r`
        <div class="thread-status-working">
          <devtools-spinner></devtools-spinner>
          <span>${a(n.working)}</span>
        </div>
      `:r`
          <div class="thread-status-sent">
            <devtools-icon
              class="check-icon"
              name="checkmark"
              aria-label=${a(n.sentCheckmark)}>
            </devtools-icon>
            <span>${a(n.sentStatus)}</span>
          </div>
        `;case"RESOLVED":return r`
        <devtools-button
          class="see-response-button"
          .data=${{variant:C.Button.Variant.TEXT,jslogContext:"comments-see-response"}}
          @keydown=${t=>{(t.key==="Enter"||t.key===" ")&&t.stopPropagation()}}
        >${a(n.seeResponse)}</devtools-button>
      `;case"ACTIVE":return r`
        <devtools-button
          .data=${{variant:C.Button.Variant.ICON,iconName:"bin",title:a(n.deleteComment),jslogContext:"delete"}}
          @click=${t=>{t.stopPropagation(),e(o.id)}}
          @keydown=${t=>{(t.key==="Enter"||t.key===" ")&&t.stopPropagation()}}
        ></devtools-button>
      `;default:return p.nothing}}var V=(o,e,t)=>{let h=o.activeTab==="queued",f=o.activeTab==="sent",T=o.queuedThreads.length>0||o.sentThreads.length>0,m;e.scrollToSection=(i,{animate:u})=>{let{scrollContainer:s}=e,l=i==="queued"?0:m?.offsetTop;return!s||l===void 0||Math.abs(l-s.scrollTop)<1?!1:(s.scrollTo({top:l,behavior:u?"smooth":"instant"}),u)},e.sectionAtTop=()=>{let{scrollContainer:i}=e;return i&&m&&m.offsetTop-i.scrollTop<=1?"sent":"queued"};let g=(i,u)=>{let s=i.currentTarget,l=s.getBoundingClientRect(),D=s.querySelector(".comment-pin-badge")?.getBoundingClientRect();o.onThreadClick(u,{left:D?.left??l.left,top:l.top})},y=(i,u)=>r`
    <ul class="comments-list ${u}" role="list">
      ${B(i,s=>s.thread.id,s=>r`
          <li
            class="comment-thread-item ${s.thread.isOrphaned?"orphaned":""}"
            role="listitem"
            tabindex="0"
            @click=${l=>g(l,s.thread)}
            @keydown=${l=>{(l.key==="Enter"||l.key===" ")&&(l.preventDefault(),g(l,s.thread))}}
            jslog=${c.item("comment-thread").track({click:!0})}>
            <div
              class=${R({"comment-pin-badge":!0,resolved:s.thread.status==="RESOLVED"})}
              aria-hidden="true">
            </div>
            <span class="anchor-chip ${s.thread.isOrphaned?"orphaned":""}">
              ${"node"in s.title?H(k.DOMLinkifier.DOMNodeLink,{node:s.title.node,options:{preventKeyboardFocus:!0,disabled:s.thread.isOrphaned}}):r`<span class="anchor-chip-text">${s.title.text}</span>`}
              ${s.thread.isOrphaned?r`<span class="orphaned-label">(${a(n.removed)})</span>`:p.nothing}
            </span>
            <div class="comment-text">${s.commentText}</div>
            ${j(s.thread,o.onDeleteThread)}
          </li>
        `)}
    </ul>
  `,w=()=>r`
    <div class="comments-footer">
      <devtools-icon
        class="info-icon"
        name="info"
        aria-label="Info"
        aria-details="comments-pane-info-tooltip"
        tabindex="0"
      ></devtools-icon>
      <devtools-tooltip
        id="comments-pane-info-tooltip"
        variant="rich"
      >
        <div class="info-tooltip-container">
          ${U()}
        </div>
      </devtools-tooltip>
      <button
        class="send-agent-button"
        @click=${o.onSendToAgent}
        jslog=${c.action("comments-send-to-agent").track({click:!0})}>
        ${a(n.sendToAgent)}
      </button>
    </div>
  `,d=i=>r`
    <div class="comments-empty-state">
      <div class="comments-empty-state-title">${i}</div>
      <div class="comments-empty-state-description">
        ${P(L,n.emptyStateDescription,{PH1:r`<devtools-icon
            class="comments-empty-state-icon"
            name="comment-mode"
            role="img"
            aria-label=${a(n.commentModeIcon)}
          ></devtools-icon>`})}
      </div>
      <devtools-button
        class="comments-empty-state-link"
        .data=${{variant:C.Button.Variant.TEXT,jslogContext:"comments-add-comment"}}
        @click=${o.onAddComment}
      >${a(n.addComment)}</devtools-button>
    </div>
  `;O(r`
    <style>${$}</style>
    <div class="comments-container" role="region" aria-label="Comments" jslog=${c.panel("comments").track({resize:!0})}>
      <div class="comments-toolbar" role="toolbar" jslog=${c.toolbar("comments-drawer")}>
        <div class="toolbar-left">
          <button
            class="tab-button ${h?"active":""}"
            aria-current=${h?"location":"false"}
            @click=${()=>o.onTabClick("queued")}
            jslog=${c.sectionHeader("queued").track({click:!0})}>
            ${a(n.queued)}
          </button>
          <button
            class="tab-button ${f?"active":""}"
            aria-current=${f?"location":"false"}
            @click=${()=>o.onTabClick("sent")}
            jslog=${c.sectionHeader("sent").track({click:!0})}>
            ${a(n.sent)}
          </button>
        </div>
        <button
          class="toolbar-button"
          title=${a(n.clearComments)}
          aria-label=${a(n.clearComments)}
          @click=${o.onClearAll}
          jslog=${c.action("clear-comments").track({click:!0})}>
          <devtools-icon name="clear"></devtools-icon>
        </button>
      </div>

      ${T?r`
        <div
          class="comments-scroll-container"
          ${E(i=>{e.scrollContainer=i})}
          @scroll=${o.onScroll}
          @scrollend=${o.onScrollEnd}>
          <div class="comments-queued-section">
            ${o.queuedThreads.length>0?r`
              ${y(o.queuedThreads,"comments-queued-list")}
              ${w()}
            `:d(a(n.noQueuedComments))}
          </div>
          ${o.sentThreads.length>0?r`
            <div class="comments-sent-section" ${E(i=>{m=i})}>
              <div class="comments-sent-separator" role="separator" aria-label=${a(n.sentComments)}>
                ${a(n.sentComments)}
              </div>
              ${y(o.sentThreads,"comments-sent-list")}
            </div>
          `:p.nothing}
        </div>
      `:d(a(n.noComments))}
    </div>
  `,t)},z=class extends b.Widget.Widget{static INJECT=[v.CommentManager.CommentManager];#a;#e;#r=new WeakMap;#t={};#o="queued";#s=!1;#n=!1;constructor(e,[t]=[new v.CommentManager.CommentManager],h=V){super(e),this.#a=h,this.#e=t}#i=()=>{this.requestUpdate()};wasShown(){super.wasShown(),this.#e.addEventListener(v.CommentManager.Events.COMMENT_THREADS_CHANGED,this.#i,this),this.#n=!1,this.requestUpdate()}elementsToRestoreScrollPositionsFor(){let{scrollContainer:e}=this.#t;return e?[this.element,e]:[this.element]}willHide(){this.#s=!1,this.#e.removeEventListener(v.CommentManager.Events.COMMENT_THREADS_CHANGED,this.#i,this),super.willHide()}#l(e){this.#o!==e&&(this.#o=e,this.requestUpdate())}#m=e=>{this.#s=this.#t.scrollToSection?.(e,{animate:!0})??!1,this.#l(e)};#c=()=>{!this.#s&&this.#t.sectionAtTop&&this.#l(this.#t.sectionAtTop())};#v=()=>{this.#s=!1,this.#c()};#h=()=>{this.#e.clear(),this.requestUpdate()};#u=(e,t)=>{e.isGeneratedComment&&e.status!=="RESOLVED"||S.Revealer.reveal(new v.CommentThread.RevealableThread(e,t))};#g=e=>{this.#e.removeCommentThread(e),this.requestUpdate()};#y=()=>{this.#e.sendQueuedThreads()};#p=()=>{let e=b.ActionRegistry.ActionRegistry.instance();this.#e.isCommentMode()||!e.hasAction(M)||e.getAction(M).execute()};async#d(e){let t=this.#r.get(e);return t||(t=await N(e.anchor),this.#r.set(e,t)),{thread:e,title:t,commentText:e.comments[0]?.text??""}}async performUpdate(e){let t=this.#e.getCommentThreads(),h=t.filter(d=>d.status==="ACTIVE"),f=t.filter(d=>d.status==="SENT_TO_AGENT"||d.status==="RESOLVED"),[T,m]=await Promise.all([Promise.all(h.map(d=>this.#d(d))),Promise.all(f.map(d=>this.#d(d)))]);if(e?.aborted)return;let g=T.length===0&&m.length>0,y=g&&!this.#n;this.#n=g,y?this.#o="sent":m.length===0&&(this.#o="queued");let w={activeTab:this.#o,queuedThreads:T,sentThreads:m,onTabClick:this.#m,onScroll:this.#c,onScrollEnd:this.#v,onClearAll:this.#h,onThreadClick:this.#u,onDeleteThread:this.#g,onSendToAgent:this.#y,onAddComment:this.#p};this.#a(w,this.#t,this.contentElement),y&&this.#t.scrollToSection?.("sent",{animate:!1})}};export{A as CommentsPane};
//# sourceMappingURL=comments.js.map
