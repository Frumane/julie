import"../../ui/components/spinners/spinners.js";import"../../ui/kit/kit.js";import*as S from"../../core/common/common.js";import*as i from"../../core/host/host.js";import*as $ from"../../core/i18n/i18n.js";import*as b from"../../core/root/root.js";import*as k from"../../models/ai_assistance/ai_assistance.js";import*as U from"../../third_party/marked/marked.js";import*as p from"../../ui/components/buttons/buttons.js";import*as z from"../../ui/components/input/input.js";import*as D from"../../ui/components/markdown_view/markdown_view.js";import*as A from"../../ui/legacy/legacy.js";import*as h from"../../ui/lit/lit.js";import*as v from"../../ui/visual_logging/visual_logging.js";import*as w from"../console/console.js";var N=`@scope to (devtools-widget > *){*{padding:0;margin:0;box-sizing:border-box}:scope{font-family:var(--default-font-family);font-size:inherit;display:block}.wrapper{background-color:var(--sys-color-cdt-base-container);border-radius:var(--sys-shape-corner-medium);container-type:inline-size;display:grid;animation:expand var(--sys-motion-duration-medium2) var(--sys-motion-easing-emphasized) forwards}.wrapper.closing{animation:collapse var(--sys-motion-duration-medium2) var(--sys-motion-easing-emphasized) forwards}@keyframes expand{from{grid-template-rows:0fr}to{grid-template-rows:1fr}}@keyframes collapse{from{grid-template-rows:1fr}to{grid-template-rows:0fr;padding-top:0;padding-bottom:0}}.animation-wrapper{overflow:hidden;padding:var(--sys-size-6) var(--sys-size-8)}.wrapper.top{border-radius:var(--sys-shape-corner-medium) var(--sys-shape-corner-medium) var(--sys-shape-corner-extra-small) var(--sys-shape-corner-extra-small)}header{display:flex;flex-direction:row;gap:var(--sys-size-4);color:var(--sys-color-on-surface);font-size:var(--sys-typescale-body3-size);font-style:normal;font-weight:500;margin-bottom:var(--sys-size-6);align-items:center}header:focus-visible{outline:none}header > .filler{display:flex;flex-direction:row;gap:var(--sys-size-5);align-items:center;flex:1}.reminder-container{border-radius:var(--sys-size-5);background-color:var(--sys-color-surface4);padding:var(--sys-size-8);font-weight:var(--ref-typeface-weight-medium);h3{font:inherit}}.reminder-items{display:grid;grid-template-columns:var(--sys-size-8) auto;gap:var(--sys-size-5) var(--sys-size-6);margin-top:var(--sys-size-6);line-height:var(--sys-size-8);font-weight:var(--ref-typeface-weight-regular)}main{--override-markdown-view-message-color:var(--sys-color-on-surface);color:var(--sys-color-on-surface);font-size:var(--sys-typescale-body4-size);font-style:normal;font-weight:400;line-height:var(--sys-size-9);p{margin-block:1em}ul{list-style-type:none;list-style-position:inside;padding-inline-start:0.2em;li{display:list-item;list-style-type:disc;list-style-position:outside;margin-inline-start:1em}li::marker{font-size:var(--sys-typescale-body5-size);line-height:1}}label{display:inline-flex;flex-direction:row;gap:0.5em;input,
      span{vertical-align:middle}input[type="checkbox"]{margin-top:0.3em}}}.opt-in-teaser{display:flex;gap:var(--sys-size-5)}devtools-markdown-view{margin-bottom:var(--sys-size-6)}footer{display:flex;flex-direction:row;align-items:center;color:var(--sys-color-on-surface);font-style:normal;font-weight:400;line-height:normal;margin-top:var(--sys-size-7);gap:var(--sys-size-13)}@container (max-width: 600px){footer{gap:var(--sys-size-5)}}footer > .filler{flex:1}footer .rating{display:flex;flex-direction:row;gap:var(--sys-size-5)}.buttons{display:flex;gap:var(--sys-size-3)}@media (width <= 500px){.buttons{flex-wrap:wrap}}main .buttons{margin-top:var(--sys-size-6)}.disclaimer{display:flex;gap:var(--sys-size-2);color:var(--sys-color-on-surface-subtle);font-size:var(--sys-typescale-body5-size);align-items:flex-start;flex-direction:column}.link{color:var(--sys-color-primary);text-decoration-line:underline;devtools-icon{color:var(--sys-color-primary);width:var(--sys-size-7);height:var(--sys-size-7)}}button.link{border:none;background:none;cursor:pointer;font:inherit}.loader{background:linear-gradient(130deg,transparent 0%,var(--sys-color-gradient-tertiary) 20%,var(--sys-color-gradient-primary) 40%,transparent 60%,var(--sys-color-gradient-tertiary) 80%,var(--sys-color-gradient-primary) 100%);background-position:0% 0%;background-size:250% 250%;animation:gradient 5s infinite linear}@keyframes gradient{0%{background-position:0 0}100%{background-position:100% 100%}}summary{font-size:var(--sys-typescale-body4-size);font-style:normal;font-weight:400;line-height:var(--sys-size-9)}details{overflow:hidden;margin-top:var(--sys-size-6)}::details-content{height:0;transition:height var(--sys-motion-duration-short4) var(--sys-motion-easing-emphasized),content-visibility var(--sys-motion-duration-short4) var(--sys-motion-easing-emphasized) allow-discrete}[open]::details-content{height:auto}details.references{transition:margin-bottom var(--sys-motion-duration-short4) var(--sys-motion-easing-emphasized)}details.references[open]{margin-bottom:var(--sys-size-1)}h2{display:block;font-size:var(--sys-size-7);margin:0;font-weight:var(--ref-typeface-weight-medium);line-height:var(--sys-size-9)}h2:focus-visible{outline:none}.info{width:var(--sys-size-9);height:var(--sys-size-9)}.badge{background:linear-gradient(135deg,var(--sys-color-gradient-primary),var(--sys-color-gradient-tertiary));border-radius:var(--sys-size-3);height:var(--sys-size-9);devtools-icon{margin:var(--sys-size-2)}}.header-icon-container{background:linear-gradient(135deg,var(--sys-color-gradient-primary),var(--sys-color-gradient-tertiary));border-radius:var(--sys-size-4);height:var(--sys-size-13);width:var(--sys-size-13);display:flex;align-items:center;justify-content:center}.close-button{align-self:flex-start}.sources-list{padding-left:var(--sys-size-6);margin-bottom:var(--sys-size-6);list-style:none;counter-reset:sources;display:grid;grid-template-columns:var(--sys-size-9) auto;list-style-position:inside}.sources-list li{display:contents}.sources-list li::before{counter-increment:sources;content:"[" counter(sources) "]";display:table-cell}.sources-list devtools-link.highlighted{animation:highlight-fadeout 2s}@keyframes highlight-fadeout{from{background-color:var(--sys-color-yellow-container)}to{background-color:transparent}}.references-list{padding-left:var(--sys-size-8)}.references-list li{padding-left:var(--sys-size-3)}details h3{font-size:var(--sys-typescale-body5-size);font-weight:var(--ref-typeface-weight-medium);text-transform:uppercase;color:var(--sys-color-on-surface-subtle);padding-left:var(--sys-size-6)}.error-message{font:var(--sys-typescale-body4-bold)}@scope (.insight-sources){:root{padding:0;margin:0;box-sizing:border-box;display:block}:scope ul{color:var(--sys-color-primary);font-size:var(--sys-typescale-body4-size);font-style:normal;font-weight:400;line-height:var(--sys-typescale-body4-line-height);margin-top:var(--sys-size-6);padding-inline-start:var(--sys-size-3)}li{list-style-type:none}ul .link{color:var(--sys-color-primary);display:inline-flex!important;align-items:center;gap:var(--sys-size-3);text-decoration-line:underline}devtools-icon{height:var(--sys-size-8);width:var(--sys-size-8);margin-right:var(--sys-size-1)}devtools-icon[name="open-externally"]{color:var(--icon-link)}.source-disclaimer{color:var(--sys-color-on-surface-subtle)}}}
/*# sourceURL=${import.meta.resolve("././components/consoleInsight.css")} */`;var l={consoleMessage:"Console message",stackTrace:"Stack trace",networkRequest:"Network request",relatedCode:"Related code",generating:"Generating explanation\u2026",insight:"Explanation",closeInsight:"Close explanation",inputData:"Data used to understand this message",goodResponse:"Good response",badResponse:"Bad response",report:"Report legal issue",error:"DevTools encountered an error",errorBody:"Something went wrong. Try again.",opensInNewTab:"(opens in a new tab)",learnMore:"Learn more",notLoggedIn:"This feature is only available when you sign in to Chrome with your Google account",signIn:"Sign in",offlineHeader:"DevTools can\u2019t reach the internet",offline:"Check your internet connection and try again",signInToUse:"Sign in to use this feature",search:"Use search instead",reloadRecommendation:"Reload the page to capture related network request data for this message to get a better insight",turnOnInSettings:"Turn on {PH1} to use AI assistance for understanding and addressing console warnings and errors",settingsLink:"`Console insights` in Settings",references:"Sources and related content",relatedContent:"Related content",timedOut:"Generating a response took too long. Please try again.",notAvailableInIncognitoMode:"AI assistance isn\u2019t available in Incognito mode or Guest mode"},_=$.i18n.registerUIStrings("panels/explain/components/ConsoleInsight.ts",l),c=$.i18n.getLocalizedString.bind(void 0,_),j=h.i18nTemplate.bind(void 0,_),{render:W,html:a,Directives:C}=h,{widget:q}=A.Widget,H=class s extends Event{static eventName="closeinsight";constructor(){super(s.eventName,{composed:!0,bubbles:!0})}};function O(s){switch(s){case w.PromptBuilder.SourceType.MESSAGE:return c(l.consoleMessage);case w.PromptBuilder.SourceType.STACKTRACE:return c(l.stackTrace);case w.PromptBuilder.SourceType.NETWORK_REQUEST:return c(l.networkRequest);case w.PromptBuilder.SourceType.RELATED_CODE:return c(l.relatedCode)}}var Y="https://policies.google.com/terms",Q="https://policies.google.com/privacy",K="https://support.google.com/legal/answer/13505487",V="https://goo.gle/devtools-console-messages-ai",J="https://accounts.google.com",X=(g=>(g.INSIGHT="insight",g.LOADING="loading",g.ERROR="error",g.SETTING_IS_NOT_TRUE="setting-is-not-true",g.CONSENT_REMINDER="consent-reminder",g.NOT_LOGGED_IN="not-logged-in",g.SYNC_IS_PAUSED="sync-is-paused",g.OFFLINE="offline",g))(X||{}),Z={name:"citation",level:"inline",start(s){return s.match(/\[\^/)?.index},tokenizer(s){let e=s.match(/^\[\^(\d+)\]/);return e?{type:"citation",raw:e[0],linkText:Number(e[1])}:!1},renderer:()=>""};function G(s){return!!s.factualityMetadata?.facts.length}var R=s=>s.stopPropagation();function ee(s){return a`<devtools-button
    @click=${s}
    class="search-button"
    .variant=${p.Button.Variant.OUTLINED}
    .jslogContext=${"search"}
  >
    ${c(l.search)}
  </devtools-button>`}function te(){return a`<devtools-link href=${V} class="link" jslogcontext="learn-more">
    ${c(l.learnMore)}
  </devtools-link>`}function ie(s,e,t,n){return s.length?a`
    <ol class="sources-list">
      ${s.map((r,d)=>a`
        <li>
          <devtools-link
            href=${r}
            class=${C.classMap({link:!0,highlighted:d===e})}
            jslogcontext="references.console-insights"
            ${C.ref(o=>{n.citationLinks[d]=o})}
            @animationend=${t}
          >
            ${r}
          </devtools-link>
        </li>
      `)}
    </ol>
  `:h.nothing}function se(s,e){return s.length===0?h.nothing:a`
    ${e.length?a`<h3>${c(l.relatedContent)}</h3>`:h.nothing}
    <ul class="references-list">
      ${s.map(t=>a`
        <li>
          <devtools-link
            href=${t}
            class="link"
            jslogcontext="references.console-insights"
          >
            ${t}
          </devtools-link>
        </li>
      `)}
    </ul>
  `}function ne(){return a`
    <div role="presentation" aria-label="Loading" class="loader" style="clip-path: url('#clipPath');">
      <svg width="100%" height="64">
        <clipPath id="clipPath">
          <rect x="0" y="0" width="100%" height="16" rx="8"></rect>
          <rect x="0" y="24" width="100%" height="16" rx="8"></rect>
          <rect x="0" y="48" width="100%" height="16" rx="8"></rect>
        </clipPath>
      </svg>
    </div>`}function oe(s,e){return a`
    <div class="insight-sources">
      <ul>
        ${C.repeat(s,t=>t.value,t=>a`<li><devtools-link class="link" title="${O(t.type)} ${c(l.opensInNewTab)}" href="data:text/plain;charset=utf-8,${encodeURIComponent(t.value)}" .jslogContext=${"source-"+t.type}>
            <devtools-icon name="open-externally"></devtools-icon>
            ${O(t.type)}
          </devtools-link></li>`)}
        ${e?a`<li class="source-disclaimer">
          <devtools-icon name="warning"></devtools-icon>
          ${c(l.reloadRecommendation)}</li>`:h.nothing}
      </ul>
    </div>`}function re(s,{renderer:e,disableAnimations:t,areReferenceDetailsOpen:n,highlightedCitationIndex:r,callbacks:d},o){return a`
        ${s.validMarkdown?a`<devtools-markdown-view
            .data=${{tokens:s.tokens,renderer:e,animationEnabled:!t}}>
          </devtools-markdown-view>`:s.explanation}
        ${s.timedOut?a`<p class="error-message">${c(l.timedOut)}</p>`:h.nothing}
        ${G(s.metadata)?a`
          <details
            class="references"
            ?open=${n}
            jslog=${v.expand("references").track({click:!0})}
            @toggle=${d.onToggleReferenceDetails}
            @transitionend=${d.onReferencesOpen}
          >
            <summary>${c(l.references)}</summary>
            ${ie(s.directCitationUrls,r,d.onCitationAnimationEnd,o)}
            ${se(s.relatedUrls,s.directCitationUrls)}
          </details>
        `:h.nothing}
        <details jslog=${v.expand("sources").track({click:!0})}>
          <summary>${c(l.inputData)}</summary>
          ${oe(s.sources,s.isPageReloadRecommended)}
        </details>
        <div class="buttons">
          ${ee(d.onSearch)}
        </div>`}function x(s){return a`<div class="error">${s}</div>`}function ae(s){return a`
    <h3>Things to consider</h3>
    <div class="reminder-items">
      <div>
        <devtools-icon name="google" class="medium">
        </devtools-icon>
      </div>
      <div>The console message, associated stack trace, related source code, and the associated network headers are sent to Google to generate explanations. ${s?"The content you submit and that is generated by this feature will not be used to improve Google\u2019s AI models.":"This data may be seen by human reviewers to improve this feature. Avoid sharing sensitive or personal information."}
      </div>
      <div>
        <devtools-icon name="policy" class="medium">
        </devtools-icon>
      </div>
      <div>Use of this feature is subject to the <devtools-link
          href=${Y}
          class="link"
          jslogcontext="terms-of-service.console-insights">
        Google Terms of Service
        </devtools-link> and <devtools-link
          href=${Q}
          class="link"
          jslogcontext="privacy-policy.console-insights">
        Google Privacy Policy
        </devtools-link>
      </div>
      <div>
        <devtools-icon name="warning" class="medium">
        </devtools-icon>
      </div>
      <div>
        <devtools-link
          href=${K}
          class="link"
          jslogcontext="code-snippets-explainer.console-insights"
        >Use generated code snippets with caution</devtools-link>
      </div>
    </div>`}function le(s){let e=a`
    <button
      class="link" role="link"
      jslog=${v.action("open-ai-settings").track({click:!0})}
      @click=${s}
    >${c(l.settingsLink)}</button>`;return a`
    <div class="badge">
      <devtools-icon name="lightbulb-spark" class="medium">
      </devtools-icon>
    </div>
    <div>
      ${j(l.turnOnInSettings,{PH1:e})} ${te()}
    </div>`}function de(){return x(b.Runtime.hostConfig.isOffTheRecord?c(l.notAvailableInIncognitoMode):c(l.notLoggedIn))}function B(s,e){return a`<span>
    AI tools may generate inaccurate info that doesn't represent Google's views. ${s?"The content you submit and that is generated by this feature will not be used to improve Google\u2019s AI models.":"Data sent to Google may be seen by human reviewers to improve this feature."} <button class="link" role="link" @click=${e}
              jslog=${v.action("open-ai-settings").track({click:!0})}>
      Open settings
    </button> or <devtools-link href=${V}
        class="link" jslogcontext="learn-more">
      learn more
    </devtools-link>
  </span>`}function P(s,e){return a`
    <div class="disclaimer">
      ${B(s,e)}
    </div>`}function ce(s){return b.Runtime.hostConfig.isOffTheRecord?h.nothing:a`
    <div class="filler"></div>
    <div>
      <devtools-button
        @click=${s}
        .variant=${p.Button.Variant.PRIMARY}
        .jslogContext=${"update-settings"}
      >
        ${c(l.signIn)}
      </devtools-button>
    </div>`}function ge(s,e){return a`
    <div class="filler"></div>
    <div class="buttons">
      <devtools-button
        @click=${s}
        .variant=${p.Button.Variant.TONAL}
        .jslogContext=${"settings"}
        .title=${"Settings"}
      >
        Settings
      </devtools-button>
      <devtools-button
        class='continue-button'
        @click=${e}
        .variant=${p.Button.Variant.PRIMARY}
        .jslogContext=${"continue"}
        .title=${"continue"}
      >
        Continue
      </devtools-button>
    </div>`}function ue(s,e,t){return a`
  <div class="disclaimer">
    ${B(s,t.onDisclaimerSettingsLink)}
  </div>
  <div class="filler"></div>
  <div class="rating">
    <devtools-button
      data-rating="true"
      .iconName=${"thumb-up"}
      .toggledIconName=${"thumb-up"}
      .variant=${p.Button.Variant.ICON_TOGGLE}
      .size=${p.Button.Size.SMALL}
      .toggleOnClick=${!1}
      .toggleType=${p.Button.ToggleType.PRIMARY}
      .disabled=${e!==void 0}
      .toggled=${e===!0}
      .title=${c(l.goodResponse)}
      .jslogContext=${"thumbs-up"}
      @click=${()=>t.onRating(!0)}
    ></devtools-button>
    <devtools-button
      data-rating="false"
      .iconName=${"thumb-down"}
      .toggledIconName=${"thumb-down"}
      .variant=${p.Button.Variant.ICON_TOGGLE}
      .size=${p.Button.Size.SMALL}
      .toggleOnClick=${!1}
      .toggleType=${p.Button.ToggleType.PRIMARY}
      .disabled=${e!==void 0}
      .toggled=${e===!1}
      .title=${c(l.badResponse)}
      .jslogContext=${"thumbs-down"}
      @click=${()=>t.onRating(!1)}
    ></devtools-button>
    <devtools-button
      .iconName=${"report"}
      .variant=${p.Button.Variant.ICON}
      .size=${p.Button.Size.SMALL}
      .title=${c(l.report)}
      .jslogContext=${"report"}
      @click=${t.onReport}
    ></devtools-button>
  </div>`}function he(){return a`
    <div class="header-icon-container">
      <devtools-icon name="lightbulb-spark" class="large">
      </devtools-icon>
    </div>`}function T({headerText:s,showIcon:e=!1,showSpinner:t=!1,onClose:n},r){return a`
    <header>
      ${e?he():h.nothing}
      <div class="filler">
        <h2 tabindex="-1" ${C.ref(r)}>
          ${s}
        </h2>
        ${t?a`<devtools-spinner></devtools-spinner>`:h.nothing}
      </div>
      <div class="close-button">
        <devtools-button
          .iconName=${"cross"}
          .variant=${p.Button.Variant.ICON}
          .size=${p.Button.Size.SMALL}
          .title=${c(l.closeInsight)}
          jslog=${v.close().track({click:!0})}
          @click=${n}
        ></devtools-button>
      </div>
    </header>
  `}var pe=(s,e,t)=>{let{state:n,noLogging:r,callbacks:d}=s,{onClose:o,onDisclaimerSettingsLink:f}=d,g=`${v.section(n.type).track({resize:!0})}`,m=h.nothing,u=h.nothing,M={},I;switch(n.type){case"loading":m=T({headerText:c(l.generating),onClose:o},e.headerRef),u=ne();break;case"insight":m=T({headerText:c(l.insight),onClose:o,showSpinner:!n.completed},e.headerRef),u=re(n,s,e),I=ue(r,s.selectedRating,d);break;case"error":m=T({headerText:c(l.error),onClose:o},e.headerRef),u=x(c(l.errorBody)),I=P(r,f);break;case"consent-reminder":m=T({headerText:"Understand console messages with AI",onClose:o,showIcon:!0},e.headerRef),M["reminder-container"]=!0,u=ae(r),I=ge(d.onReminderSettingsLink,d.onConsentReminderConfirmed);break;case"setting-is-not-true":M["opt-in-teaser"]=!0,u=le(d.onEnableInsightsInSettingsLink);break;case"not-logged-in":case"sync-is-paused":m=T({headerText:c(l.signInToUse),onClose:o},e.headerRef),u=de(),I=ce(d.onGoToSignIn);break;case"offline":m=T({headerText:c(l.offlineHeader),onClose:o},e.headerRef),u=x(c(l.offline)),I=P(r,f);break}W(a`
    <style>${N}</style>
    <style>${z.checkboxStyles}</style>
    <div
      class=${C.classMap({wrapper:!0,closing:s.closing})}
      jslog=${v.pane("console-insights").track({resize:!0})}
      @animationend=${d.onAnimationEnd}
      @keydown=${R}
      @keyup=${R}
      @keypress=${R}
      @click=${R}
    >
      <div class="animation-wrapper">
        ${m}
        <main jslog=${g} class=${C.classMap(M)}>
          ${u}
        </main>
        ${I?a`<footer jslog=${v.section("footer")}>
          ${I}
        </footer>`:h.nothing}
      </div>
    </div>
  `,t)},L=class s extends A.Widget.Widget{static async create(e,t){let n=i.AidaClient.HostConfigTracker.instance().aidaAvailability??await i.AidaClient.AidaClient.checkAccessPreconditions();return a`<devtools-widget class="devtools-console-insight" ${q(r=>new s(e,t,n,r))}>
    </devtools-widget>`}disableAnimations=!1;#v;#o;#d;#c;#e;#f=C.createRef();#y=[];#s=-1;#r=!1;#b=!1;#g=!1;#n;#t;#a;#u;#I;constructor(e,t,n,r,d=pe){super(r),this.#v=d,this.#o=e,this.#d=t,this.#a=n,this.#t=this.#S(),this.#c=new D.MarkdownView.MarkdownInsightRenderer(this.#h.bind(this)),this.#I=new U.Marked.Marked({extensions:[Z]}),this.#e=this.#p(),this.#u=this.#w.bind(this),this.requestUpdate()}#h(e){if(this.#e.type!=="insight")return;let t=this.#r;this.#r=!0,this.#s=e-1,this.requestUpdate(),t&&this.#k()}#k(){let e=this.#y[this.#s];e&&(e.scrollIntoView({behavior:"auto"}),e.focus())}#p(){switch(this.#a){case i.AidaClient.AidaAccessPreconditions.AVAILABLE:{let e=S.Settings.Settings.instance().createSetting("console-insights-skip-reminder",!1,S.Settings.SettingStorageType.SESSION).get();return{type:"loading",consentOnboardingCompleted:this.#m().get()||e}}case i.AidaClient.AidaAccessPreconditions.NO_ACCOUNT_EMAIL:return{type:"not-logged-in"};case i.AidaClient.AidaAccessPreconditions.SYNC_IS_PAUSED:return{type:"sync-is-paused"};case i.AidaClient.AidaAccessPreconditions.NO_INTERNET:return{type:"offline"}}}#S(){return new k.AiSetting.AiSetting(k.AiUtils.consoleInsightsEnabledSettingDescriptor,i.AidaClient.HostConfigTracker.instance(),S.Settings.Settings.instance())}#m(){return S.Settings.Settings.instance().createLocalSetting("console-insights-onboarding-finished",!1)}wasShown(){super.wasShown(),this.focus(),this.#t.addEventListener(k.AiSetting.Events.CHANGED,this.#C,this);let e=b.Runtime.hostConfig.aidaAvailability?.blockedByAge===!0;this.#e.type==="loading"&&this.#t?.getIfNotDisabled()===!0&&!e&&this.#e.consentOnboardingCompleted&&i.userMetrics.actionTaken(i.UserMetrics.Action.GeneratingInsightWithoutDisclaimer),i.AidaClient.HostConfigTracker.instance().addEventListener(i.AidaClient.Events.AIDA_AVAILABILITY_CHANGED,this.#u);let t=i.AidaClient.HostConfigTracker.instance().aidaAvailability;t!==void 0&&this.#A(t),this.#e.type!=="insight"&&this.#e.type!=="error"&&(this.#e=this.#p()),this.#l()}willHide(){super.willHide(),this.#t.removeEventListener(k.AiSetting.Events.CHANGED,this.#C,this),i.AidaClient.HostConfigTracker.instance().removeEventListener(i.AidaClient.Events.AIDA_AVAILABILITY_CHANGED,this.#u)}#A(e){e!==this.#a&&(this.#a=e,this.#e=this.#p(),this.#l())}#w(e){this.#A(e.data)}#C(){this.#t?.getIfNotDisabled()===!0&&this.#m().set(!0),this.#e.type==="setting-is-not-true"&&this.#t?.getIfNotDisabled()===!0&&(this.#i({type:"loading",consentOnboardingCompleted:!0}),i.userMetrics.actionTaken(i.UserMetrics.Action.InsightsOptInTeaserConfirmedInSettings),this.#l()),this.#e.type==="consent-reminder"&&this.#t?.getIfNotDisabled()===!1&&(this.#i({type:"loading",consentOnboardingCompleted:!1}),i.userMetrics.actionTaken(i.UserMetrics.Action.InsightsReminderTeaserAbortedInSettings),this.#l())}#i(e){this.#b=this.#e.type!==e.type,this.#e=e,this.requestUpdate()}async#l(){if(this.#e.type!=="loading")return;let e=b.Runtime.hostConfig.aidaAvailability?.blockedByAge===!0;if(this.#t?.getIfNotDisabled()!==!0||e){this.#i({type:"setting-is-not-true"}),i.userMetrics.actionTaken(i.UserMetrics.Action.InsightsOptInTeaserShown);return}if(!this.#e.consentOnboardingCompleted){let{sources:t,isPageReloadRecommended:n}=await this.#o.buildPrompt();this.#i({type:"consent-reminder",sources:t,isPageReloadRecommended:n}),i.userMetrics.actionTaken(i.UserMetrics.Action.InsightsReminderTeaserShown);return}await this.#T()}#R(){this.#e.type==="consent-reminder"&&i.userMetrics.actionTaken(i.UserMetrics.Action.InsightsReminderTeaserCanceled),this.#g=!0,this.requestUpdate()}#L(){if(this.#g){this.contentElement.dispatchEvent(new H);return}this.#b&&this.#f.value?.focus()}#E(){this.#s!==-1&&(this.#s=-1,this.requestUpdate())}#M(e){if(this.#e.type!=="insight")throw new Error("Unexpected state");if(this.#e.metadata?.rpcGlobalId===void 0)throw new Error("RPC Id not in metadata");if(this.#n!==void 0)return;this.#n=e,this.requestUpdate(),this.#n?i.userMetrics.actionTaken(i.UserMetrics.Action.InsightRatedPositive):i.userMetrics.actionTaken(i.UserMetrics.Action.InsightRatedNegative);let t=b.Runtime.hostConfig.aidaAvailability?.disallowLogging??!0;return this.#d.registerClientEvent({corresponding_aida_rpc_global_id:this.#e.metadata.rpcGlobalId,disable_user_content_logging:t,do_conversation_client_event:{user_feedback:{sentiment:this.#n?i.AidaClient.Rating.POSITIVE:i.AidaClient.Rating.NEGATIVE}}})}#H(){i.InspectorFrontendHost.InspectorFrontendHostInstance.openInNewTab(k.AiUtils.REPORT_LEGAL_ISSUE_URL)}#x(){let e=this.#o.getSearchQuery();i.InspectorFrontendHost.InspectorFrontendHostInstance.openSearchResultsInNewTab(e)}async#$(){this.#m().set(!0),this.#i({type:"loading",consentOnboardingCompleted:!0}),i.userMetrics.actionTaken(i.UserMetrics.Action.InsightsReminderTeaserConfirmed),await this.#T()}#N(e,t){let n=[];if(!G(t)||!t.attributionMetadata)return{explanationWithCitations:e,directCitationUrls:n};let{attributionMetadata:r}=t,d=r.citations.filter(f=>f.sourceType===i.AidaClient.CitationSourceType.WORLD_FACTS).sort((f,g)=>(g.endIndex||0)-(f.endIndex||0)),o=e;for(let[f,g]of d.entries()){let m=/[.,:;!?]*\s/g;m.lastIndex=g.endIndex||0;let u=m.exec(o);u&&g.uri&&(o=o.slice(0,u.index)+`[^${d.length-f}]`+o.slice(u.index),n.push(g.uri))}return n.reverse(),{explanationWithCitations:o,directCitationUrls:n}}#O(e){for(let t of e)if(t.type==="code"){let n=t.text.match(/\[\^\d+\]/g);if(t.text=t.text.replace(/\[\^\d+\]/g,""),n?.length){let r=n.map(d=>{let o=parseInt(d.slice(2,-1),10);return{index:o,clickHandler:this.#h.bind(this,o)}});t.citations=r}}}#P(e,t){if(!t.factualityMetadata?.facts.length)return[];let n=t.factualityMetadata.facts.filter(o=>o.sourceUri&&!e.includes(o.sourceUri)).map(o=>o.sourceUri)||[],r=t.attributionMetadata?.citations.filter(o=>o.sourceType===i.AidaClient.CitationSourceType.TRAINING_DATA&&(o.uri||o.repository)).map(o=>o.uri||`https://www.github.com/${o.repository}`)||[],d=[...new Set(r.filter(o=>!n.includes(o)&&!e.includes(o)))];return n.push(...d),n}async#T(){try{for await(let{sources:e,isPageReloadRecommended:t,explanation:n,metadata:r,completed:d}of this.#z()){let{explanationWithCitations:o,directCitationUrls:f}=this.#N(n,r),g=this.#P(f,r),m=this.#U(o),u=m!==!1;u&&this.#O(m),this.#i({type:"insight",tokens:u?m:[],validMarkdown:u,explanation:n,sources:e,metadata:r,isPageReloadRecommended:t,completed:d,directCitationUrls:f,relatedUrls:g})}i.userMetrics.actionTaken(i.UserMetrics.Action.InsightGenerated)}catch(e){console.error("[ConsoleInsight] Error in #generateInsight:",e),i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErrored),e.message==="doAidaConversation timed out"&&this.#e.type==="insight"?(this.#e.timedOut=!0,this.#i({...this.#e,completed:!0,timedOut:!0})):this.#i({type:"error",error:e.message})}}#U(e){try{let t=this.#I.lexer(e);for(let n of t)this.#c.renderToken(n);return t}catch{return i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErroredMarkdown),!1}}async*#z(){let{prompt:e,sources:t,isPageReloadRecommended:n}=await this.#o.buildPrompt();try{for await(let r of this.#d.doConversation(i.AidaClient.AidaClient.buildConsoleInsightsRequest(e)))yield{sources:t,isPageReloadRecommended:n,...r}}catch(r){throw r.message==="Server responded: permission denied"?i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErroredPermissionDenied):r.message.startsWith("Cannot send request:")?i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErroredCannotSend):r.message.startsWith("Request failed:")?i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErroredRequestFailed):r.message.startsWith("Cannot parse chunk:")?i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErroredCannotParseChunk):r.message==="Unknown chunk result"?i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErroredUnknownChunk):r.message.startsWith("Server responded:")?i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErroredApi):i.userMetrics.actionTaken(i.UserMetrics.Action.InsightErroredOther),r}}#D(){i.InspectorFrontendHost.InspectorFrontendHostInstance.openInNewTab(J)}#_(e){let t=e.target;t&&(this.#r=t.open,t.open||(this.#s=-1),this.requestUpdate())}#V(){A.ViewManager.ViewManager.instance().showView("chrome-ai")}#G(){i.userMetrics.actionTaken(i.UserMetrics.Action.InsightsReminderTeaserSettingsLinkClicked),A.ViewManager.ViewManager.instance().showView("chrome-ai")}#B(){i.userMetrics.actionTaken(i.UserMetrics.Action.InsightsOptInTeaserSettingsLinkClicked),A.ViewManager.ViewManager.instance().showView("chrome-ai")}performUpdate(){let e={state:this.#e,closing:this.#g,disableAnimations:this.disableAnimations,renderer:this.#c,citationClickHandler:this.#h.bind(this),selectedRating:this.#n,noLogging:b.Runtime.hostConfig.aidaAvailability?.enterprisePolicyValue===b.Runtime.GenAiEnterprisePolicyValue.ALLOW_WITHOUT_LOGGING,areReferenceDetailsOpen:this.#r,highlightedCitationIndex:this.#s,callbacks:{onClose:this.#R.bind(this),onAnimationEnd:this.#L.bind(this),onCitationAnimationEnd:this.#E.bind(this),onSearch:this.#x.bind(this),onRating:this.#M.bind(this),onReport:this.#H.bind(this),onGoToSignIn:this.#D.bind(this),onConsentReminderConfirmed:this.#$.bind(this),onToggleReferenceDetails:this.#_.bind(this),onDisclaimerSettingsLink:this.#V.bind(this),onReminderSettingsLink:this.#G.bind(this),onEnableInsightsInSettingsLink:this.#B.bind(this),onReferencesOpen:this.#k.bind(this)}},t={headerRef:this.#f,citationLinks:[]};this.#v(e,t,this.contentElement),this.#y=t.citationLinks}};import*as y from"../../core/host/host.js";import*as E from"../console/console.js";var F=class{handleAction(e,t){switch(t){case"explain.console-message.context":case"explain.console-message.context.error":case"explain.console-message.context.warning":case"explain.console-message.context.other":case"explain.console-message.teaser":case"explain.console-message.hover":{let n=e.flavor(E.ConsoleViewMessage.ConsoleViewMessage);if(n){t.startsWith("explain.console-message.context")?y.userMetrics.actionTaken(y.UserMetrics.Action.InsightRequestedViaContextMenu):t==="explain.console-message.teaser"?y.userMetrics.actionTaken(y.UserMetrics.Action.InsightRequestedViaTeaser):t==="explain.console-message.hover"&&y.userMetrics.actionTaken(y.UserMetrics.Action.InsightRequestedViaHoverButton);let r=new E.PromptBuilder.PromptBuilder(n),d=new y.AidaClient.AidaClient;return L.create(r,d).then(o=>{n.setInsight(o)}),!0}return!1}}return!1}};export{F as ActionDelegate,H as CloseEvent,L as ConsoleInsight,pe as DEFAULT_VIEW,X as State};
//# sourceMappingURL=explain.js.map
