var kt=Object.defineProperty;var K=(i,e)=>{for(var t in e)kt(i,t,{get:e[t],enumerable:!0})};var De={};K(De,{CSSOverviewUnusedDeclarations:()=>z});import*as ge from"../../core/i18n/i18n.js";var N={topAppliedToAStatically:"`Top` applied to a statically positioned element",leftAppliedToAStatically:"`Left` applied to a statically positioned element",rightAppliedToAStatically:"`Right` applied to a statically positioned element",bottomAppliedToAStatically:"`Bottom` applied to a statically positioned element",widthAppliedToAnInlineElement:"`Width` applied to an inline element",heightAppliedToAnInlineElement:"`Height` applied to an inline element",verticalAlignmentAppliedTo:"Vertical alignment applied to element which is neither `inline` nor `table-cell`"},$t=ge.i18n.registerUIStrings("panels/css_overview/CSSOverviewUnusedDeclarations.ts",N),E=ge.i18n.getLocalizedString.bind(void 0,$t),z=class{static#t(e,t,o){let r=e.get(t)||[];r.push(o),e.set(t,r)}static checkForUnusedPositionValues(e,t,o,r,s,n,a,c){if(o[r]==="static"){if(o[s]!=="auto"){let p=E(N.topAppliedToAStatically);this.#t(e,p,{declaration:`top: ${o[s]}`,nodeId:t})}if(o[n]!=="auto"){let p=E(N.leftAppliedToAStatically);this.#t(e,p,{declaration:`left: ${o[n]}`,nodeId:t})}if(o[a]!=="auto"){let p=E(N.rightAppliedToAStatically);this.#t(e,p,{declaration:`right: ${o[a]}`,nodeId:t})}if(o[c]!=="auto"){let p=E(N.bottomAppliedToAStatically);this.#t(e,p,{declaration:`bottom: ${o[c]}`,nodeId:t})}}}static checkForUnusedWidthAndHeightValues(e,t,o,r,s,n){if(o[r]==="inline"){if(o[s]!=="auto"){let a=E(N.widthAppliedToAnInlineElement);this.#t(e,a,{declaration:`width: ${o[s]}`,nodeId:t})}if(o[n]!=="auto"){let a=E(N.heightAppliedToAnInlineElement);this.#t(e,a,{declaration:`height: ${o[n]}`,nodeId:t})}}}static checkForInvalidVerticalAlignment(e,t,o,r,s){if(!(!o[r]||o[r].startsWith("inline")||o[r].startsWith("table"))&&o[s]!=="baseline"){let n=E(N.verticalAlignmentAppliedTo);this.#t(e,n,{declaration:`vertical-align: ${o[s]}`,nodeId:t})}}};var Pe={};K(Pe,{CSSOverviewModel:()=>W});import*as P from"../../core/common/common.js";import*as R from"../../core/sdk/sdk.js";import*as Te from"../../ui/legacy/components/color_picker/color_picker.js";var W=class extends R.SDKModel.SDKModel{#t;#o;#s;constructor(e){super(e),this.#t=e.runtimeAgent(),this.#o=e.cssAgent(),this.#s=e.domsnapshotAgent()}async getNodeStyleStats(){let e=new Map,t=new Map,o=new Map,r=new Map,s=new Map,n=new Map,a=new Map,c={computedStyles:["background-color","color","fill","border-top-width","border-top-color","border-bottom-width","border-bottom-color","border-left-width","border-left-color","border-right-width","border-right-color","font-family","font-size","font-weight","line-height","position","top","right","bottom","left","display","width","height","vertical-align"],includeTextColorOpacities:!0,includeBlendedBackgroundColors:!0},p=v=>v instanceof P.Color.Legacy?v.hasAlpha()?v.asString(P.Color.Format.HEXA):v.asString(P.Color.Format.HEX):v.asString(),h=(v,f,C)=>{if(v===-1)return;let ee=m[v];if(!ee)return;let V=P.Color.parse(ee);if(!V||V.asLegacyColor().rgba()[3]===0)return;let g=p(V);if(!g)return;let L=C.get(g)||new Set;return L.add(f),C.set(g,L),V},I=v=>new Set(["altglyph","circle","ellipse","path","polygon","polyline","rect","svg","text","textpath","tref","tspan"]).has(v.toLowerCase()),Q=v=>new Set(["iframe","video","embed","img"]).has(v.toLowerCase()),ue=(v,f)=>new Set(["tr","td","thead","tbody"]).has(v.toLowerCase())&&f.startsWith("table"),Z=0,{documents:at,strings:m}=await this.#s.invoke_captureSnapshot(c);for(let{nodes:v,layout:f}of at){Z+=f.nodeIndex.length;for(let C=0;C<f.styles.length;C++){let ee=f.styles[C],V=f.nodeIndex[C];if(!v.backendNodeId||!v.nodeName)continue;let g=v.backendNodeId[V],L=v.nodeName[V],[lt,dt,ct,ut,pt,mt,vt,gt,ht,ft,wt,pe,te,oe,ke,bt,St,yt,Ct,xt,me,It,Mt,$e]=ee;h(lt,g,e);let ve=h(dt,g,t);if(I(m[L])&&h(ct,g,r),m[ut]!=="0px"&&h(pt,g,s),m[mt]!=="0px"&&h(vt,g,s),m[gt]!=="0px"&&h(ht,g,s),m[ft]!=="0px"&&h(wt,g,s),pe&&pe!==-1){let $=m[pe],y=n.get($)||new Map,se="font-size",ie="font-weight",D="line-height",x=y.get(se)||new Map,T=y.get(ie)||new Map,M=y.get(D)||new Map;if(te!==-1){let b=m[te],A=x.get(b)||[];A.push(g),x.set(b,A)}if(oe!==-1){let b=m[oe],A=T.get(b)||[];A.push(g),T.set(b,A)}if(ke!==-1){let b=m[ke],A=M.get(b)||[];A.push(g),M.set(b,A)}y.set(se,x),y.set(ie,T),y.set(D,M),n.set($,y)}let G=ve&&f.blendedBackgroundColors&&f.blendedBackgroundColors[C]!==-1?P.Color.parse(m[f.blendedBackgroundColors[C]]):null;if(ve&&G){let $=new Te.ContrastInfo.ContrastInfo({backgroundColors:[G.asString(P.Color.Format.HEXA)],computedFontSize:te!==-1?m[te]:"",computedFontWeight:oe!==-1?m[oe]:""}),y=ve.asLegacyColor().blendWithAlpha(f.textColorOpacities?f.textColorOpacities[C]:1);$.setColor(y);let se=p(y),ie=p(G.asLegacyColor()),D=`${se}_${ie}`;if(P.Settings.Settings.instance().resolve(R.SDKSettings.apcaSettingDescriptor).get()){let x=$.contrastRatioAPCA(),T=$.contrastRatioAPCAThreshold();if(!(x&&T?Math.abs(x)>=T:!1)&&x){let b={nodeId:g,contrastRatio:x,textColor:y,backgroundColor:G,thresholdsViolated:{aa:!1,aaa:!1,apca:!0}};o.has(D)?o.get(D).push(b):o.set(D,[b])}}else{let x=$.contrastRatioThreshold("aa")||0,T=$.contrastRatioThreshold("aaa")||0,M=$.contrastRatio()||0;if(x>M||T>M){let b={nodeId:g,contrastRatio:M,textColor:y,backgroundColor:G,thresholdsViolated:{aa:x>M,aaa:T>M,apca:!1}};o.has(D)?o.get(D).push(b):o.set(D,[b])}}}z.checkForUnusedPositionValues(a,g,m,bt,St,xt,yt,Ct),!I(m[L])&&!Q(m[L])&&z.checkForUnusedWidthAndHeightValues(a,g,m,me,It,Mt),$e!==-1&&!ue(m[L],m[me])&&z.checkForInvalidVerticalAlignment(a,g,m,me,$e)}}return{backgroundColors:e,textColors:t,textColorContrastIssues:o,fillColors:r,borderColors:s,fontInfo:n,unusedDeclarations:a,elementCount:Z}}getComputedStyleForNode(e){return this.#o.invoke_getComputedStyleForNode({nodeId:e})}async getMediaQueries(){let e=await this.#o.invoke_getMediaQueries(),t=new Map;if(!e)return t;for(let o of e.medias){if(o.source==="linkedSheet")continue;let r=t.get(o.text)||[];r.push(o),t.set(o.text,r)}return t}async getGlobalStylesheetStats(){let e=`(function() {
      let styleRules = 0;
      let inlineStyles = 0;
      let externalSheets = 0;
      const stats = {
        // Simple.
        type: new Set(),
        class: new Set(),
        id: new Set(),
        universal: new Set(),
        attribute: new Set(),

        // Non-simple.
        nonSimple: new Set()
      };

      for (const styleSheet of document.styleSheets) {
        if (styleSheet.href) {
          externalSheets++;
        } else {
          inlineStyles++;
        }

        // Attempting to grab rules can trigger a DOMException.
        // Try it and if it fails skip to the next stylesheet.
        let rules;
        try {
          rules = styleSheet.rules;
        } catch (err) {
          continue;
        }

        for (const rule of rules) {
          if ('selectorText' in rule) {
            styleRules++;

            // Each group that was used.
            for (const selectorGroup of rule.selectorText.split(',')) {
              // Each selector in the group.
              for (const selector of selectorGroup.split(/[\\t\\n\\f\\r ]+/g)) {
                if (selector.startsWith('.')) {
                  // Class.
                  stats.class.add(selector);
                } else if (selector.startsWith('#')) {
                  // Id.
                  stats.id.add(selector);
                } else if (selector.startsWith('*')) {
                  // Universal.
                  stats.universal.add(selector);
                } else if (selector.startsWith('[')) {
                  // Attribute.
                  stats.attribute.add(selector);
                } else {
                  // Type or non-simple selector.
                  const specialChars = /[#.:\\[\\]|\\+>~]/;
                  if (specialChars.test(selector)) {
                    stats.nonSimple.add(selector);
                  } else {
                    stats.type.add(selector);
                  }
                }
              }
            }
          }
        }
      }

      return {
        styleRules,
        inlineStyles,
        externalSheets,
        stats: {
          // Simple.
          type: stats.type.size,
          class: stats.class.size,
          id: stats.id.size,
          universal: stats.universal.size,
          attribute: stats.attribute.size,

          // Non-simple.
          nonSimple: stats.nonSimple.size
        }
      }
    })()`,{result:t}=await this.#t.invoke_evaluate({expression:e,returnByValue:!0});if(t.type==="object")return t.value}};R.SDKModel.SDKModel.register(W,{capabilities:R.Target.Capability.DOM,autostart:!1});var Le={};K(Le,{CSSOverviewProcessingView:()=>X,DEFAULT_VIEW:()=>Ve});import*as he from"../../core/i18n/i18n.js";import*as Ne from"../../ui/components/buttons/buttons.js";import*as Ue from"../../ui/legacy/legacy.js";import{html as Dt,render as Tt}from"../../ui/lit/lit.js";var Ae=`.overview-processing-view{overflow:hidden;padding:var(--sys-size-8);justify-content:center;align-items:center;height:100%}.overview-processing-view h1{font-size:var(--sys-typescale-body1-size);text-align:center;font-weight:normal;margin:0;padding:var(--sys-size-5)}.overview-processing-view h2{font-size:var(--sys-typescale-body4-size);text-align:center;font-weight:normal;margin:0;padding-top:var(--sys-size-13)}
/*# sourceURL=${import.meta.resolve("./cssOverviewProcessingView.css")} */`;var Oe={cancel:"Cancel"},Pt=he.i18n.registerUIStrings("panels/css_overview/CSSOverviewProcessingView.ts",Oe),At=he.i18n.getLocalizedString.bind(void 0,Pt),Ve=(i,e,t)=>{Tt(Dt`
    <style>${Ae}</style>
    <div style="overflow:auto">
      <div class="vbox overview-processing-view">
        <h1>Processing page</h1>
        <div>
          <devtools-button
              @click=${i.onCancel}
              .jslogContext=${"css-overview.cancel-processing"}
              .variant=${Ne.Button.Variant.OUTLINED}>${At(Oe.cancel)}</devtools-button>
        </div>
      </div>
    </div>`,t)},X=class extends Ue.Widget.Widget{#t=()=>{};#o;constructor(e,t=Ve){super(e),this.#o=t,this.requestUpdate()}set onCancel(e){this.#t=e,this.requestUpdate()}performUpdate(){this.#o({onCancel:this.#t},void 0,this.element)}};var et={};K(et,{CSSOverviewCompletedView:()=>F,DEFAULT_VIEW:()=>Je,ELEMENT_DETAILS_DEFAULT_VIEW:()=>Ze,ElementDetailsView:()=>ne});import"../../ui/legacy/components/data_grid/data_grid.js";import"../../ui/kit/kit.js";import*as S from"../../core/common/common.js";import*as Se from"../../core/i18n/i18n.js";import*as qe from"../../core/platform/platform.js";import*as U from"../../core/sdk/sdk.js";import*as je from"../../core/text_utils/text_utils.js";import*as Qe from"../../ui/geometry/geometry.js";import*as Ge from"../../ui/legacy/components/utils/utils.js";import*as B from"../../ui/legacy/legacy.js";import{Directives as Lt,html as u,nothing as k,render as Xe}from"../../ui/lit/lit.js";import*as w from"../../ui/visual_logging/visual_logging.js";import*as Ye from"../common/common.js";var fe=`@scope to (devtools-widget > *){.overview-completed-view{overflow:auto;--overview-default-padding:var(--sys-size-12);--overview-icon-padding:var(--sys-size-13)}.overview-completed-view .summary ul,
  .overview-completed-view .colors ul{display:flex;flex-wrap:wrap;list-style:none;margin:0;padding:0}.overview-completed-view .summary ul{display:grid;grid-template-columns:repeat(auto-fill,140px);gap:var(--sys-size-8)}.overview-completed-view .colors ul li{display:inline-block;margin:0 0 var(--sys-size-8);padding:0 var(--sys-size-5) 0 0}.overview-completed-view .summary ul li{display:flex;flex-direction:column;grid-column-start:auto}.overview-completed-view li .label{font-size:var(--sys-typescale-body4-size);padding-bottom:var(--sys-size-2)}.overview-completed-view li .value{font-size:17px}.overview-completed-view ul li span{font-weight:bold}.unused-rules-grid .header-container,
  .unused-rules-grid .data-container,
  .unused-rules-grid table.data{position:relative}.unused-rules-grid .data-container{top:0;max-height:350px}.unused-rules-grid{border-left:none;border-right:none}.unused-rules-grid .monospace{display:block;height:18px}.element-grid{flex:1;border-left:none;border-right:none;overflow:auto}.block{width:65px;height:25px;border-radius:3px;margin-right:var(--sys-size-8);&:focus-visible{outline:var(--sys-size-2) solid var(--sys-color-state-focus-ring);outline-offset:var(--sys-size-2)}}.block-title{padding-top:var(--sys-size-3);font-size:var(--sys-typescale-body4-size);color:var(--sys-color-on-surface);letter-spacing:0;text-transform:uppercase}.block-title.color-text{text-transform:none;max-width:65px;text-overflow:ellipsis;white-space:nowrap;cursor:text;user-select:text;overflow:hidden}.results-section{flex-shrink:0;border-bottom:var(--sys-size-1) solid var(--sys-color-divider);padding:var(--overview-default-padding) 0 var(--overview-default-padding) 0}.horizontally-padded{padding-left:var(--overview-default-padding);padding-right:var(--overview-default-padding)}.results-section h1{font-size:15px;font-weight:normal;padding:0;margin:0 0 var(--sys-size-9);padding-left:calc(var(--overview-default-padding) + var(--overview-icon-padding));position:relative;height:26px;line-height:26px}.results-section h1::before{content:"";display:block;position:absolute;left:var(--overview-default-padding);top:0;width:26px;height:26px;background-image:var(--image-file-cssoverview_icons_2x);background-size:104px 26px}.results-section.horizontally-padded h1{padding-left:var(--overview-icon-padding)}.results-section.horizontally-padded h1::before{left:0}.results-section.summary h1{padding-left:0}.results-section.summary h1::before{display:none}.results-section.colors h1::before{background-position:0 0}.results-section.font-info h1::before{background-position:-26px 0}.results-section.unused-declarations h1::before{background-position:-52px 0}.results-section.media-queries h1::before{background-position:-78px 0}.results-section.colors h2{margin-top:var(--sys-size-9);font-size:var(--sys-typescale-body3-size);font-weight:normal}.overview-completed-view .font-info ul,
  .overview-completed-view .media-queries ul,
  .overview-completed-view .unused-declarations ul{width:100%;list-style:none;margin:0;padding:0 var(--overview-default-padding)}.overview-completed-view .font-info ul li,
  .overview-completed-view .media-queries ul li,
  .overview-completed-view .unused-declarations ul li{display:grid;grid-template-columns:2fr 3fr;gap:var(--sys-size-6);margin-bottom:var(--sys-size-3);align-items:center}.overview-completed-view .font-info button .details,
  .overview-completed-view .media-queries button .details,
  .overview-completed-view .unused-declarations button .details{min-width:100px;text-align:right;margin-right:var(--sys-size-5);color:var(--sys-color-primary);pointer-events:none}.overview-completed-view .font-info button .bar-container,
  .overview-completed-view .media-queries button .bar-container,
  .overview-completed-view .unused-declarations button .bar-container{flex:1;pointer-events:none}.overview-completed-view .font-info button .bar,
  .overview-completed-view .media-queries button .bar,
  .overview-completed-view .unused-declarations button .bar{height:var(--sys-size-5);background:var(--sys-color-primary-bright);border-radius:var(--sys-size-2);min-width:var(--sys-size-2)}.overview-completed-view .font-info button,
  .overview-completed-view .media-queries button,
  .overview-completed-view .unused-declarations button{border:none;padding:0;padding-right:10px;margin:0;display:flex;align-items:center;border-radius:var(--sys-size-2);cursor:pointer;height:var(--sys-size-12);background:none;&:focus-visible{outline:var(--sys-size-2) solid var(--sys-color-state-focus-ring)}&:hover{border-radius:var(--sys-shape-corner-medium-small);background:var(--sys-color-state-hover-on-subtle)}&:hover .details,
    &:focus .details{color:color-mix(in srgb,var(--sys-color-primary),var(--sys-color-state-hover-on-prominent) 6%)}&:hover .bar,
    &:focus .bar{background-color:color-mix(in srgb,var(--sys-color-primary-bright),var(--sys-color-state-hover-on-prominent) 6%);color:var(--sys-color-on-primary)}}.overview-completed-view .font-info .font-metric{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:var(--sys-size-6)}.overview-completed-view .font-info ul{padding:0}.overview-completed-view .font-info ul li{grid-template-columns:1fr 4fr}.overview-completed-view .font-info h2{font-size:var(--sys-typescale-body2-size);font-weight:bold;margin:0 0 1em}.overview-completed-view .font-info h3{font-size:var(--sys-typescale-body3-size);font-weight:normal;font-style:italic;margin:0 0 0.5em}.overview-completed-view .font-info{padding-bottom:0}.overview-completed-view .font-family{padding:var(--overview-default-padding)}.overview-completed-view .font-family:nth-child(2n+1){background:var(--sys-color-cdt-base-container)}.overview-completed-view .font-family:first-of-type{padding-top:0}.contrast-warning{display:flex;align-items:center;margin-top:var(--sys-size-2)}.contrast-warning .threshold-label{font-weight:normal;width:30px}.contrast-warning devtools-icon{margin-left:var(--sys-size-2)}.contrast-preview{padding:0 5px}.contrast-container-in-grid{display:flex;align-items:center}.contrast-container-in-grid > *{margin-right:5px;min-width:initial}::part(node-id-column){align-items:center;height:var(--sys-size-9);--show-element-display:none}::part(node-id-column):focus,
  ::part(node-id-column):hover{--show-element-display:inline-block}::part(show-element){display:var(--show-element-display);height:var(--sys-size-8);width:var(--sys-size-8)}.results-section.colors{forced-color-adjust:none}}
/*# sourceURL=${import.meta.resolve("./cssOverviewCompletedView.css")} */`;var We={};K(We,{CSSOverviewSidebarPanel:()=>Y,DEFAULT_VIEW:()=>Ke});import"../../ui/legacy/legacy.js";import*as be from"../../core/i18n/i18n.js";import*as Be from"../../ui/components/buttons/buttons.js";import*as Fe from"../../ui/legacy/legacy.js";import{Directives as Nt,html as ze,render as Ut}from"../../ui/lit/lit.js";import*as He from"../../ui/visual_logging/visual_logging.js";var Ee=`@scope to (devtools-widget > *){.overview-sidebar-panel{display:flex;background:var(--sys-color-cdt-base-container);min-width:fit-content;flex-direction:column}.overview-sidebar-panel-item{height:30px;padding-left:30px;display:flex;align-items:center;color:var(--sys-color-on-surface);white-space:nowrap;&:hover{background:var(--sys-color-state-hover-on-subtle)}&:focus{background:var(--sys-color-state-focus-highlight)}&.selected{background:var(--sys-color-tonal-container);color:var(--sys-color-on-tonal-container)}}.overview-toolbar{border-bottom:var(--sys-size-1) solid var(--sys-color-divider);flex:0 0 auto}.overview-sidebar-panel-item:focus-visible{outline-width:unset}@media (forced-colors: active){.overview-sidebar-panel-item.selected{forced-color-adjust:none;background:Highlight;color:HighlightText}.overview-sidebar-panel-item:hover{forced-color-adjust:none;background:Highlight;color:HighlightText}}}
/*# sourceURL=${import.meta.resolve("./cssOverviewSidebarPanel.css")} */`;var{classMap:Ot}=Nt,we={clearOverview:"Clear overview",cssOverviewPanelSidebar:"CSS overview panel sidebar"},Vt=be.i18n.registerUIStrings("panels/css_overview/CSSOverviewSidebarPanel.ts",we),Re=be.i18n.getLocalizedString.bind(void 0,Vt),Ke=(i,e,t)=>{Ut(ze`
      <style>${Ee}</style>
      <div class="overview-sidebar-panel" @click=${s=>{if(s.target instanceof HTMLElement){let n=s.target.dataset.id;n&&i.onItemClick(n)}}} @keydown=${s=>{if(!(s.key!=="Enter"&&s.key!=="ArrowUp"&&s.key!=="ArrowDown")){if(s.target instanceof HTMLElement){let n=s.target.dataset.id;n&&i.onItemKeyDown(n,s.key)}s.consume(!0)}}}
           aria-label=${Re(we.cssOverviewPanelSidebar)} role="tree">
        <div class="overview-toolbar">
          <devtools-toolbar>
            <devtools-button title=${Re(we.clearOverview)} @click=${i.onReset}
                .iconName=${"clear"} .variant=${Be.Button.Variant.TOOLBAR}
                .jslogContext=${"css-overview.clear-overview"}></devtools-button>
          </devtools-toolbar>
        </div>
        ${i.items.map(({id:s,name:n})=>{let a=s===i.selectedId;return ze`
            <div class="overview-sidebar-panel-item ${Ot({selected:a})}"
                ?autofocus=${a}
                role="treeitem" data-id=${s} tabindex="0"
                jslog=${He.item(`css-overview.${s}`).track({click:!0,keydown:"Enter|ArrowUp|ArrowDown"})}>
              ${n}
            </div>`})}
      </div>`,t)},Y=class extends Fe.Widget.VBox{#t;#o=[];#s;#i=(e,t)=>{};#r=()=>{};constructor(e,t=Ke){super(e,{useShadowDom:!0,delegatesFocus:!0}),this.#t=t}performUpdate(){let e={items:this.#o,selectedId:this.#s,onReset:this.#r,onItemClick:this.#a.bind(this),onItemKeyDown:this.#n.bind(this)};this.#t(e,void 0,this.contentElement)}set items(e){this.#o=e,this.requestUpdate()}set selectedId(e){this.#e(e)}set onItemSelected(e){this.#i=e,this.requestUpdate()}set onReset(e){this.#r=e,this.requestUpdate()}#e(e,t=!1){return this.#s=e,this.requestUpdate(),this.#i(e,t),this.updateComplete}#a(e){this.#e(e,!1)}#n(e,t){if(t==="Enter")this.#e(e,!0);else{let o=-1;for(let a=0;a<this.#o.length;a++)if(this.#o[a].id===e){o=a;break}if(o<0)return;let s=(o+(t==="ArrowDown"?1:-1))%this.#o.length,n=this.#o[s].id;if(!n)return;this.#e(n,!1).then(()=>{this.element.blur(),this.element.focus()})}}};var{styleMap:ae,ref:J}=Lt,{widget:_e}=B.Widget,l={overviewSummary:"Overview summary",colors:"Colors",fontInfo:"Font info",unusedDeclarations:"Unused declarations",mediaQueries:"Media queries",elements:"Elements",externalStylesheets:"External stylesheets",inlineStyleElements:"Inline style elements",styleRules:"Style rules",typeSelectors:"Type selectors",idSelectors:"ID selectors",classSelectors:"Class selectors",universalSelectors:"Universal selectors",attributeSelectors:"Attribute selectors",nonsimpleSelectors:"Non-simple selectors",backgroundColorsS:"Background colors: {PH1}",textColorsS:"Text colors: {PH1}",fillColorsS:"Fill colors: {PH1}",borderColorsS:"Border colors: {PH1}",thereAreNoFonts:"No fonts",thereAreNoUnusedDeclarations:"No unused declarations",thereAreNoMediaQueries:"No media queries",contrastIssues:"Contrast issues",nOccurrences:"{n, plural, =1 {# occurrence} other {# occurrences}}",contrastIssuesS:"Contrast issues: {PH1}",textColorSOverSBackgroundResults:"Text color {PH1} over {PH2} background results in low contrast for {PH3} elements",aa:"AA",aaa:"AAA",apca:"APCA",element:"Element",declaration:"Declaration",source:"Source",contrastRatio:"Contrast ratio",cssOverviewElements:"CSS overview elements",showElement:"Show element",unableToLink:"(unable to link)",unableToLinkToInlineStyle:"(unable to link to inline style)"},Et=Se.i18n.registerUIStrings("panels/css_overview/CSSOverviewCompletedView.ts",l),d=Se.i18n.getLocalizedString.bind(void 0,Et);function ye(i){let{h:e,s:t,l:o}=i.as(S.Color.Format.HSL);return e=Math.round(e*360),t=Math.round(t*100),o=Math.round(o*100),o=Math.max(0,o-15),`1px solid hsl(${e}deg ${t}% ${o}%)`}var zt=new Intl.NumberFormat("en-US"),Je=(i,e,t)=>{function o(r,s){r&&(r.scrollIntoView(),s&&r.querySelector('button, [tabindex="0"]')?.focus())}Xe(u`
      <style>${fe}</style>
      <devtools-split-view direction="column" sidebar-position="first" sidebar-initial-size="200">
        <devtools-widget slot="sidebar" ${_e(Y,{minimumSize:new Qe.Size(100,25),items:[{name:d(l.overviewSummary),id:"summary"},{name:d(l.colors),id:"colors"},{name:d(l.fontInfo),id:"font-info"},{name:d(l.unusedDeclarations),id:"unused-declarations"},{name:d(l.mediaQueries),id:"media-queries"}],selectedId:i.selectedSection,onItemSelected:i.onSectionSelected,onReset:i.onReset})}>
        </devtools-widget>
        <devtools-split-view sidebar-position="second" slot="main" direction="row" sidebar-initial-size="minimized">
          <div class="vbox overview-completed-view" slot="main" @click=${i.onClick}>
            <!-- Dupe the styles into the main container because of the shadow root will prevent outer styles. -->
            <style>${fe}</style>
            <div class="results-section horizontally-padded summary"
                  jslog=${w.section("summary")}
                  ${J(r=>{e.revealSection.set("summary",o.bind(null,r))})}>
              <h1>${d(l.overviewSummary)}</h1>
              ${Rt(i.elementCount,i.globalStyleStats,i.mediaQueries)}
            </div>
            <div class="results-section horizontally-padded colors"
                jslog=${w.section("colors")}
                ${J(r=>{e.revealSection.set("colors",o.bind(null,r))})}>
                <h1>${d(l.colors)}</h1>
                ${Bt(i.backgroundColors,i.textColors,i.textColorContrastIssues,i.fillColors,i.borderColors)}
              </div>
              <div class="results-section font-info"
                    jslog=${w.section("font-info")}
                    ${J(r=>{e.revealSection.set("font-info",o.bind(null,r))})}>
                <h1>${d(l.fontInfo)}</h1>
                ${Kt(i.fontInfo)}
              </div>
              <div class="results-section unused-declarations"
                    jslog=${w.section("unused-declarations")}
                    ${J(r=>{e.revealSection.set("unused-declarations",o.bind(null,r))})}>
                <h1>${d(l.unusedDeclarations)}</h1>
                ${Ft(i.unusedDeclarations)}
              </div>
              <div class="results-section media-queries"
                    jslog=${w.section("media-queries")}
                    ${J(r=>{e.revealSection.set("media-queries",o.bind(null,r))})}>
              <h1>${d(l.mediaQueries)}</h1>
              ${Ht(i.mediaQueries)}
            </div>
          </div>
          <devtools-widget slot="sidebar" ${_e(r=>{let s=new B.TabbedPane.TabbedPane(r);return e.closeAllTabs=()=>{s.closeTabs(s.tabIds())},e.addTab=(n,a,c,p)=>{s.hasTab(n)||s.appendTab(n,a,c,void 0,void 0,!0,void 0,void 0,p),s.selectTab(n),s.parentWidget().setSidebarMinimized(!1)},s.addEventListener(B.TabbedPane.Events.TabClosed,n=>{s.tabIds().length===0&&s.parentWidget().setSidebarMinimized(!0)}),s})}>
          </devtools-widget>
        </devtools-split-view>
      </devtools-split-view>`,t)};function Rt(i,e,t){let o=(r,s)=>u`
    <li jslog=${w.item("summary-item")}>
      <div class="label">${r}</div>
      <div class="value">${zt.format(s)}</div>
    </li>`;return u`<ul>
    ${o(d(l.elements),i)}
    ${o(d(l.externalStylesheets),e.externalSheets)}
    ${o(d(l.inlineStyleElements),e.inlineStyles)}
    ${o(d(l.styleRules),e.styleRules)}
    ${o(d(l.mediaQueries),t.length)}
    ${o(d(l.typeSelectors),e.stats.type)}
    ${o(d(l.idSelectors),e.stats.id)}
    ${o(d(l.classSelectors),e.stats.class)}
    ${o(d(l.universalSelectors),e.stats.universal)}
    ${o(d(l.attributeSelectors),e.stats.attribute)}
    ${o(d(l.nonsimpleSelectors),e.stats.nonSimple)}
  </ul>`}function Bt(i,e,t,o,r){return u`
    <h2>${d(l.backgroundColorsS,{PH1:i.length})}</h2>
    <ul>${i.map(s=>re("background",s))}</ul>

    <h2>${d(l.textColorsS,{PH1:e.length})}</h2>
    <ul>${e.map(s=>re("text",s))}</ul>

    ${t.size>0?_t(t):""}

    <h2>${d(l.fillColorsS,{PH1:o.length})}</h2>
    <ul>${o.map(s=>re("fill",s))}</ul>

    <h2>${d(l.borderColorsS,{PH1:r.length})}</h2>
    <ul>${r.map(s=>re("border",s))}</ul>`}function Ft(i){return i.length>0?Ce(i,"unused-declarations"):u`<div class="horizontally-padded">${d(l.thereAreNoUnusedDeclarations)}</div>`}function Ht(i){return i.length>0?Ce(i,"media-queries"):u`<div class="horizontally-padded">${d(l.thereAreNoMediaQueries)}</div>`}function Kt(i){return i.length>0?u`${i.map(({font:e,fontMetrics:t})=>u`
    <section class="font-family">
      <h2>${e}</h2>
      ${Wt(e,t)}
    </section>`)}`:u`<div>${d(l.thereAreNoFonts)}</div>`}function Wt(i,e){return u`
    <div class="font-metric">
      ${e.map(({label:t,values:o})=>u`
        <div>
          <h3>${t}</h3>
          ${Ce(o,"font-info",`${i}/${t}`,t)}
        </div>`)}
    </div>`}function Ce(i,e,t="",o=""){let r=i.reduce((s,n)=>s+n.nodes.length,0);return u`
      <ul aria-label=${e}>
        ${i.map(({title:s,nodes:n})=>{let a=100*n.length/r,c=d(l.nOccurrences,{n:n.length});return u`<li jslog=${w.item("css-overview.group-item")}>
            <div class="title">${s}</div>
            <button data-type=${e} data-path=${t} data-label=${s}
            jslog=${w.action().track({click:!0}).context(`css-overview.${e}`)}
            aria-label=${`${o?`${o}, `:""}${s}: ${c}`}>
              <div class="details">${c}</div>
              <div class="bar-container">
                <div class="bar" style=${ae({width:a})}></div>
              </div>
            </button>
          </li>`})}
  </ul>`}function _t(i){return u`
    <h2>${d(l.contrastIssuesS,{PH1:i.size})}</h2>
    <ul>
      ${[...i.entries()].map(([e,t])=>qt(e,t))}
    </ul>`}function qt(i,e){console.assert(e.length>0);let t=e[0];for(let c of e)Math.abs(c.contrastRatio)<Math.abs(t.contrastRatio)&&(t=c);let o=t.textColor.asString(S.Color.Format.HEXA),r=t.backgroundColor.asString(S.Color.Format.HEXA),s=S.Settings.Settings.instance().resolve(U.SDKSettings.apcaSettingDescriptor).get(),n=d(l.textColorSOverSBackgroundResults,{PH1:o,PH2:r,PH3:e.length}),a=ye(t.backgroundColor.asLegacyColor());return u`<li jslog=${w.item("contrast-issue")}>
    <button
      title=${n} aria-label=${n}
      data-type="contrast" data-key=${i} data-section="contrast" class="block"
      style=${ae({color:o,backgroundColor:r,border:a})}
      jslog=${w.action("css-overview.contrast").track({click:!0})}>
      Text
    </button>
    <div class="block-title">
      ${s?u`
        <div class="contrast-warning hidden">
          <span class="threshold-label">${d(l.apca)}</span>
          ${t.thresholdsViolated.apca?_():q()}
        </div>`:u`
        <div class="contrast-warning hidden">
          <span class="threshold-label">${d(l.aa)}</span>
          ${t.thresholdsViolated.aa?_():q()}
        </div>
        <div class="contrast-warning hidden">
          <span class="threshold-label">${d(l.aaa)}</span>
          ${t.thresholdsViolated.aaa?_():q()}
        </div>`}
    </div>
  </li>`}function re(i,e){let t=S.Color.parse(e)?.asLegacyColor();return t?u`<li jslog=${w.item("color-item")}>
    <button title=${e} data-type="color" data-color=${e}
      data-section=${i} class="block"
      style=${ae({backgroundColor:e,border:ye(t)})}
      jslog=${w.action("css-overview.color").track({click:!0})}>
    </button>
    <div class="block-title color-text">${e}</div>
  </li>`:k}var F=class i extends B.Widget.VBox{onReset=()=>{};#t="summary";#o;#s;#i;#r;#e;#a;#n={revealSection:new Map,closeAllTabs:()=>{},addTab:(e,t,o,r)=>{}};constructor(e,t=Je){super(e),this.#a=t,this.#i=new Ge.Linkifier.Linkifier(20,!0),this.#r=new Map,this.#e=null}set target(e){if(!e)return;let t=e.model(U.CSSModel.CSSModel),o=e.model(U.DOMModel.DOMModel);if(!t||!o)throw new Error("Target must provide CSS and DOM models");this.#o=t,this.#s=o}#c(e,t){let o=this.#n.revealSection.get(e);o&&o(t)}#u(){this.#p(),this.onReset()}#p(){this.#n.closeAllTabs(),this.#r=new Map,i.pushedNodes.clear(),this.#t="summary",this.requestUpdate()}#m(e){if(!e.target)return;let o=e.target.dataset,r=o.type;if(!r||!this.#e)return;let s;switch(r){case"contrast":{let n=o.section,a=o.key;if(!a)return;let c=this.#e.textColorContrastIssues.get(a)||[];s={type:r,key:a,nodes:c,section:n};break}case"color":{let n=o.color,a=o.section;if(!n)return;let c;switch(a){case"text":c=this.#e.textColors.get(n);break;case"background":c=this.#e.backgroundColors.get(n);break;case"fill":c=this.#e.fillColors.get(n);break;case"border":c=this.#e.borderColors.get(n);break}if(!c)return;c=Array.from(c).map(p=>({nodeId:p})),s={type:r,color:n,nodes:c,section:a};break}case"unused-declarations":{let n=o.label;if(!n)return;let a=this.#e.unusedDeclarations.get(n);if(!a)return;s={type:r,declaration:n,nodes:a};break}case"media-queries":{let n=o.label;if(!n)return;let a=this.#e.mediaQueries.get(n);if(!a)return;s={type:r,text:n,nodes:a};break}case"font-info":{let n=o.label;if(!o.path)return;let[a,c]=o.path.split("/");if(!n)return;let p=this.#e.fontInfo.get(a);if(!p)return;let h=p.get(c);if(!h)return;let I=h.get(n);if(!I)return;let Q=I.map(Z=>({nodeId:Z})),ue=`${n} (${a}, ${c})`;s={type:r,name:ue,nodes:Q};break}default:return}e.consume(),this.#d(s),this.requestUpdate()}performUpdate(){if(!this.#e||!("backgroundColors"in this.#e)||!("textColors"in this.#e))return;let e={elementCount:this.#e.elementCount,backgroundColors:this.#l(this.#e.backgroundColors),textColors:this.#l(this.#e.textColors),textColorContrastIssues:this.#e.textColorContrastIssues,fillColors:this.#l(this.#e.fillColors),borderColors:this.#l(this.#e.borderColors),globalStyleStats:this.#e.globalStyleStats,mediaQueries:this.#v(this.#e.mediaQueries),unusedDeclarations:this.#v(this.#e.unusedDeclarations),fontInfo:this.#h(this.#e.fontInfo),selectedSection:this.#t,onClick:this.#m.bind(this),onSectionSelected:this.#c.bind(this),onReset:this.#u.bind(this)};this.#a(e,this.#n,this.element)}#d(e){let t="",o="";switch(e.type){case"contrast":{let{section:s,key:n}=e;t=`${s}-${n}`,o=d(l.contrastIssues);break}case"color":{let{section:s,color:n}=e;t=`${s}-${n}`,o=`${n.toUpperCase()} (${s})`;break}case"unused-declarations":{let{declaration:s}=e;t=`${s}`,o=`${s}`;break}case"media-queries":{let{text:s}=e;t=`${s}`,o=`${s}`;break}case"font-info":{let{name:s}=e;t=`${s}`,o=`${s}`;break}}let r=this.#r.get(t);if(!r){if(!this.#s||!this.#o)throw new Error("Unable to initialize CSS overview, missing models");r=new ne(this.#s,this.#o,this.#i),r.data=e.nodes,this.#r.set(t,r)}this.#n.addTab(t,o,r,e.type)}#l(e){return Array.from(e.keys()).sort((t,o)=>{let r=S.Color.parse(t)?.asLegacyColor(),s=S.Color.parse(o)?.asLegacyColor();return!r||!s?0:S.ColorUtils.luminance(s.rgba())-S.ColorUtils.luminance(r.rgba())})}#h(e){return Array.from(e.entries()).map(([o,r])=>{let s=Array.from(r.entries());return{font:o,fontMetrics:s.map(([n,a])=>({label:n,values:this.#v(a)}))}})}#v(e){return Array.from(e.entries()).sort((t,o)=>{let r=t[1];return o[1].length-r.length}).map(([t,o])=>({title:t,nodes:o}))}set overviewData(e){this.#e=e,this.requestUpdate()}static pushedNodes=new Set},Ze=(i,e,t)=>{let{items:o,visibility:r}=i;Xe(u`
    <div>
      <devtools-data-grid class="element-grid" striped inline
         name=${d(l.cssOverviewElements)}>
        <table>
          <tr>
            ${r.has("node-id")?u`
              <th id="node-id" weight="50" sortable>
                ${d(l.element)}
              </th>`:k}
            ${r.has("declaration")?u`
              <th id="declaration" weight="50" sortable>
                ${d(l.declaration)}
              </th>`:k}
            ${r.has("source-url")?u`
              <th id="source-url" weight="100">
                ${d(l.source)}
              </th>`:k}
            ${r.has("contrast-ratio")?u`
              <th id="contrast-ratio" weight="25" width="150px" sortable fixed>
                ${d(l.contrastRatio)}
              </th>`:k}
          </tr>
          ${o.map(({data:s,link:n,showNode:a})=>u`
            <tr>
              ${r.has("node-id")?jt(s,n,a):k}
              ${r.has("declaration")?Qt(s):k}
              ${r.has("source-url")?Gt(s,n):k}
              ${r.has("contrast-ratio")?Xt(s):k}
            </tr>`)}
        </table>
      </devtools-data-grid>
    </div>`,t)},ne=class extends B.Widget.Widget{#t;#o;#s;#i;#r;constructor(e,t,o,r=Ze){super(),this.#t=e,this.#o=t,this.#s=o,this.#r=r,this.#i=[]}set data(e){this.#i=e,this.requestUpdate()}async performUpdate(){let e=new Set;if(!this.#i.length){this.#r({items:[],visibility:e},void 0,this.element);return}let[t]=this.#i;"nodeId"in t&&t.nodeId&&e.add("node-id"),"declaration"in t&&t.declaration&&e.add("declaration"),"sourceURL"in t&&t.sourceURL&&e.add("source-url"),"contrastRatio"in t&&t.contrastRatio&&e.add("contrast-ratio");let o;if("nodeId"in t&&e.has("node-id")){let s=this.#i.reduce((n,a)=>{let c=a.nodeId;return F.pushedNodes.has(c)?n:(F.pushedNodes.add(c),n.add(c))},new Set);o=await this.#t.pushNodesByBackendIdsToFrontend(s)}let r=await Promise.all(this.#i.map(async s=>{let n,a;if("nodeId"in s&&e.has("node-id")){let c=o?.get(s.nodeId)??null;c&&(n=Ye.DOMLinkifier.Linkifier.instance().linkify(c),a=()=>c.scrollIntoView())}if("range"in s&&s.range&&s.styleSheetId&&e.has("source-url")){let c=je.TextRange.TextRange.fromObject(s.range),p=this.#o.styleSheetHeaderForId(s.styleSheetId);if(p){let h=p.lineNumberInSource(c.startLine),I=p.columnNumberInSource(c.startLine,c.startColumn),Q=new U.CSSModel.CSSLocation(p,h,I);n=u`${this.#s.linkifyCSSLocation(Q)}`}}return{data:s,link:n,showNode:a}}));this.#r({items:r,visibility:e},void 0,this.element)}};function jt(i,e,t){return e?u`
    <td>
      ${e}
      <devtools-icon part="show-element" name="select-element"
          title=${d(l.showElement)} tabindex="0"
          @click=${()=>t?.()}></devtools-icon>
    </td>`:k}function Qt(i){if(!("declaration"in i))throw new Error("Declaration entry is missing a declaration.");return u`<td>${i.declaration}</td>`}function Gt(i,e){return"range"in i&&i.range?e?u`<td>${e}</td>`:u`<td>${d(l.unableToLink)}</td>`:u`<td>${d(l.unableToLinkToInlineStyle)}</td>`}function Xt(i){if(!("contrastRatio"in i))throw new Error("Contrast ratio entry is missing a contrast ratio.");let e=S.Settings.Settings.instance().resolve(U.SDKSettings.apcaSettingDescriptor).get(),t=qe.NumberUtilities.floor(i.contrastRatio,2),o=e?t+"%":t,r=ye(i.backgroundColor),s=i.textColor.asString(),n=i.backgroundColor.asString();return u`
    <td>
      <div class="contrast-container-in-grid">
          <span class="contrast-preview" style=${ae({border:r,color:s,backgroundColor:n})}>Aa</span>
          <span>${o}</span>
          ${e?u`
            <span>${d(l.apca)}</span>${i.thresholdsViolated.apca?_():q()}`:u`
            <span>${d(l.aa)}</span>${i.thresholdsViolated.aa?_():q()}
            <span>${d(l.aaa)}</span>${i.thresholdsViolated.aaa?_():q()}`}
      </div>
    </td>`}function _(){return u`
    <devtools-icon name="clear" class="small" style="color:var(--icon-error);"></devtools-icon>`}function q(){return u`
    <devtools-icon name="checkmark" class="small"
        style="color:var(--icon-checkmark-green);"></devtools-icon>`}var nt={};K(nt,{CSSOverviewPanel:()=>Me,DEFAULT_VIEW:()=>rt});import*as de from"../../core/host/host.js";import*as O from"../../core/sdk/sdk.js";import*as ce from"../../ui/legacy/legacy.js";import{render as oo}from"../../ui/lit/lit.js";import"../../ui/components/panel_feedback/panel_feedback.js";import"../../ui/components/panel_introduction_steps/panel_introduction_steps.js";import*as xe from"../../core/i18n/i18n.js";import*as st from"../../ui/components/buttons/buttons.js";import*as it from"../../ui/legacy/legacy.js";import{html as Yt,render as Jt}from"../../ui/lit/lit.js";var tt=`@scope to (devtools-widget > *){h1{font-weight:normal}.css-overview-start-view{padding:var(--sys-size-11);display:flex;flex-direction:column;background-color:var(--sys-color-cdt-base-container);overflow:auto}.start-capture-wrapper{width:fit-content}.preview-feature{padding:var(--sys-size-6) var(--sys-size-8);border:var(--sys-size-1) solid var(--sys-color-neutral-outline);color:var(--sys-color-on-surface);font-size:var(--sys-typescale-body3-size);line-height:var(--sys-typescale-body3-line-height);border-radius:var(--sys-shape-corner-medium-small);margin:42px 0;letter-spacing:0.01em}.preview-header{color:var(--sys-color-primary);font-size:var(--sys-typescale-body3-size);line-height:var(--sys-typescale-body3-line-height);letter-spacing:0.01em;margin:9px 0 var(--sys-size-7)}.preview-icon{vertical-align:middle}.feedback-prompt{margin-bottom:var(--sys-size-11)}.feedback-prompt .devtools-link{color:-webkit-link;cursor:pointer;text-decoration:underline}.resources{display:flex;flex-direction:row}.thumbnail-wrapper{width:var(--sys-size-22);height:92px;margin-right:var(--sys-size-9)}.video-doc-header{font-size:var(--sys-typescale-body3-size);line-height:var(--sys-typescale-body3-line-height);letter-spacing:0.04em;color:var(--sys-color-on-surface);margin-bottom:var(--sys-size-2)}devtools-feedback-button{align-self:flex-end}.resources .devtools-link{font-size:var(--sys-typescale-body2-size);line-height:var(--sys-size-10);letter-spacing:0.04em;text-decoration-line:underline;color:var(--sys-color-primary)}}
/*# sourceURL=${import.meta.resolve("./cssOverviewStartView.css")} */`;var H={captureOverview:"Capture overview",identifyCSSImprovements:"Identify potential CSS improvements",capturePageCSSOverview:"Capture an overview of your page\u2019s CSS",identifyCSSImprovementsWithExampleIssues:"Identify potential CSS improvements (e.g. low contrast issues, unused declarations, color or font mismatches)",locateAffectedElements:"Locate the affected elements in the Elements panel",quickStartWithCSSOverview:"Quick start: get started with the new CSS overview panel"},Zt=xe.i18n.registerUIStrings("panels/css_overview/CSSOverviewStartView.ts",H),j=xe.i18n.getLocalizedString.bind(void 0,Zt),ot="https://g.co/devtools/css-overview-feedback",eo="https://developer.chrome.com/docs/devtools/css-overview",to=(i,e,t)=>{Jt(Yt`
    <style>${tt}</style>
    <div class="css-overview-start-view">
      <devtools-panel-introduction-steps>
        <span slot="title">${j(H.identifyCSSImprovements)}</span>
        <span slot="step-1">${j(H.capturePageCSSOverview)}</span>
        <span slot="step-2">${j(H.identifyCSSImprovementsWithExampleIssues)}</span>
        <span slot="step-3">${j(H.locateAffectedElements)}</span>
      </devtools-panel-introduction-steps>
      <div class="start-capture-wrapper">
        <devtools-button
          class="start-capture"
          autofocus
          .variant=${st.Button.Variant.PRIMARY}
          .jslogContext=${"css-overview.capture-overview"}
          @click=${i.onStartCapture}>
          ${j(H.captureOverview)}
        </devtools-button>
      </div>
      <devtools-panel-feedback .data=${{feedbackUrl:ot,quickStartUrl:eo,quickStartLinkText:j(H.quickStartWithCSSOverview)}}>
      </devtools-panel-feedback>
      <devtools-feedback-button .data=${{feedbackUrl:ot}}>
      </devtools-feedback-button>
    </div>`,t)},le=class extends it.Widget.Widget{#t;onStartCapture=()=>{};constructor(e,t=to){super(e,{useShadowDom:!0,delegatesFocus:!0}),this.#t=t,this.performUpdate()}performUpdate(){this.#t({onStartCapture:this.onStartCapture},void 0,this.contentElement)}};var{widget:Ie}=ce.Widget,rt=(i,e,t)=>{oo(i.state==="start"?Ie(le,{onStartCapture:i.onStartCapture}):i.state==="processing"?Ie(X,{onCancel:i.onCancel}):Ie(F,{onReset:i.onReset,overviewData:i.overviewData,target:i.target}),t)},Me=class extends ce.Panel.Panel{#t;#o;#s;#i;#r;#e;#a;#n;#c;#u;#p;#m;#d;#l;constructor(e=rt){super("css-overview"),this.#t=O.TargetManager.TargetManager.instance().inspectedURL(),O.TargetManager.TargetManager.instance().addEventListener(O.TargetManager.Events.INSPECTED_URL_CHANGED,this.#v,this),this.#l=e,O.TargetManager.TargetManager.instance().observeTargets(this),this.#g()}#h(){de.userMetrics.actionTaken(de.UserMetrics.Action.CaptureCssOverviewClicked),this.#y()}#v(){this.#t!==O.TargetManager.TargetManager.instance().inspectedURL()&&(this.#t=O.TargetManager.TargetManager.instance().inspectedURL(),this.#g())}targetAdded(e){e===O.TargetManager.TargetManager.instance().primaryPageTarget()&&(this.#o=e.model(W)??void 0)}targetRemoved(){}#f(){if(!this.#o)throw new Error("Did not retrieve model information yet.");return this.#o}#g(){this.#s=new Map,this.#i=new Map,this.#r=new Map,this.#e=new Map,this.#a=new Map,this.#n=new Map,this.#c=new Map,this.#u=0,this.#p={styleRules:0,inlineStyles:0,externalSheets:0,stats:{type:0,class:0,id:0,universal:0,attribute:0,nonSimple:0}},this.#m=new Map,this.#w()}#w(){this.#d="start",this.performUpdate()}#b(){this.#d="processing",this.performUpdate()}#S(){this.#d="completed",this.performUpdate()}performUpdate(){let e={state:this.#d,onStartCapture:this.#h.bind(this),onCancel:this.#g.bind(this),onReset:this.#g.bind(this),target:this.#o?.target(),overviewData:{backgroundColors:this.#s,textColors:this.#i,textColorContrastIssues:this.#m,fillColors:this.#r,borderColors:this.#e,globalStyleStats:this.#p,fontInfo:this.#a,elementCount:this.#u,mediaQueries:this.#n,unusedDeclarations:this.#c}};this.#l(e,void 0,this.contentElement)}async#y(){this.#b();let e=this.#f(),[t,{elementCount:o,backgroundColors:r,textColors:s,textColorContrastIssues:n,fillColors:a,borderColors:c,fontInfo:p,unusedDeclarations:h},I]=await Promise.all([e.getGlobalStylesheetStats(),e.getNodeStyleStats(),e.getMediaQueries()]);o&&(this.#u=o),t&&(this.#p=t),I&&(this.#n=I),r&&(this.#s=r),s&&(this.#i=s),n&&(this.#m=n),a&&(this.#r=a),c&&(this.#e=c),p&&(this.#a=p),h&&(this.#c=h),this.#S()}};export{et as CSSOverviewCompletedView,Pe as CSSOverviewModel,nt as CSSOverviewPanel,Le as CSSOverviewProcessingView,We as CSSOverviewSidebarPanel,De as CSSOverviewUnusedDeclarations};
//# sourceMappingURL=css_overview.js.map
