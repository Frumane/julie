var y=Object.defineProperty;var u=(t,e)=>{for(var o in e)y(t,o,{get:e[o],enumerable:!0})};var h={};u(h,{DEFAULT_VIEW:()=>p,ElementsPanelLink:()=>s});import*as c from"../../../ui/legacy/legacy.js";import{html as U,render as k}from"../../../ui/lit/lit.js";import*as v from"../../../ui/visual_logging/visual_logging.js";var d=`@scope to (devtools-widget > *){.element-reveal-icon{display:inline-block;width:var(--sys-size-9);height:var(--sys-size-9);mask-image:var(--image-file-select-element);background-color:var(--icon-default);border:none;padding:0}}
/*# sourceURL=${import.meta.resolve("././elementsPanelLink.css")} */`;var p=(t,e,o)=>{k(U`
    <style>${d}</style>
    <button
      class="element-reveal-icon"
      jslog=${v.link("elements-panel").track({click:!0})}
      @click=${t.onElementRevealIconClick}
      @mouseenter=${t.onElementRevealIconMouseEnter}
      @mouseleave=${t.onElementRevealIconMouseLeave}></button>
    `,o)},s=class extends c.Widget.Widget{#e=()=>{};#t=()=>{};#o=()=>{};#n;constructor(e,o=p){super(e),this.#n=o}wasShown(){super.wasShown(),this.requestUpdate()}set onElementRevealIconClick(e){this.#e!==e&&(this.#e=e,this.requestUpdate())}set onElementRevealIconMouseEnter(e){this.#t!==e&&(this.#t=e,this.requestUpdate())}set onElementRevealIconMouseLeave(e){this.#o!==e&&(this.#o=e,this.requestUpdate())}set data(e){this.onElementRevealIconClick=e.onElementRevealIconClick,this.onElementRevealIconMouseEnter=e.onElementRevealIconMouseEnter,this.onElementRevealIconMouseLeave=e.onElementRevealIconMouseLeave}performUpdate(){this.#n({onElementRevealIconClick:this.#e,onElementRevealIconMouseEnter:this.#t,onElementRevealIconMouseLeave:this.#o},void 0,this.contentElement)}};var L={};u(L,{DEFAULT_VIEW:()=>w,HideIssuesMenu:()=>r});import*as g from"../../../core/common/common.js";import*as l from"../../../core/i18n/i18n.js";import*as E from"../../../ui/components/buttons/buttons.js";import*as i from"../../../ui/legacy/legacy.js";import{html as x,render as S}from"../../../ui/lit/lit.js";var I=`@scope to (devtools-widget > *){.hide-issues-menu-btn{position:relative;display:flex;background-color:transparent;flex:none;align-items:center;justify-content:center;padding:0;margin:0 calc(-1 * var(--sys-size-2)) 0 var(--sys-size-3);overflow:hidden;border-radius:0;border:none;&:hover > devtools-icon{color:var(--icon-default-hover)}}}
/*# sourceURL=${import.meta.resolve("././hideIssuesMenu.css")} */`;var f={tooltipTitle:"Hide issues"},b=l.i18n.registerUIStrings("panels/issues/components/HideIssuesMenu.ts",f),C=l.i18n.getLocalizedString.bind(void 0,b),w=(t,e,o)=>{let M=n=>{n.stopPropagation();let a=n.currentTarget,m=new i.ContextMenu.ContextMenu(n,{x:a?.getBoundingClientRect().left,y:a?.getBoundingClientRect().bottom});m.headerSection().appendItem(t.menuItemLabel,()=>t.menuItemAction(),{jslogContext:"toggle-similar-issues"}),m.show()},R=n=>{(n.key==="Enter"||n.key==="Space")&&n.stopImmediatePropagation()};S(x`
    <style>${I}</style>
    <devtools-button
      .data=${{variant:E.Button.Variant.ICON,iconName:"dots-vertical",title:C(f.tooltipTitle)}}
      .jslogContext=${"hide-issues"}
      class="hide-issues-menu-btn"
      @click=${M}
      @keydown=${R}></devtools-button>
  `,o,{container:{classes:["hide-issues-menu"]}})},r=class extends i.Widget.Widget{#e=g.UIString.LocalizedEmptyString;#t=()=>{};#o;constructor(e,o=w){super(e,{useShadowDom:"pure"}),this.#o=o}set menuItemLabel(e){this.#e!==e&&(this.#e=e,this.requestUpdate())}set menuItemAction(e){this.#t!==e&&(this.#t=e,this.requestUpdate())}wasShown(){super.wasShown(),this.requestUpdate()}performUpdate(){this.#o({menuItemLabel:this.#e,menuItemAction:this.#t},void 0,this.contentElement)}};export{h as ElementsPanelLink,L as HideIssuesMenu};
//# sourceMappingURL=components.js.map
