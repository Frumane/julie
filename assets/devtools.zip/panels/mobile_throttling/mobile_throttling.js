var ge=Object.defineProperty;var V=(n,t)=>{for(var e in t)ge(n,e,{get:t[e],enumerable:!0})};var Gt={};V(Gt,{CPUThrottlingSelector:()=>ft,DEFAULT_VIEW:()=>Vt});import*as X from"../../core/common/common.js";import*as Tt from"../../core/i18n/i18n.js";import*as it from"../../core/sdk/sdk.js";import*as _ from"../../models/crux-manager/crux-manager.js";import*as Rt from"../../ui/legacy/legacy.js";import*as St from"../../ui/lit/lit.js";import*as j from"../../ui/visual_logging/visual_logging.js";import*as vt from"../common/common.js";var Ht={};V(Ht,{ActionDelegate:()=>wt,CPUPerformanceTier:()=>Ce,DEFAULT_SAVE_DATA_VIEW:()=>Kt,SaveDataOverrideSelect:()=>et,ThrottlingManager:()=>B,throttlingManager:()=>Q});import*as L from"../../core/common/common.js";import*as nt from"../../core/host/host.js";import*as bt from"../../core/i18n/i18n.js";import*as u from"../../core/sdk/sdk.js";import{Icon as me}from"../../ui/kit/kit.js";import*as w from"../../ui/legacy/legacy.js";import{html as he,render as pe}from"../../ui/lit/lit.js";import*as $t from"../../ui/visual_logging/visual_logging.js";import*as G from"../common/common.js";var It={};V(It,{ThrottlingPresets:()=>k});import*as pt from"../../core/i18n/i18n.js";import*as v from"../../core/sdk/sdk.js";import*as U from"../common/common.js";var M={noThrottling:"No CPU and no network throttling",noInternetConnectivity:"No internet connectivity",lowTierMobile:"Low-tier mobile",slowGXCpuSlowdown:"Slow 3G & 6x CPU slowdown",slowGXCpuSlowdownCalibrated:"Slow 3G & {PH1}x CPU slowdown",midtierMobile:"Mid-tier mobile",fastGXCpuSlowdown:"Fast 3G & 4x CPU slowdown",fastGXCpuSlowdownCalibrated:"Fast 3G & {PH1}x CPU slowdown",custom:"Custom",checkNetworkAndPerformancePanels:"Check Network and Performance panels"},ue=pt.i18n.registerUIStrings("panels/mobile_throttling/ThrottlingPresets.ts",M),N=pt.i18n.getLocalizedString.bind(void 0,ue),k=class n{static getNoThrottlingConditions(){return{title:typeof v.NetworkManager.NoThrottlingConditions.title=="function"?v.NetworkManager.NoThrottlingConditions.title():v.NetworkManager.NoThrottlingConditions.title,description:N(M.noThrottling),network:v.NetworkManager.NoThrottlingConditions,cpuThrottlingOption:U.CPUThrottlingOption.NoThrottlingOption,jslogContext:"no-throttling"}}static getOfflineConditions(){return{title:typeof v.NetworkManager.OfflineConditions.title=="function"?v.NetworkManager.OfflineConditions.title():v.NetworkManager.OfflineConditions.title,description:N(M.noInternetConnectivity),network:v.NetworkManager.OfflineConditions,cpuThrottlingOption:U.CPUThrottlingOption.NoThrottlingOption,jslogContext:"offline"}}static getLowEndMobileConditions(){let t=U.CPUThrottlingOption.CalibratedLowTierMobileThrottlingOption.rate()!==0,e=t?U.CPUThrottlingOption.CalibratedLowTierMobileThrottlingOption:U.CPUThrottlingOption.LowTierThrottlingOption,o=t?N(M.slowGXCpuSlowdownCalibrated,{PH1:e.rate()}):N(M.slowGXCpuSlowdown);return{title:N(M.lowTierMobile),description:o,network:v.NetworkManager.Slow3GConditions,cpuThrottlingOption:e,jslogContext:"low-end-mobile"}}static getMidTierMobileConditions(){let t=U.CPUThrottlingOption.CalibratedMidTierMobileThrottlingOption.rate()!==0,e=t?U.CPUThrottlingOption.CalibratedMidTierMobileThrottlingOption:U.CPUThrottlingOption.MidTierThrottlingOption,o=t?N(M.fastGXCpuSlowdownCalibrated,{PH1:e.rate()}):N(M.fastGXCpuSlowdown);return{title:N(M.midtierMobile),description:o,network:v.NetworkManager.Slow4GConditions,cpuThrottlingOption:e,jslogContext:"mid-tier-mobile"}}static getCustomConditions(){return{title:N(M.custom),description:N(M.checkNetworkAndPerformancePanels),jslogContext:"custom"}}static getMobilePresets(){return[n.getMidTierMobileConditions(),n.getLowEndMobileConditions(),n.getCustomConditions()]}static getAdvancedMobilePresets(){return[n.getOfflineConditions()]}static networkPresets=[v.NetworkManager.Fast4GConditions,v.NetworkManager.Slow4GConditions,v.NetworkManager.Slow3GConditions,v.NetworkManager.OfflineConditions];static cpuThrottlingPresets=U.CPUThrottlingOption.cpuThrottlingPresets};globalThis.MobileThrottling=globalThis.MobileThrottling||{};globalThis.MobileThrottling.networkPresets=k.networkPresets;var Ce=u.CPUThrottlingManager.CPUPerformanceTier,C={offline:"Offline",forceDisconnectedFromNetwork:"Force disconnected from network",cpuThrottlingIsEnabled:"CPU throttling is enabled",cpuThrottling:"CPU throttling",excessConcurrency:"Exceeding the default value may degrade system performance",resetConcurrency:"Reset to the default value",hardwareConcurrency:"Hardware concurrency",hardwareConcurrencySettingLabel:"Override the value reported by `navigator.hardwareConcurrency`",recommendedThrottling:"{PH1} \u2013 recommended",calibrate:"Calibrate\u2026",recalibrate:"Recalibrate\u2026",noSaveDataOverride:"'Save-Data': default",saveDataOn:"'Save-Data': on",saveDataOff:"'Save-Data': off",saveDataSettingTooltip:"Override the value reported by `navigator.connection.saveData` on the page"},we=bt.i18n.registerUIStrings("panels/mobile_throttling/ThrottlingManager.ts",C),b=bt.i18n.getLocalizedString.bind(void 0,we),Ct,B=class n extends L.ObjectWrapper.ObjectWrapper{cpuThrottlingControls;cpuThrottlingOptions;customNetworkConditionsSetting;currentNetworkThrottlingConditionKeySetting;calibratedCpuThrottlingSetting;lastNetworkThrottlingConditions;cpuThrottlingManager;#e=!1;#n=G.CPUThrottlingOption.NoThrottlingOption;get hardwareConcurrencyOverrideEnabled(){return this.#e}constructor(t){super(),this.cpuThrottlingManager=u.CPUThrottlingManager.CPUThrottlingManager.instance(),this.cpuThrottlingManager.addEventListener(u.CPUThrottlingManager.Events.RATE_CHANGED,e=>this.onCPUThrottlingRateChangedOnSDK(e.data)),this.cpuThrottlingControls=new Set,this.cpuThrottlingOptions=k.cpuThrottlingPresets,this.customNetworkConditionsSetting=u.NetworkManager.customUserNetworkConditionsSetting(t),this.currentNetworkThrottlingConditionKeySetting=u.NetworkManager.activeNetworkThrottlingKeySetting(t),this.calibratedCpuThrottlingSetting=t.createSetting("calibrated-cpu-throttling",{},L.Settings.SettingStorageType.GLOBAL),this.calibratedCpuThrottlingSetting.addChangeListener(this.onCalibratedSettingChanged,this),u.NetworkManager.MultitargetNetworkManager.instance().addEventListener(u.NetworkManager.MultitargetNetworkManager.Events.CONDITIONS_CHANGED,()=>{this.lastNetworkThrottlingConditions=this.#i();let e=u.NetworkManager.MultitargetNetworkManager.instance().networkConditions();this.currentNetworkThrottlingConditionKeySetting.set(e.key)}),this.isDirty()&&u.NetworkManager.MultitargetNetworkManager.instance().setNetworkConditions(this.#i())}#i(){let t=this.currentNetworkThrottlingConditionKeySetting.get(),e=u.NetworkManager.getPredefinedCondition(t);return e||(this.customNetworkConditionsSetting.get().find(r=>r.key===t)??u.NetworkManager.NoThrottlingConditions)}static instance(t={forceNew:null}){let{forceNew:e,settings:o}=t;return(!Ct||e)&&(Ct=new n(o??L.Settings.Settings.instance())),Ct}createOfflineToolbarCheckbox(){let t=new w.Toolbar.ToolbarCheckbox(b(C.offline),b(C.forceDisconnectedFromNetwork),e.bind(this));t.element.setAttribute("jslog",`${$t.toggle("disconnect-from-network").track({click:!0})}`),u.NetworkManager.MultitargetNetworkManager.instance().addEventListener(u.NetworkManager.MultitargetNetworkManager.Events.CONDITIONS_CHANGED,o),t.setChecked(u.NetworkManager.MultitargetNetworkManager.instance().isOffline());function e(){if(t.checked())u.NetworkManager.MultitargetNetworkManager.instance().setNetworkConditions(u.NetworkManager.OfflineConditions);else{let r=!this.lastNetworkThrottlingConditions.download&&!this.lastNetworkThrottlingConditions.upload?u.NetworkManager.NoThrottlingConditions:this.lastNetworkThrottlingConditions;u.NetworkManager.MultitargetNetworkManager.instance().setNetworkConditions(r)}}function o(){t.setChecked(u.NetworkManager.MultitargetNetworkManager.instance().isOffline())}return t}updatePanelIcon(){let t=[];this.cpuThrottlingManager.cpuThrottlingRate()!==G.CPUThrottlingOption.CPUThrottlingRates.NO_THROTTLING&&t.push(b(C.cpuThrottlingIsEnabled)),w.InspectorView.InspectorView.instance().setPanelWarnings("timeline",t)}cpuThrottlingOption(){return this.#n}setCPUThrottlingOption(t){this.#n!==t&&(this.#n=t,this.cpuThrottlingManager.setCPUThrottlingRate(t.rate()))}onCalibratedSettingChanged(){if(!this.#n.calibratedDeviceType)return;let t=this.#n.rate();if(t===0){this.setCPUThrottlingOption(G.CPUThrottlingOption.NoThrottlingOption);return}this.cpuThrottlingManager.setCPUThrottlingRate(t)}onCPUThrottlingRateChangedOnSDK(t){t!==G.CPUThrottlingOption.CPUThrottlingRates.NO_THROTTLING&&nt.userMetrics.actionTaken(nt.UserMetrics.Action.CpuThrottlingEnabled);let e=G.CPUThrottlingOption.determineOptionFromRate(t,this.#n);this.#n=e;let o=this.cpuThrottlingOptions.indexOf(e);for(let r of this.cpuThrottlingControls)r.setSelectedIndex(o);this.updatePanelIcon()}createCPUThrottlingSelector(){let t=()=>{let a=this.calibratedCpuThrottlingSetting.get(),g=a.low||a.mid;return b(g?C.recalibrate:C.calibrate)},e=()=>{if(o.selectedIndex()===o.options().length-1){let a=this.cpuThrottlingOptions.indexOf(this.#n);o.setSelectedIndex(a),L.Revealer.reveal(this.calibratedCpuThrottlingSetting)}else this.setCPUThrottlingOption(this.cpuThrottlingOptions[o.selectedIndex()])},o=new w.Toolbar.ToolbarComboBox(e,b(C.cpuThrottling),"","cpu-throttling");this.cpuThrottlingControls.add(o);let r=this.#n,l=[],i=this.cpuThrottlingOptions;for(let a=0;a<this.cpuThrottlingOptions.length;++a){let g=this.cpuThrottlingOptions[a],m=g.title(),h=g.jslogContext,f=o.createOption(m,h);o.addOption(f),r===g&&o.setSelectedIndex(a),l.push(f)}let s=o.createOption(t(),"");return o.addOption(s),l.push(s),{control:o,updateRecommendedOption(a){for(let g=0;g<l.length-1;g++){let m=i[g];l[g].text=m===a?b(C.recommendedThrottling,{PH1:m.title()}):m.title(),l[g].disabled=m.rate()===0}l[l.length-1].textContent=t()}}}createSaveDataOverrideSelector(t){let e=document.createElement("select");return e.title=b(C.saveDataSettingTooltip),w.ARIAUtils.setLabel(e,b(C.saveDataSettingTooltip)),t&&(e.className=t),w.Widget.registerWidgetConfig(e,w.Widget.widgetConfig(et)),e}createHardwareConcurrencySelector(){let t=new w.Toolbar.ToolbarItem(w.UIUtils.createInput("devtools-text-input","number","hardware-concurrency"));t.setTitle(b(C.hardwareConcurrencySettingLabel));let e=t.element;e.min="1",t.setEnabled(!1);let o=w.UIUtils.CheckboxLabel.create(b(C.hardwareConcurrency),!1,b(C.hardwareConcurrencySettingLabel),"hardware-concurrency"),r=new w.Toolbar.ToolbarButton("Reset concurrency","undo",void 0,"hardware-concurrency-reset");r.setTitle(b(C.resetConcurrency));let l=new me;l.name="warning-filled",l.classList.add("small");let i=new w.Toolbar.ToolbarItem(l);return i.setTitle(b(C.excessConcurrency)),o.disabled=!0,r.element.classList.add("concurrency-hidden"),i.element.classList.add("concurrency-hidden"),this.cpuThrottlingManager.getHardwareConcurrency().then(s=>{if(s===void 0)return;let a=g=>{g>=1&&this.cpuThrottlingManager.setHardwareConcurrency(g),g>s?i.element.classList.remove("concurrency-hidden"):i.element.classList.add("concurrency-hidden"),g===s?r.element.classList.add("concurrency-hidden"):r.element.classList.remove("concurrency-hidden")};e.value=`${s}`,e.oninput=()=>a(Number(e.value)),o.disabled=!1,o.addEventListener("change",()=>{this.#e=o.checked,t.setEnabled(this.hardwareConcurrencyOverrideEnabled),a(this.hardwareConcurrencyOverrideEnabled?Number(e.value):s)}),r.addEventListener(w.Toolbar.ToolbarButton.Events.CLICK,()=>{e.value=`${s}`,a(s)})}),{numericInput:t,reset:r,warning:i,checkbox:o}}setHardwareConcurrency(t){this.cpuThrottlingManager.setHardwareConcurrency(t)}effectiveCPUPerformanceTier(){return this.cpuThrottlingManager.effectiveCPUPerformanceTier()}setCPUPerformanceTier(t){this.cpuThrottlingManager.setCPUPerformanceTier(t)}isDirty(){let t=u.NetworkManager.MultitargetNetworkManager.instance().networkConditions(),e=this.#i();return!u.NetworkManager.networkConditionsEqual(t,e)}},Kt=(n,t,e)=>{pe(he`
    <option value=${u.EmulationModel.DataSaverOverride.UNSET} .selected=${n.selectedOption===u.EmulationModel.DataSaverOverride.UNSET}>${b(C.noSaveDataOverride)}</option>
    <option value=${u.EmulationModel.DataSaverOverride.ENABLED} .selected=${n.selectedOption===u.EmulationModel.DataSaverOverride.ENABLED}>${b(C.saveDataOn)}</option>
    <option value=${u.EmulationModel.DataSaverOverride.DISABLED} .selected=${n.selectedOption===u.EmulationModel.DataSaverOverride.DISABLED}>${b(C.saveDataOff)}</option>
  `,e,{container:{listeners:{change:o=>n.onSelect(o.target.value)}}})},et=class extends w.Widget.Widget{#e;#n;constructor(t,e=Kt){super(t),this.#n=e,this.#e=L.Settings.Settings.instance().resolve(u.SDKSettings.dataSaverSettingDescriptor),this.performUpdate()}wasShown(){super.wasShown(),this.#e.addChangeListener(this.requestUpdate,this),this.requestUpdate()}willHide(){super.willHide(),this.#e.removeChangeListener(this.requestUpdate,this)}performUpdate(){this.#n({selectedOption:this.#e.get(),onSelect:t=>{this.#e.set(t)}},void 0,this.contentElement)}},wt=class{handleAction(t,e){return e==="network-conditions.network-online"?(u.NetworkManager.MultitargetNetworkManager.instance().setNetworkConditions(u.NetworkManager.NoThrottlingConditions),!0):e==="network-conditions.network-low-end-mobile"?(u.NetworkManager.MultitargetNetworkManager.instance().setNetworkConditions(u.NetworkManager.Slow3GConditions),!0):e==="network-conditions.network-mid-tier-mobile"?(u.NetworkManager.MultitargetNetworkManager.instance().setNetworkConditions(u.NetworkManager.Slow4GConditions),!0):e==="network-conditions.network-offline"?(u.NetworkManager.MultitargetNetworkManager.instance().setNetworkConditions(u.NetworkManager.OfflineConditions),!0):!1}};function Q(){return B.instance()}var{render:be,html:ot,Directives:ve}=St,D={cpuThrottling:"CPU throttling: {PH1}",recommendedThrottling:"{PH1} \u2013 recommended",calibrate:"Calibrate\u2026",recalibrate:"Recalibrate\u2026",disabledThrottlingPreset:"Disabled",defaultPresets:"Presets",labelCalibratedPresets:"Calibrated presets"},fe=Tt.i18n.registerUIStrings("panels/mobile_throttling/CPUThrottlingSelector.ts",D),y=Tt.i18n.getLocalizedString.bind(void 0,fe),At=new WeakMap,Vt=(n,t,e)=>{let o=n.currentOption.title(),r=n.throttling.low||n.throttling.mid,l=y(r?D.recalibrate:D.calibrate);function i(s){let a=s.target;if(!a)return;let g=a.selectedOptions[0];if(!g)return;let m=At.get(g);m?n.onSelect(m):(n.onCalibrateClick(),s.consume(!0),a.value=String(n.currentOption.calibratedDeviceType??n.currentOption.rate()))}be(ot`${n.groups.map(s=>ot` <optgroup
        label=${s.name}
        title=${s.name}
      >
        ${s.items.map(a=>{let g=a===n.recommendedOption?y(D.recommendedThrottling,{PH1:a.title()}):a.title(),m=a.rate();return ot`
            <option
              ${ve.ref(h=>h&&At.set(h,a))}
              .value=${String(a.calibratedDeviceType??m)}
              .selected=${n.currentOption===a}
              ?disabled=${m===0}
              title=${g}
              aria-label=${g}
              jslog=${j.item(a.jslogContext).track({click:!0})}
            >
              ${g}
            </option>
          `})}
        ${s.name===y(D.labelCalibratedPresets)?ot`<option
              .value=${"-1"}
              title=${l}
              aria-label=${l}
              jslog=${j.action("cpu-throttling-selector-calibrate").track({click:!0})}
            >
              ${l}
            </option>`:St.nothing}
      </optgroup>`)}`,e,{container:{listeners:{change:i},attributes:{title:y(D.cpuThrottling,{PH1:o}),"aria-label":y(D.cpuThrottling,{PH1:o}),jslog:`${j.dropDown("cpu-throttling").track({change:!0})}`}}})},ft=class n extends Rt.Widget.Widget{#e;#n=null;#i=[];#o;#t;#r=it.CPUThrottlingManager.CPUThrottlingManager.instance();static createForGlobalConditions(t){let e=t.createChild("select"),o=new n(e);return o.show(t,void 0,!0),o.performUpdate(),o}constructor(t,e=Vt){super(t),this.#e=Q().cpuThrottlingOption(),this.#o=X.Settings.Settings.instance().createSetting("calibrated-cpu-throttling",{},X.Settings.SettingStorageType.GLOBAL),this.#g(),this.#t=e,this.performUpdate()}set recommendedOption(t){this.#n=t,this.requestUpdate()}#s=()=>{let t=vt.CPUThrottlingOption.CalibratedMidTierMobileThrottlingOption;t.rate()===0&&(t=vt.CPUThrottlingOption.MidTierThrottlingOption),this.recommendedOption=t};wasShown(){super.wasShown(),this.#r.addEventListener(it.CPUThrottlingManager.Events.RATE_CHANGED,this.#a,this),this.#o.addChangeListener(this.#l,this),_.CrUXManager.instance().addEventListener(_.Events.FIELD_DATA_CHANGED,this.#s),this.#s(),this.#a()}willHide(){super.willHide(),this.#o.removeChangeListener(this.#l,this),this.#r.removeEventListener(it.CPUThrottlingManager.Events.RATE_CHANGED,this.#a,this),_.CrUXManager.instance().removeEventListener(_.Events.FIELD_DATA_CHANGED,this.#s)}#a(){this.#e=Q().cpuThrottlingOption(),this.requestUpdate()}#l(){this.#g(),this.requestUpdate()}#d(t){Q().setCPUThrottlingOption(t)}#c(){X.Revealer.reveal(this.#o),this.requestUpdate()}#g(){this.#i=[{name:y(D.disabledThrottlingPreset),items:k.cpuThrottlingPresets.filter(t=>t.rate()===1&&!t.calibratedDeviceType)},{name:y(D.defaultPresets),items:k.cpuThrottlingPresets.filter(t=>!t.calibratedDeviceType&&t.rate()>1)},{name:y(D.labelCalibratedPresets),items:k.cpuThrottlingPresets.filter(t=>t.calibratedDeviceType)}]}performUpdate(){let t={recommendedOption:this.#n,currentOption:this.#e,groups:this.#i,throttling:this.#o.get(),onSelect:this.#d.bind(this),onCalibrateClick:this.#c.bind(this)};this.#t(t,void 0,this.contentElement)}};var _t={};V(_t,{NetworkPanelIndicator:()=>Mt});import*as Bt from"../../core/common/common.js";import*as Nt from"../../core/i18n/i18n.js";import*as I from"../../core/sdk/sdk.js";import*as Pt from"../../ui/legacy/legacy.js";var rt={networkThrottlingIsEnabled:"Network throttling is enabled",requestsMayBeOverridden:"Requests may be overridden locally. See the Sources panel.",requestsMayBeBlocked:"Requests may be blocked. See the Request conditions panel."},Te=Nt.i18n.registerUIStrings("panels/mobile_throttling/NetworkPanelIndicator.ts",rt),kt=Nt.i18n.getLocalizedString.bind(void 0,Te),Mt=class{constructor(){if(!Pt.InspectorView.InspectorView.instance().hasPanel("network"))return;let t=I.NetworkManager.MultitargetNetworkManager.instance();t.addEventListener(I.NetworkManager.MultitargetNetworkManager.Events.CONDITIONS_CHANGED,e),t.addEventListener(I.NetworkManager.MultitargetNetworkManager.Events.BLOCKED_PATTERNS_CHANGED,e),t.addEventListener(I.NetworkManager.MultitargetNetworkManager.Events.INTERCEPTORS_CHANGED,e),Bt.Settings.Settings.instance().resolve(I.SDKSettings.cacheDisabledSettingDescriptor).addChangeListener(e,this),e();function e(){let o=[];t.isThrottling()&&o.push(kt(rt.networkThrottlingIsEnabled)),I.NetworkManager.MultitargetNetworkManager.instance().isIntercepting()&&o.push(kt(rt.requestsMayBeOverridden)),t.isBlocking()&&o.push(kt(rt.requestsMayBeBlocked)),Pt.InspectorView.InspectorView.instance().setPanelWarnings("network",o)}}};var Xt={};V(Xt,{DEFAULT_VIEW:()=>Ft,Events:()=>zt,NetworkThrottlingSelect:()=>J,getRecommendedNetworkConditions:()=>Qt});import*as E from"../../core/common/common.js";import*as Dt from"../../core/i18n/i18n.js";import*as Wt from"../../core/platform/platform.js";import*as p from"../../core/sdk/sdk.js";import*as Y from"../../models/crux-manager/crux-manager.js";import*as qt from"../../ui/legacy/legacy.js";import*as Se from"../../ui/lit/lit.js";import*as K from"../../ui/visual_logging/visual_logging.js";var{render:ke,html:st,Directives:jt}=Se,T={disabled:"Disabled",presets:"Presets",custom:"Custom",blockingGroup:"Blocking",sS:"{PH1}: {PH2}",addS:"Add {PH1}",add:"Add\u2026",recommendedThrottling:"{PH1} \u2013 recommended"},Pe=Dt.i18n.registerUIStrings("panels/mobile_throttling/NetworkThrottlingSelector.ts",T),P=Dt.i18n.getLocalizedString.bind(void 0,Pe),Ut=new WeakMap,Ft=(n,t,e)=>{let o=s=>typeof s.title=="function"?s.title():s.title,r=(s,a)=>`${K.item(Wt.StringUtilities.toKebabCase("i18nTitleKey"in a&&a.i18nTitleKey||o(a))).track({click:!0})}`,l=n.selectedConditions;function i(s){let a=s.target;if(!a)return;let g=a.selectedOptions[0];if(!g)return;let m=Ut.get(g);m?(l=m,n.onSelect(m)):(n.onAddCustomConditions(),s.consume(!0),l&&(a.value=o(l)))}ke(st`${n.throttlingGroups.map(s=>st`<optgroup
            label=${s.title}>
            ${s.items.map(a=>st`<option
              ${jt.ref(g=>g&&Ut.set(g,a))}
              .selected=${l?p.NetworkManager.networkConditionsEqual(a,l):s===n.throttlingGroups[0]}
              value=${o(a)}
              aria-label=${P(T.sS,{PH1:s.title,PH2:o(a)})}
              jslog=${r(s,a)}>
                ${a===n.recommendedConditions?P(T.recommendedThrottling,{PH1:o(a)}):o(a)}
            </option>`)}
        </optgroup>`)}
        <optgroup label=${n.customConditionsGroup.title}>
          ${n.customConditionsGroup.items.map(s=>st`<option
              ${jt.ref(a=>a&&Ut.set(a,s))}
              .selected=${!!(l&&p.NetworkManager.networkConditionsEqual(s,l))}
              value=${o(s)}
              aria-label=${P(T.sS,{PH1:n.customConditionsGroup.title,PH2:o(s)})}
              jslog=${K.item("custom-network-throttling-item").track({click:!0})}>
                ${s===n.recommendedConditions?P(T.recommendedThrottling,{PH1:o(s)}):o(s)}
          </option>`)}
          <option
            value=${P(T.add)}
            aria-label=${P(T.addS,{PH1:n.customConditionsGroup.title})}
            jslog=${K.action("add").track({click:!0})}>
              ${P(T.add)}
          </option>
        </optgroup>`,e,{container:{listeners:{change:i},attributes:{disabled:n.disabled,"aria-label":n.title,jslog:`${K.dropDown(n.jslogContext).track({change:!0})}`}}})},zt=(t=>(t.CONDITIONS_CHANGED="ConditionsChanged",t))(zt||{});function Qt(n){if(n?.percentiles){let t=Number(n.percentiles.p75);return p.NetworkManager.getRecommendedNetworkPreset(t)}return null}var Me=E.ObjectWrapper.eventMixin(qt.Widget.Widget),J=class n extends Me{#e;#n;#i=null;#o;#t;#r;#s;#a=n.Variant.GLOBAL_CONDITIONS;#l=!1;#d=!1;#c=[];static createForGlobalConditions(t,e){let o=t.createChild("select"),r=new n(o,{title:e});return r.bindToGlobalConditions=!0,r.show(t,void 0,!0),r.performUpdate(),r}constructor(t,e={},o=E.Settings.Settings.instance(),r=Ft){super(t),this.#e=o,this.#n=p.NetworkManager.customUserNetworkConditionsSetting(o),this.#o=e.jslogContext,this.#t=e.currentConditions,this.#r=e.title,this.#s=r,this.performUpdate()}wasShown(){super.wasShown(),this.#n.addChangeListener(this.requestUpdate,this),this.#d&&(this.#h(),this.#m(),this.#u()),this.requestUpdate()}willHide(){super.willHide(),this.#n.removeChangeListener(this.requestUpdate,this),E.EventTarget.removeEventListeners(this.#c)}get disabled(){return this.#l}set disabled(t){this.#l=t,this.requestUpdate()}get recommendedConditions(){return this.#i}set recommendedConditions(t){this.#i=t,this.requestUpdate()}get currentConditions(){return this.#t}set currentConditions(t){this.#t=t,this.requestUpdate()}get jslogContext(){return this.#o}set jslogContext(t){this.#o=t,this.requestUpdate()}#g=t=>{let e=t.data;"block"in e||p.NetworkManager.MultitargetNetworkManager.instance().setNetworkConditions(e)};#m=()=>{this.currentConditions=p.NetworkManager.MultitargetNetworkManager.instance().networkConditions()};#u=()=>{let e=Y.CrUXManager.instance().getSelectedFieldMetricData("round_trip_time");this.recommendedConditions=Qt(e)};#h(){this.#c.push(p.NetworkManager.MultitargetNetworkManager.instance().addEventListener(p.NetworkManager.MultitargetNetworkManager.Events.CONDITIONS_CHANGED,this.#m),Y.CrUXManager.instance().addEventListener(Y.Events.FIELD_DATA_CHANGED,this.#u))}set bindToGlobalConditions(t){t!==this.#d&&(this.#d=t,t?(this.#o=p.NetworkManager.activeNetworkThrottlingKeySetting(this.#e).name,B.instance(),this.#t=p.NetworkManager.MultitargetNetworkManager.instance().networkConditions(),this.addEventListener("ConditionsChanged",this.#g),this.isShowing()&&this.#h(),this.#u()):(this.removeEventListener("ConditionsChanged",this.#g),E.EventTarget.removeEventListeners(this.#c)),this.requestUpdate())}get variant(){return this.#a}set variant(t){this.#a=t,this.requestUpdate()}get title(){return this.#r}set title(t){this.#r=t,this.requestUpdate()}performUpdate(){let t=p.NetworkManager.customUserNetworkConditionsSetting(this.#e),e=t.get(),o=()=>{E.Revealer.reveal(t)},r=a=>{this.dispatchEventToListeners("ConditionsChanged",a)},l=[];switch(this.#a){case n.Variant.GLOBAL_CONDITIONS:l.push({title:P(T.disabled),items:[p.NetworkManager.NoThrottlingConditions]},{title:P(T.presets),items:[p.NetworkManager.Fast4GConditions,p.NetworkManager.Slow4GConditions,p.NetworkManager.Slow3GConditions,p.NetworkManager.OfflineConditions]});break;case n.Variant.INDIVIDUAL_REQUEST_CONDITIONS:l.push({title:P(T.blockingGroup),items:[p.NetworkManager.BlockingConditions]},{title:P(T.presets),items:[p.NetworkManager.Fast4GConditions,p.NetworkManager.Slow4GConditions,p.NetworkManager.Slow3GConditions]});break}let i={title:P(T.custom),items:e},s={recommendedConditions:this.#i,selectedConditions:this.#t,jslogContext:this.#o,title:this.#r,disabled:this.#l,onSelect:r,onAddCustomConditions:o,throttlingGroups:l,customConditionsGroup:i};this.#s(s,void 0,this.contentElement)}};(t=>{let n;(r=>(r.GLOBAL_CONDITIONS="global-conditions",r.INDIVIDUAL_REQUEST_CONDITIONS="individual-request-conditions"))(n=t.Variant||={})})(J||={});var le={};V(le,{CPUThrottlingCard:()=>mt,CPU_THROTTLING_CARD_DEFAULT_VIEW:()=>re,DEFAULT_VIEW:()=>ae,ThrottlingSettingsTab:()=>xt});import"../../ui/components/lists/lists.js";import"../../ui/kit/kit.js";import*as gt from"../../core/common/common.js";import*as H from"../../core/i18n/i18n.js";import*as ne from"../../core/platform/platform.js";import*as Ot from"../../core/sdk/sdk.js";import*as q from"../../ui/components/buttons/buttons.js";import*as ht from"../../ui/legacy/legacy.js";import{Directives as ut,html as S,nothing as A,render as oe}from"../../ui/lit/lit.js";import*as R from"../../ui/visual_logging/visual_logging.js";import*as ie from"../common/common.js";import*as yt from"../../core/i18n/i18n.js";import*as W from"../../core/sdk/sdk.js";import*as dt from"../common/common.js";var Jt={runningCalibration:"Running CPU calibration, don\u2019t leave this tab or close DevTools"},Ne=yt.i18n.registerUIStrings("panels/mobile_throttling/CalibrationController.ts",Jt),Ue=yt.i18n.getLocalizedString.bind(void 0,Ne),De=250,at=1e3,lt=264;function Yt(n){return Number(n.toFixed(2))}var ct=class{#e;#n;#i;#o;#t="idle";async start(){let t=W.TargetManager.TargetManager.instance().primaryPageTarget();if(!t)return!1;let e=t.model(W.RuntimeModel.RuntimeModel),o=t.model(W.EmulationModel.EmulationModel);if(!e||!o)return!1;this.#t="running",this.#e=e,this.#n=o,this.#i=t.inspectedURL();function r(l){let i=document.createElement("span");i.textContent=l,document.body.append(i),document.body.style.cssText=`
        font-family: system-ui, sans-serif;
        height: 100vh;
        margin: 0;
        background-color: antiquewhite;
        font-size: 18px;
        text-align: center;

        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
      `;let s=document.createElement("span");document.body.append(s),s.id="moon",s.textContent="\u{1F311}",s.style.cssText="font-size: 5em"}return await t.pageAgent().invoke_navigate({url:"about:blank"}),await e.agent.invoke_evaluate({expression:`
          (${r})(${JSON.stringify(Ue(Jt.runningCalibration))});

          window.runBenchmark = () => {
            window.runs = window.runs ?? 0;
            moon.textContent = ['\u{1F311}', '\u{1F312}', '\u{1F313}', '\u{1F314}', '\u{1F315}', '\u{1F316}', '\u{1F317}', '\u{1F318}'][window.runs++ % 8];
            return (${ye})(${De});
          }`}),await this.#s(),!0}async#r(t){if(this.#t!=="running")throw this.#o=void 0,new Error("Calibration has been canceled");await this.#n.setCPUThrottlingRate(t)}async#s(){if(this.#t!=="running")throw this.#o=void 0,new Error("Calibration has been canceled");let{result:t}=await this.#e.agent.invoke_evaluate({expression:"runBenchmark()"});if(!Number.isFinite(t.value)){let e=`unexpected score from benchmark: ${t.value}`;throw t.description&&(e+=`
${t.description}`),new Error(e)}return t.value}async*iterator(){let t=this,e=!1;yield{progress:0};let o=new Map;async function r(m){let h=o.get(m);if(h!==void 0)return h;await t.#r(m);let f=await t.#s();return o.set(m,f),f}async function*l(m,h,f){let F={rate:h,score:await r(h)},$={rate:f,score:await r(f)},O=0,z=0,tt=8;for(;z++<tt;){O=Yt(($.rate+F.rate)/2);let x=await r(O);if(Math.abs(m-x)<10)break;x<m?($.rate=O,$.score=x):(F.rate=O,F.score=x),yield{progress:z/tt/2+(e?.5:0)}}return Yt(O)}this.#o={};let i=await r(1);if(i<at&&(o.clear(),i=await r(1),i<at)){if(i<lt){this.#o={low:dt.CPUThrottlingOption.CalibrationError.DEVICE_TOO_WEAK,mid:dt.CPUThrottlingOption.CalibrationError.DEVICE_TOO_WEAK,actualScore:i};return}this.#o={mid:dt.CPUThrottlingOption.CalibrationError.DEVICE_TOO_WEAK},e=!0}let s=1,a=i/lt*1.5,g=yield*l(lt,s,a);if(this.#o.low=g,!this.#o.mid){e=!0,yield{progress:.5};let m=at/lt,h=g/m,f=yield*l(at,h-h/4,h+h/4);this.#o.mid=f}this.#o.actualScore=i,yield{progress:1}}abort(){this.#t==="running"&&(this.#t="aborting")}result(){return this.#o}async end(){this.#t!=="idle"&&(this.#t="idle",this.#i.startsWith("chrome://")?await this.#e.agent.invoke_evaluate({expression:"history.back()"}):await this.#e.agent.invoke_evaluate({expression:`window.location.href = ${JSON.stringify(this.#i)}`}))}};function ye(n=1e3){let t=n/2;function e(){let r=Date.now(),l=0;for(;Date.now()-r<t;){let s="";for(let a=0;a<1e4;a++)s+="a";if(s.length===1)throw new Error("will never happen, but prevents compiler optimizations");l++}let i=(Date.now()-r)/1e3;return Math.round(l/10/i)}function o(){let r=[],l=[];for(let g=0;g<1e5;g++)r[g]=l[g]=g;let i=Date.now(),s=0;for(;s%10!==0||Date.now()-i<t;){let g=s%2===0?r:l,m=s%2===0?l:r;for(let h=0;h<g.length;h++)m[h]=g[h];s++}let a=(Date.now()-i)/1e3;return Math.round(s/10/a)}return(e()+o())/2}var Zt=`.add-conditions-button{margin:var(--sys-size-5) 0;border:none}.conditions-list{flex:auto;&:has(.list-item){margin-top:var(--sys-size-3)}}.settings-container{display:flex;overflow-x:auto}.settings-container::-webkit-scrollbar{-webkit-appearance:none;height:var(--sys-size-4)}.settings-container::-webkit-scrollbar-thumb{border-radius:var(--sys-shape-corner-extra-small);background-color:var(--sys-color-primary)}.setting{display:flex;flex-direction:column;justify-content:space-between;align-items:flex-start;gap:var(--sys-size-3);padding:var(--sys-size-4);flex-shrink:0;width:calc(var(--sys-size-19) - var(--sys-size-4))}.input{width:100%}.conditions-list-item{padding:3px 5px;height:30px;display:flex;align-items:center;position:relative;flex:auto 1 1}.conditions-list-text{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;flex-basis:var(--sys-size-24);user-select:none;color:var(--sys-color-on-surface);text-align:center;position:relative}.conditions-list-text:last-child{flex-basis:100px;text-align:left}.conditions-list-title{text-align:start;display:flex;flex-grow:1;align-items:flex-start}.conditions-list-title-text{flex:auto;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.conditions-list-separator{flex:0 0 var(--sys-size-1);background-color:var(--sys-color-divider);height:30px;margin:0 var(--sys-size-3)}.settings-card-container-wrapper{scrollbar-gutter:stable;padding:var(--sys-size-8) 0;overflow:auto;position:absolute;inset:var(--sys-size-8) 0 0}.settings-card-container{display:flex;flex-direction:column;align-items:center;gap:var(--sys-size-9)}.cpu-preset-section{padding:var(--sys-size-7);display:flex;justify-content:space-between}.cpu-preset-result.not-calibrated{font-style:italic}.cpu-preset-calibrate{flex-direction:column;gap:var(--sys-size-7)}.cpu-preset-calibrate .button-container{display:flex;gap:var(--sys-size-5)}.cpu-preset-calibrate .text-container{display:flex;flex-direction:column;gap:var(--sys-size-5)}.text-with-icon{display:flex;align-items:center;gap:var(--sys-size-3)}.conditions-list-header{font-weight:bold;border-bottom:var(--sys-size-1) solid var(--sys-color-divider)}.editor-container{display:flex;flex-direction:column;align-items:stretch;flex:none;background:var(--sys-color-surface3);overflow:hidden}.editor-content{flex:auto;display:flex;flex-direction:column;align-items:stretch}.editor-content input{margin-right:10px}.editor-content input.error-input{background-color:var(--sys-color-cdt-base-container)}.editor-buttons{flex:none;display:flex;flex-direction:row;align-items:center;justify-content:flex-start;padding:5px;gap:var(--sys-size-6)}.list-widget-input-validation-error{color:var(--sys-color-error);margin:0 5px}.editor-container ~ .add-conditions-button{display:none}
/*# sourceURL=${import.meta.resolve("./throttlingSettingsTab.css")} */`;var{widget:Ee}=ht.Widget,d={defaultProfiles:"Default profiles",customProfiles:"Custom profiles",addCustomProfile:"Add profile",dms:"{PH1} `ms`",profileName:"Profile name",download:"Download",upload:"Upload",latency:"Latency",packetLoss:"Packet Loss",calibratedLowTierMobile:"Low-tier mobile device",calibratedMidTierMobile:"Mid-tier mobile device",packetQueueLength:"Packet Queue Length",packetReordering:"Packet Reordering",packet:"packet",optional:"optional",profileNameCharactersLengthMust:"Profile name length must be between 1 and {PH1} characters",sMustBeANumberBetweenSkbsToSkbs:"{PH1} must be a number between {PH2} `kbit/s` to {PH3} `kbit/s` inclusive",latencyMustBeAnIntegerBetweenSms:"Latency must be an integer between {PH1} `ms` to {PH2} `ms` inclusive",packetLossMustBeAnIntegerBetweenSpct:"Packet Loss must be a number between {PH1} `%` to {PH2} `%` inclusive",packetQueueLengthMustBeAnIntegerGreaterOrEqualToZero:"Packet queue length must be greater than or equal to 0",dskbits:"{PH1} `kbit/s`",fsmbits:"{PH1} `Mbit/s`",on:"On",off:"Off",cpuThrottlingPresets:"CPU throttling presets",calibrate:"Calibrate",recalibrate:"Recalibrate",continue:"Continue",cancel:"Cancel",save:"Save",add:"Add",needsCalibration:"Needs calibration",calibrationCTA:"To use the CPU throttling presets, run the calibration process to determine the ideal throttling rate for your device",cpuCalibrationDescription:"These presets throttle your CPU to approximate the performance of typical low or mid-tier mobile devices",calibrationConfirmationPrompt:"Calibration will take ~5 seconds, and temporarily navigate away from your current page. Do you wish to continue?",calibrationWarningHighCPU:"CPU utilization is too high",calibrationWarningRunningOnBattery:"Device is running on battery. Plug in charger for best results.",calibrationWarningLowBattery:"Device battery is low (<20%). Results may be impacted by CPU throttling.",dSlowdown:"{PH1}\xD7 slowdown"},Oe=H.i18n.registerUIStrings("panels/mobile_throttling/ThrottlingSettingsTab.ts",d),c=H.i18n.getLocalizedString.bind(void 0,Oe);function xe(n){let t={state:""};return typeof PressureObserver>"u"?Promise.resolve(t):new Promise(e=>{let o=new PressureObserver(l=>{t.state=l.at(-1).state,e(t)}),r=()=>{o.disconnect(),e(t)};if(n.aborted){r();return}n.addEventListener("abort",r,{once:!0}),o.observe("cpu",{sampleInterval:1e3}).catch(()=>{r()})})}var re=(n,t,e)=>{let o=(g,m)=>S`
    <div class="text-with-icon">
      <devtools-icon name=${m}></devtools-icon>
      ${g}
    </div>
  `,r=n.state==="cta"||n.state==="prompting",l=n.state==="prompting"?c(d.continue):n.hasCalibrated?c(d.recalibrate):c(d.calibrate),i=n.state==="prompting"||n.state==="calibrating",s=n.state==="cta"&&!n.hasCalibrated||n.state==="prompting",a=n.state==="calibrating";oe(S`
        <devtools-card heading=${c(d.cpuThrottlingPresets)}>
          <span>${c(d.cpuCalibrationDescription)}</span>
          <div class="cpu-preset-section">
            ${c(d.calibratedLowTierMobile)}
            <div class=${ut.classMap({"cpu-preset-result":!0,"not-calibrated":n.lowNotCalibrated})}>
              ${n.lowResultText}
            </div>
          </div>
          <div class="cpu-preset-section">
            ${c(d.calibratedMidTierMobile)}
            <div class=${ut.classMap({"cpu-preset-result":!0,"not-calibrated":n.midNotCalibrated})}>
              ${n.midResultText}
            </div>
          </div>
          <div class="cpu-preset-section cpu-preset-calibrate">
            <div class="button-container">
              <devtools-button
                class="calibrate-button"
                style=${r?"":"display: none"}
                .variant=${q.Button.Variant.PRIMARY}
                .jslogContext=${"throttling.calibrate"}
                @click=${n.onCalibrateClick}>
                ${l}
              </devtools-button>
              <devtools-button
                class="cancel-button"
                style=${i?"":"display: none"}
                .variant=${q.Button.Variant.OUTLINED}
                .jslogContext=${"throttling.calibrate-cancel"}
                @click=${n.onCancelClick}>
                ${c(d.cancel)}
              </devtools-button>
            </div>
            <div
              class="text-container"
              style=${s?"":"display: none"}>
              ${n.state==="cta"&&!n.hasCalibrated?o(c(d.calibrationCTA),"info"):A}
              ${n.state==="prompting"?S`
                ${n.warnings.map(g=>o(g,"warning"))}
                ${o(c(d.calibrationConfirmationPrompt),"info")}
              `:A}
            </div>
            <devtools-progress
              no-stop-button
              style=${a?"":"display: none"}
              .worked=${n.progressWorked}
              .totalWork=${1}>
            </devtools-progress>
          </div>
        </devtools-card>
      `,e)},mt=class extends ht.Widget.Widget{#e;computePressurePromise;computePressureAbortController;controller;state="cta";warnings=[];#n;#i=0;constructor(t,e=re){super(t),this.#n=e,this.performUpdate()}wasShown(){super.wasShown(),this.computePressureAbortController||(this.computePressureAbortController=new AbortController,this.computePressurePromise=xe(this.computePressureAbortController.signal)),this.state="cta",this.performUpdate()}willHide(){super.willHide(),this.computePressureAbortController?.abort(),this.computePressureAbortController=void 0,this.computePressurePromise=void 0,this.controller&&this.controller.abort()}performUpdate(){!this.#e&&gt.Settings.Settings.hasInstance()&&(this.#e=gt.Settings.Settings.instance().createSetting("calibrated-cpu-throttling",{},gt.Settings.SettingStorageType.GLOBAL)),this.state!=="calibrating"&&(this.controller=void 0);let t=this.#e?.get()??{},e=!!(t.low||t.mid),o=r=>r===void 0?c(d.needsCalibration):typeof r=="string"?ie.CPUThrottlingOption.calibrationErrorToString(r):typeof r!="number"?`Invalid: ${r}`:c(d.dSlowdown,{PH1:r.toFixed(1)});this.#n({state:this.state,hasCalibrated:e,lowResultText:o(t.low),lowNotCalibrated:t.low===void 0,midResultText:o(t.mid),midNotCalibrated:t.mid===void 0,warnings:this.warnings,progressWorked:this.#i,onCalibrateClick:()=>{this.calibrateButtonClicked()},onCancelClick:()=>this.cancelButtonClicked()},void 0,this.element)}async getCalibrationWarnings(){let t=[];if(this.computePressurePromise){let o=await this.computePressurePromise;(o.state==="critical"||o.state==="serious")&&t.push(c(d.calibrationWarningHighCPU))}let e=await navigator.getBattery();return e.charging?e.level<.2&&t.push(c(d.calibrationWarningLowBattery)):t.push(c(d.calibrationWarningRunningOnBattery)),t}async calibrateButtonClicked(){this.state==="cta"?(this.warnings=await this.getCalibrationWarnings(),this.state="prompting",this.requestUpdate()):this.state==="prompting"&&(this.state="calibrating",this.requestUpdate(),this.runCalibration())}cancelButtonClicked(){this.controller?this.controller.abort():(this.state="cta",this.requestUpdate())}async runCalibration(){this.#i=0,this.requestUpdate(),this.controller=new ct;try{if(!await this.controller.start()){console.error("Calibration failed to start");return}for await(let e of this.controller.iterator())this.#i=e.progress,this.requestUpdate()}catch(e){console.error(e)}finally{await this.controller.end()}let t=this.controller.result();t&&(t.low||t.mid)&&this.#e&&(this.#e.set(t),this.#i=1,this.requestUpdate(),await new Promise(e=>setTimeout(e,200))),this.state="cta",this.requestUpdate()}};function Le(n){let t=n.match(/USER_CUSTOM_SETTING_(\d+)/);return t?.[1]?parseInt(t[1],10):0}function se(n){return typeof n.title=="function"?n.title():n.title}function te(){let n=c(d.profileName),t=[c(d.download),c(d.upload),c(d.latency),c(d.packetLoss),c(d.packetQueueLength),c(d.packetReordering)];return S`
    <div class="conditions-list-item conditions-list-header">
      <div class="conditions-list-text conditions-list-title" title=${n}>
        <div class="conditions-list-title-text">${n}</div>
      </div>
      ${t.map(e=>S`
        <div class="conditions-list-separator"></div>
        <div class="conditions-list-text" title=${e}>${e}</div>
      `)}
    </div>
  `}function Et(n){let t=se(n),e=ee(n.download),o=ee(n.upload),r=c(d.dms,{PH1:n.latency}),l=$e(n.packetLoss??0),i=String(n.packetQueueLength??0),s=n.packetReordering?c(d.on):c(d.off);return S`
    <div class="conditions-list-item">
      <div class="conditions-list-text conditions-list-title" title=${t}>
        <div class="conditions-list-title-text">${t}</div>
      </div>
      <div class="conditions-list-separator"></div>
      <div class="conditions-list-text">${e}</div>
      <div class="conditions-list-separator"></div>
      <div class="conditions-list-text">${o}</div>
      <div class="conditions-list-separator"></div>
      <div class="conditions-list-text">${r}</div>
      <div class="conditions-list-separator"></div>
      <div class="conditions-list-text">${l}</div>
      <div class="conditions-list-separator"></div>
      <div class="conditions-list-text">${i}</div>
      <div class="conditions-list-separator"></div>
      <div class="conditions-list-text">${s}</div>
    </div>
  `}function Ie(n){let t=n.editingIndex===n.customConditions.length,e=c(d.optional),o=[{name:"title",labelText:c(d.profileName),placeholder:"",isOptional:!1},{name:"download",labelText:c(d.download),placeholder:H.i18n.lockedString("kbit/s"),isOptional:!0},{name:"upload",labelText:c(d.upload),placeholder:H.i18n.lockedString("kbit/s"),isOptional:!0},{name:"latency",labelText:c(d.latency),placeholder:H.i18n.lockedString("ms"),isOptional:!0},{name:"packetLoss",labelText:c(d.packetLoss),placeholder:H.i18n.lockedString("percent"),isOptional:!0},{name:"packetQueueLength",labelText:c(d.packetQueueLength),placeholder:c(d.packet),isOptional:!0}],r=Object.values(n.validationErrors).filter(Boolean),l=r.length>0;return S`
    <div
        class="editor-container"
        jslog=${R.pane("editor").track({resize:!0})}
        @keydown=${i=>{ne.KeyboardUtilities.isEscKey(i)&&(i.consume(!0),n.onCancelEdit())}}>
      <div
          class="editor-content"
          @keydown=${i=>{i.key==="Enter"&&(i.consume(!0),n.onCommitEdit())}}>
        <div class="settings-container">
          ${o.map((i,s)=>{let a=n.showValidationErrors&&!!n.validationErrors[i.name];return S`
              <div class="setting">
                <div>${i.labelText}</div>
                <div>
                  <input
                      class=${ut.classMap({"harmony-input":!0,input:!0,"error-input":a})}
                      type="text"
                      ?autofocus=${s===0}
                      placeholder=${i.placeholder}
                      aria-label=${i.labelText}
                      aria-description=${e}
                      aria-invalid=${a?"true":"false"}
                      .value=${ut.live(n.editingValues[i.name])}
                      jslog=${R.textField().track({change:!0,keydown:"Enter"}).context(i.name)}
                      @input=${g=>n.onEditorInput(i.name,g.target.value)}>
                  <div style=${i.isOptional?"":"visibility: hidden"}>
                    ${e}
                  </div>
                </div>
              </div>
            `})}
          <div class="setting">
            <div>${c(d.packetReordering)}</div>
            <div>
              <devtools-checkbox
                  class="input"
                  aria-label=${c(d.packetReordering)}
                  aria-description=${e}
                  .checked=${n.editingValues.packetReordering}
                  .jslogContext=${"packetReordering"}
                  @change=${i=>n.onEditorInput("packetReordering",i.target.checked)}>
              </devtools-checkbox>
              <div style="visibility: hidden">
                ${e}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="editor-buttons">
        <devtools-button
            .variant=${q.Button.Variant.OUTLINED}
            .jslogContext=${"cancel"}
            jslog=${R.action("cancel").track({click:!0})}
            @click=${n.onCancelEdit}>
          ${c(d.cancel)}
        </devtools-button>
        <devtools-button
            .variant=${q.Button.Variant.PRIMARY}
            .jslogContext=${"commit"}
            .disabled=${l}
            @click=${n.onCommitEdit}>
          ${c(t?d.add:d.save)}
        </devtools-button>
      </div>
      <div class="list-widget-input-validation-error" role="alert" aria-live="polite">
        ${n.showValidationErrors&&l?r.map((i,s)=>S`${s>0?S`<br>`:A}${i}`):A}
      </div>
    </div>
  `}var ae=(n,t,e)=>{let o=n.editingIndex,r=o!==null?n.customConditions.slice(0,o):n.customConditions,l=o!==null?n.customConditions.slice(o+1):[];oe(S`
        <style>${Zt}</style>
        <div class="settings-card-container-wrapper">
          <div class="settings-card-container throttling-conditions-settings">
            ${Ee(mt)}
            <devtools-card heading=${c(d.defaultProfiles)}>
              <div>
                ${te()}
                <devtools-list class="conditions-list">
                  ${n.presets.map(i=>Et(i))}
                </devtools-list>
              </div>
            </devtools-card>
            <devtools-card heading=${c(d.customProfiles)}>
              <div>
                ${te()}
                ${r.length>0?S`
                  <devtools-list
                      class="conditions-list"
                      editable
                      deletable
                      @edit=${i=>n.onBeginEdit(i.detail.index)}
                      @delete=${i=>n.onRemoveCustomProfile(i.detail.index)}>
                    ${r.map(i=>Et(i))}
                  </devtools-list>
                `:A}
                ${o!==null?Ie(n):A}
                ${o!==null&&l.length>0?S`
                  <devtools-list
                      class="conditions-list"
                      editable
                      deletable
                      @edit=${i=>n.onBeginEdit(o+1+i.detail.index)}
                      @delete=${i=>n.onRemoveCustomProfile(o+1+i.detail.index)}>
                    ${l.map(i=>Et(i))}
                  </devtools-list>
                `:A}
                <devtools-button
                  class="add-conditions-button"
                  .variant=${q.Button.Variant.OUTLINED}
                  .iconName=${"plus"}
                  .jslogContext=${"network.add-conditions"}
                  @click=${n.onAddCustomProfile}>
                  ${c(d.addCustomProfile)}
                </devtools-button>
              </div>
            </devtools-card>
          </div>
        </div>
      `,e,{container:{attributes:{jslog:`${R.pane("throttling-conditions")}`}}})},Z={title:"",download:"",upload:"",latency:"",packetLoss:"",packetQueueLength:"",packetReordering:!1},xt=class extends ht.Widget.VBox{customUserConditions;#e;#n;#i=null;#o=null;#t={...Z};#r=!1;constructor(t,e=ae){super({useShadowDom:!0}),this.#e=e,this.customUserConditions=Ot.NetworkManager.customUserNetworkConditionsSetting(t),this.customUserConditions.addChangeListener(this.#s,this);let l=this.customUserConditions.get().at(-1)?.key;if(l&&Ot.NetworkManager.keyIsCustomUser(l)){let i=Le(l);this.#n=i}else this.#n=0;this.performUpdate()}performUpdate(){let t=this.customUserConditions.get(),e=this.#i!==null?this.#u(this.#t):{};this.#e({presets:k.networkPresets,customConditions:t,editingIndex:this.#i,editingValues:this.#t,validationErrors:e,showValidationErrors:this.#r,onAddCustomProfile:()=>this.#a(),onBeginEdit:this.#l.bind(this),onRemoveCustomProfile:this.#m.bind(this),onEditorInput:this.#d.bind(this),onCommitEdit:this.#g.bind(this),onCancelEdit:this.#c.bind(this)},void 0,this.contentElement)}wasShown(){super.wasShown(),this.#s(),this.performUpdate()}#s(){this.#i=null,this.#o=null,this.#t={...Z},this.#r=!1,this.requestUpdate()}#a(){this.#n++;let t=this.customUserConditions.get();this.#i=t.length,this.#o={key:`USER_CUSTOM_SETTING_${this.#n}`,title:()=>"",download:-1,upload:-1,latency:0,packetLoss:0,packetReordering:!1},this.#t={...Z},this.#r=!1,this.requestUpdate()}#l(t){let o=this.customUserConditions.get()[t];o&&(this.#i=t,this.#o=o,this.#t={title:se(o),download:o.download<=0?"":String(o.download/(1e3/8)),upload:o.upload<=0?"":String(o.upload/(1e3/8)),latency:o.latency?String(o.latency):"",packetLoss:o.packetLoss?String(o.packetLoss):"",packetQueueLength:o.packetQueueLength?String(o.packetQueueLength):"",packetReordering:o.packetReordering??!1},this.#r=!1,this.requestUpdate())}#d(t,e){this.#t={...this.#t,[t]:e},this.#r=!0,this.requestUpdate()}#c(){this.#i=null,this.#o=null,this.#t={...Z},this.#r=!1,this.requestUpdate()}#g(){if(this.#i===null||!this.#o)return;let t=this.#u(this.#t);if(Object.keys(t).length>0){this.#r=!0,this.requestUpdate();return}let e=this.#o;e.title=this.#t.title.trim();let o=this.#t.download.trim();e.download=o?parseInt(o,10)*(1e3/8):-1;let r=this.#t.upload.trim();e.upload=r?parseInt(r,10)*(1e3/8):-1;let l=this.#t.latency.trim();e.latency=l?parseInt(l,10):0;let i=this.#t.packetLoss.trim();e.packetLoss=i?parseFloat(i):0;let s=this.#t.packetQueueLength.trim();e.packetQueueLength=s?parseFloat(s):0,e.packetReordering=this.#t.packetReordering;let a=[...this.customUserConditions.get()];this.#i===a.length&&a.push(e),this.#i=null,this.#o=null,this.#t={...Z},this.#r=!1,this.customUserConditions.set(a)}#m(t){let e=[...this.customUserConditions.get()];e.splice(t,1),this.customUserConditions.set(e)}#u(t){let e={},r=t.title.trim();(r.length===0||r.length>49)&&(e.title=c(d.profileNameCharactersLengthMust,{PH1:49}));let l=0,i=1e7,s=t.download.trim(),a=Number(s);(Number.isNaN(a)||a<l||a>i)&&(e.download=c(d.sMustBeANumberBetweenSkbsToSkbs,{PH1:c(d.download),PH2:l,PH3:i}));let g=t.upload.trim(),m=Number(g);(Number.isNaN(m)||m<l||m>i)&&(e.upload=c(d.sMustBeANumberBetweenSkbsToSkbs,{PH1:c(d.upload),PH2:l,PH3:i}));let h=0,f=1e6,F=t.latency.trim(),$=Number(F);(!Number.isInteger($)||$<h||$>f)&&(e.latency=c(d.latencyMustBeAnIntegerBetweenSms,{PH1:h,PH2:f}));let O=0,z=100,tt=t.packetLoss.trim(),x=Number(tt);(Number.isNaN(x)||x<O||x>z)&&(e.packetLoss=c(d.packetLossMustBeAnIntegerBetweenSpct,{PH1:O,PH2:z}));let de=0,ce=t.packetQueueLength.trim(),Lt=Number(ce);return(Number.isNaN(Lt)||Lt<de)&&(e.packetQueueLength=c(d.packetQueueLengthMustBeAnIntegerGreaterOrEqualToZero)),e}};function ee(n){if(n<0)return"";let t=n/(1e3/8);if(t<1e3)return c(d.dskbits,{PH1:t});if(t<1e3*10){let e=(t/1e3).toFixed(1);return c(d.fsmbits,{PH1:e})}return c(d.fsmbits,{PH1:t/1e3|0})}function $e(n){return n<0?"":String(n)+"%"}export{Gt as CPUThrottlingSelector,_t as NetworkPanelIndicator,Xt as NetworkThrottlingSelector,Ht as ThrottlingManager,It as ThrottlingPresets,le as ThrottlingSettingsTab};
//# sourceMappingURL=mobile_throttling.js.map
