var q=Object.defineProperty;var g=(o,t)=>{for(var e in t)q(o,e,{get:t[e],enumerable:!0})};var I={};g(I,{VideoType:()=>v,getReleaseNote:()=>i,setReleaseNoteForTest:()=>X});import*as T from"../../ui/components/markdown_view/markdown_view.js";var S=!1,v=(n=>(n.WHATS_NEW="WhatsNew",n.DEVTOOLS_TIPS="DevtoolsTips",n.OTHER="Other",n))(v||{});function X(o){p=o}function i(){if(!S){for(let{key:o,link:t}of p.markdownLinks)T.MarkdownLinksMap.markdownLinks.set(o,t);S=!0}return p}var p={version:158,header:"New in DevTools (November 2026)",announcement:{title:"Modern Web Guidance is now stable!",description:"Upgrade your coding agents with expert-vetted web development best practices.",link:{url:"https://goo.gle/mwg-stable",text:"Read the announcement"}},markdownLinks:[{key:"mcp",link:"https://developer.chrome.com/blog/new-in-devtools-november-2026/#mcp"},{key:"sources",link:"https://developer.chrome.com/blog/new-in-devtools-november-2026/#sources"},{key:"web-install-manifest-diagnosti",link:"https://developer.chrome.com/blog/new-in-devtools-november-2026/#web-install-manifest-diagnosti"}],videoLinks:[],link:"https://developer.chrome.com/blog/new-in-devtools-november-2026/"};var E={};g(E,{DEVTOOLS_TIPS_THUMBNAIL:()=>$,GENERAL_THUMBNAIL:()=>C,ReleaseNoteView:()=>d,WHATS_NEW_THUMBNAIL:()=>D,getMarkdownContent:()=>H});import"../../ui/components/markdown_view/markdown_view.js";import"../../ui/kit/kit.js";import*as u from"../../core/i18n/i18n.js";import*as z from"../../third_party/marked/marked.js";import*as U from"../../ui/components/buttons/buttons.js";import*as M from"../../ui/helpers/helpers.js";import*as V from"../../ui/legacy/legacy.js";import{html as l,nothing as R,render as Y}from"../../ui/lit/lit.js";import*as A from"../../ui/visual_logging/visual_logging.js";var P=`@scope to (devtools-widget > *){.whatsnew{background:var(--sys-color-header-container);flex-grow:1;flex-shrink:0;display:flex;width:100%;height:100%;overflow:auto;justify-content:center}.whatsnew-content{max-width:var(--sys-size-35);padding:var(--sys-size-9) 0 0;>*{padding:0 var(--sys-size-9) var(--sys-size-9) var(--sys-size-9)}}.header{display:flex;align-items:center;font:var(--sys-typescale-headline4);&::before{content:"";width:var(--sys-size-9);height:var(--sys-size-9);transform:scale(1.6);margin:0 var(--sys-size-8) 0 var(--sys-size-4);background-image:var(--image-file-devtools);flex-shrink:0}}.feature-container{flex-grow:1;padding:0;background-color:var(--sys-color-surface);border-radius:var(--sys-shape-corner-large) var(--sys-shape-corner-large) 0 0;display:flex;flex-direction:column}.feature{background-color:var(--sys-color-surface3);padding:0 var(--sys-size-8) var(--sys-size-8);border-radius:var(--sys-shape-corner-medium);margin:0 var(--sys-size-9) var(--sys-size-9)}.announcement{display:flex;align-items:flex-start;gap:var(--sys-size-6);padding:var(--sys-size-8);margin:var(--sys-size-9) var(--sys-size-9) 0;background:linear-gradient(135deg,var(--sys-color-gradient-primary),var(--sys-color-gradient-tertiary));border:var(--sys-size-1) solid var(--sys-color-tonal-outline);color:var(--sys-color-on-surface);user-select:text;&::before{content:"";width:var(--sys-size-9);height:var(--sys-size-9);flex-shrink:0;background-color:var(--sys-color-primary-bright);mask-image:var(--image-file-bell);mask-repeat:no-repeat;mask-position:center;mask-size:contain}}.announcement-content{flex:1;min-width:0;h3{font:var(--sys-typescale-body2-bold);margin:0 0 var(--sys-size-7)}p{font:var(--sys-typescale-body4-regular);line-height:18px;margin:0}}.video-container{margin-bottom:var(--sys-size-9);&:has(.video){--video-bottom-padding:var(--sys-size-6);overflow:auto;display:flex;flex-direction:row;gap:var(--sys-size-5);padding:var(--sys-size-9) var(--sys-size-9) var(--video-bottom-padding);margin-bottom:calc(var(--sys-size-9) - var(--video-bottom-padding));> *{min-width:auto}}}.video{align-items:center;display:flex;flex-direction:row;border-radius:var(--sys-shape-corner-medium);background-color:var(--sys-color-surface3);font:var(--sys-typescale-body5-regular);min-width:var(--sys-size-29);max-width:var(--sys-size-32);overflow:hidden;height:72px;&:hover{box-shadow:var(--sys-elevation-level3)}.thumbnail{border-radius:var(--sys-shape-corner-medium) 0 0 var(--sys-shape-corner-medium);flex-shrink:0}.thumbnail-description{--description-margin:var(--sys-size-6);margin:var(--description-margin);height:calc(100% - var(--description-margin) * 2);overflow:hidden}}devtools-link:focus .video{outline:var(--sys-size-2) solid var(--sys-color-state-focus-ring)}@media (forced-colors: active){.feature,
    .video{border:var(--sys-size-1) solid ButtonText}.announcement{border-width:var(--sys-size-2);&::before{background-color:ButtonText;forced-color-adjust:none}}}}
/*# sourceURL=${import.meta.resolve("./releaseNoteView.css")} */`;var L={seeFeatures:"See all new features"},J=u.i18n.registerUIStrings("panels/whats_new/ReleaseNoteView.ts",L),K=u.i18n.getLocalizedString.bind(void 0,J),D="../../Images/whatsnew.svg",$="../../Images/devtools-tips.svg",C="../../Images/devtools-thumbnail.svg";async function H(){let o=await d.getFileContent(),t=z.Marked.lexer(o),e=[],n=Number.MAX_SAFE_INTEGER;return t.forEach(r=>{r.type==="heading"&&n>=r.depth?(e.push([r]),n=r.depth):e.length>0?e[e.length-1].push(r):e.push([r])}),e}var d=class extends V.Panel.Panel{#e;constructor(t=(e,n,r)=>{let s=e.getReleaseNote(),G=e.markdownContent;Y(l`
      <style>${P}</style>
      <div class="whatsnew" jslog=${A.section().context("release-notes")}>
        <div class="whatsnew-content">
          <div class="header">
            ${s.header}
          </div>
          <div>
            <devtools-button
                  .variant=${U.Button.Variant.PRIMARY}
                  .jslogContext=${"learn-more"}
                  @click=${()=>e.openNewTab(s.link)}
              >${K(L.seeFeatures)}</devtools-button>
          </div>

          <div class="feature-container">
            ${s.announcement?l`
              <div class="feature announcement">
                <div class="announcement-content">
                  <h3>${s.announcement.title}</h3>
                  <p>
                    ${s.announcement.description}${s.announcement.link?l`${" "}<devtools-link
                        href=${s.announcement.link.url}
                        jslogcontext="learn-more"
                      >${s.announcement.link.text}</devtools-link>`:R}
                  </p>
                </div>
              </div>
            `:R}
            <div class="video-container">
              ${s.videoLinks.map(a=>l`
                  <devtools-link
                  href=${a.link}
                  jslogcontext="learn-more">
                    <div class="video">
                      <img class="thumbnail" src=${e.getThumbnailPath(a.type??"WhatsNew")}>
                      <div class="thumbnail-description"><span>${a.description}</span></div>
                    </div>
                </devtools-link>
                `)}
            </div>
            ${G.map(a=>l`
                  <div class="feature">
                    <devtools-markdown-view slot="content" .data=${{tokens:a}}>
                    </devtools-markdown-view>
                  </div>`)}
          </div>
        </div>
      </div>
    `,r)}){super("whats-new",!0),this.#e=t,this.requestUpdate()}static async getFileContent(){let t=new URL("./resources/WNDT.md",import.meta.url);try{return await(await fetch(t.toString())).text()}catch{throw new Error(`Markdown file ${t.toString()} not found. Make sure it is correctly listed in the relevant BUILD.gn files.`)}}async performUpdate(){let t=await H();this.#e({getReleaseNote:i,openNewTab:M.openInNewTab,markdownContent:t,getThumbnailPath:this.#t},this,this.contentElement)}#t(t){let e;switch(t){case"WhatsNew":e=D;break;case"DevtoolsTips":e=$;break;case"Other":e=C;break}return new URL(e,import.meta.url).toString()}};var F={};g(F,{HelpLateInitialization:()=>k,ReleaseNotesActionDelegate:()=>b,ReportIssueActionDelegate:()=>N,getReleaseNoteVersionSetting:()=>Q,releaseNoteViewId:()=>B,releaseVersionSeen:()=>m,showReleaseNoteIfNeeded:()=>j});import*as c from"../../core/common/common.js";import*as _ from"../../core/host/host.js";import*as x from"../../ui/helpers/helpers.js";import*as W from"../../ui/legacy/legacy.js";import*as O from"../../ui/settings/settings.js";var m="releaseNoteVersionSeen",B="release-note",f;function j(){let t=c.Settings.Settings.instance().createSetting(m,0).get(),e=i();return Z(t,e.version,c.Settings.Settings.instance().resolve(O.WhatsNewSettings.showReleaseNoteSettingDescriptor).get())}function Q(){return f||(f=c.Settings.Settings.instance().createSetting(m,0)),f}function Z(o,t,e){let n=c.Settings.Settings.instance().createSetting(m,0);return o?!e||o>=t?!1:(n.set(t),W.ViewManager.ViewManager.instance().showView(B,!0),!0):(n.set(t),!1)}var h,k=class o{static instance(t={forceNew:null}){let{forceNew:e}=t;return(!h||e)&&(h=new o),h}async run(){_.InspectorFrontendHost.isUnderTest()||j()}},w,b=class o{handleAction(t,e){let n=i();return x.openInNewTab(n.link),!0}static instance(t={forceNew:null}){let{forceNew:e}=t;return(!w||e)&&(w=new o),w}},y,N=class o{handleAction(t,e){return x.openInNewTab("https://goo.gle/devtools-bug"),!0}static instance(t={forceNew:null}){let{forceNew:e}=t;return(!y||e)&&(y=new o),y}};export{I as ReleaseNoteText,E as ReleaseNoteView,F as WhatsNew};
//# sourceMappingURL=whats_new.js.map
