var te=Object.defineProperty;var ie=(l,e)=>{for(var t in e)te(l,t,{get:e[t],enumerable:!0})};var ee={};ie(ee,{DEFAULT_VIEW:()=>Z,DevicesSettingsTab:()=>k});import"../../../ui/components/lists/lists.js";import"../../../ui/kit/kit.js";import*as z from"../../../core/i18n/i18n.js";import*as H from"../../../core/platform/platform.js";import*as U from"../../../core/root/root.js";import*as o from"../../../models/emulation/emulation.js";import*as N from"../../../ui/components/buttons/buttons.js";import*as q from"../../../ui/components/input/input.js";import*as _ from"../../../ui/legacy/legacy.js";import{Directives as ae,html as E,nothing as A,render as se}from"../../../ui/lit/lit.js";import*as p from"../../../ui/visual_logging/visual_logging.js";import*as W from"./components/components.js";var X=`.device-card-content{padding-left:0;padding-right:0}.device-group-container{margin-bottom:var(--sys-size-5)}.device-group-title{font-weight:600;color:var(--sys-color-on-surface-subtle);font-size:var(--sys-typescale-body5-size);text-transform:uppercase;letter-spacing:0.5px;margin:var(--sys-size-6) 0 var(--sys-size-3)}.list{&:has(div){border:none}}#custom-device-add-button{padding:var(--sys-size-5) var(--sys-size-6)}.devices-list-item{padding:var(--sys-size-3) var(--sys-size-6);height:var(--sys-size-13);display:flex;align-items:center;flex:auto 1 1;overflow:hidden;color:var(--sys-color-on-surface);user-select:none;white-space:nowrap;text-overflow:ellipsis}.devices-list-checkbox{height:var(--sys-size-6);width:var(--sys-size-6);margin:var(--sys-size-2) 5px var(--sys-size-2) var(--sys-size-2);flex:none;pointer-events:none}.device-name{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.devices-edit-fields{flex:auto;display:flex;flex-direction:column;align-items:stretch;padding-left:var(--sys-size-3);margin-bottom:5px}.devices-edit-safe-area-group{display:flex;flex-direction:column}.devices-edit-fields b{margin-top:var(--sys-size-5);margin-bottom:0}.devices-edit-fields input{flex:auto;margin:var(--sys-size-5) 5px 0}.devices-edit-fields .device-edit-fixed{flex:0 0 140px}.devices-edit-fields select{margin:var(--sys-size-5) 5px 0}.editor-container{display:flex;flex-direction:column;align-items:stretch;flex:none;background:var(--sys-color-surface3);overflow:hidden}.editor-container[hidden]{display:none}.editor-content{flex:auto;display:flex;flex-direction:column;align-items:stretch}.editor-content input.error-input{background-color:var(--sys-color-cdt-base-container)}.editor-buttons{flex:none;display:flex;flex-direction:row;align-items:center;justify-content:flex-start;padding:5px;gap:var(--sys-size-6)}.list-widget-input-validation-error{color:var(--sys-color-error);margin:0 5px}
/*# sourceURL=${import.meta.resolve("./devicesSettingsTab.css")} */`;var{classMap:J,ifDefined:P,live:oe,ref:Q}=ae,{widget:le}=_.Widget,a={customDevices:"Custom devices",defaultDevices:"Default devices",addCustomDevice:"Add custom device",device:"Device",deviceName:"Device name",width:"Width",height:"Height",devicePixelRatio:"Device pixel ratio",userAgentString:"User agent string",userAgentType:"User agent type",deviceNameMustBeLessThanS:"Device name must be less than {PH1} characters",deviceNameCannotBeEmpty:"Device name can\u2019t be empty",deviceAddedOrUpdated:"Device {PH1} successfully added/updated",userAgentStringCannotBeEmpty:"User agent string can\u2019t be empty",portraitSafeArea:"Portrait safe area",landscapeSafeArea:"Landscape safe area",safeAreaLeft:"Left inset",safeAreaTop:"Top inset",safeAreaRight:"Right inset",safeAreaBottom:"Bottom inset",safeAreaValueMustBeInRange:"{PH1}: {PH2} must be an integer from 0 to {PH3}",safeAreaHorizontalInsetsExceedWidth:"{PH1}: Left and right insets mustn\u2019t exceed the device width",safeAreaVerticalInsetsExceedHeight:"{PH1}: Top and bottom insets mustn\u2019t exceed the device height",displayCutout:"Display cutout",noDisplayCutout:"No cutout",pillDisplayCutout:"Pill",notchDisplayCutout:"Notch",circleDisplayCutout:"Circle",rectangleDisplayCutout:"Rectangle",cutoutX:"Cutout x",cutoutY:"Cutout y",cutoutWidth:"Cutout width",cutoutHeight:"Cutout height",cutoutBorderRadius:"Pill radius",cutoutUpperRadius:"Upper radius",cutoutLowerRadius:"Lower radius",cutoutCenterX:"Center x",cutoutCenterY:"Center y",cutoutRadius:"Radius",cutoutFieldRequired:"{PH1} is required when display cutout is enabled",cutoutValueMustBeInRange:"{PH1} must be an integer from 0 to {PH2}",cutoutValueMustBePositiveInteger:"{PH1} must be a positive integer",cutoutXAndWidthExceedDeviceWidth:"Cutout x plus width mustn\u2019t exceed the device width",cutoutYAndHeightExceedDeviceHeight:"Cutout y plus height mustn\u2019t exceed the device height",circleMustFitCutoutBounds:"Circle must fit within the cutout bounds",cancel:"Cancel",save:"Save",add:"Add"},ue=z.i18n.registerUIStrings("panels/settings/emulation/DevicesSettingsTab.ts",a),s=z.i18n.getLocalizedString.bind(void 0,ue);function L(l){let e=l.trim();if(!e)return 0;if(!/^\d+$/.test(e))return null;let t=Number(e);return!Number.isSafeInteger(t)||t<0||t>o.DeviceModeModel.MaxDeviceSize?null:t}var V="none",R={title:"",width:"",height:"",scale:"","user-agent":"","ua-type":o.DeviceModeModel.UA.MOBILE,"safe-area-left":"","safe-area-top":"","safe-area-right":"","safe-area-bottom":"","landscape-safe-area-left":"","landscape-safe-area-top":"","landscape-safe-area-right":"","landscape-safe-area-bottom":"","cutout-shape":V,"cutout-x":"","cutout-y":"","cutout-width":"","cutout-height":"","cutout-border-radius":"","cutout-upper-radius":"","cutout-lower-radius":"","cutout-cx":"","cutout-cy":"","cutout-radius":""};function F(l){return E`
    <label class="devices-list-item" tabindex="-1">
      <input
        class="devices-list-checkbox"
        type="checkbox"
        .checked=${oe(l.checked)}
        jslog=${p.toggle().track({click:!0})}
        @click=${e=>{let t=e.currentTarget;l.onToggle(t.checked),e.consume()}}
      />
      <span class="device-name">${l.title}</span>
    </label>
  `}function g(l,e,t,n,r,i){let u=l.showValidationErrors&&l.invalidFields.has(n);return E`
    <input
      id=${P(i?.id)}
      name=${n}
      class=${J({"harmony-input":!0,"device-edit-fixed":!!i?.fixedWidth,"error-input":u})}
      type="text"
      placeholder=${r}
      aria-label=${r}
      aria-invalid=${P(u?"true":void 0)}
      ?hidden=${!!i?.hidden}
      .value=${l.values[n]}
      jslog=${p.textField().track({change:!0,keydown:"Enter"}).context(n)}
      @input=${d=>e(n,d.target.value)}
      ${i?.id==="custom-device-name-field"?Q(d=>{d instanceof HTMLInputElement?t.focusDeviceNameField=()=>d.focus():t.focusDeviceNameField=void 0}):A}
    />
  `}function G(l,e,t,n,r,i){return E`
    <div class="devices-edit-safe-area-group" role="group" aria-labelledby=${n}>
      <b id=${n}>${r}</b>
      <div class="hbox">
        ${g(l,e,t,`${i}safe-area-left`,s(a.safeAreaLeft))}
        ${g(l,e,t,`${i}safe-area-top`,s(a.safeAreaTop))}
        ${g(l,e,t,`${i}safe-area-right`,s(a.safeAreaRight))}
        ${g(l,e,t,`${i}safe-area-bottom`,s(a.safeAreaBottom))}
      </div>
    </div>
  `}function de(l,e,t){let n="cutout-heading",r=l.values["cutout-shape"],i=r===V,u=r===o.EmulatedDevices.CutoutShape.PILL,d=r===o.EmulatedDevices.CutoutShape.NOTCH,h=r===o.EmulatedDevices.CutoutShape.CIRCLE,D=i,T=i||!(u||d||h),B=[{value:V,label:s(a.noDisplayCutout)},{value:o.EmulatedDevices.CutoutShape.PILL,label:s(a.pillDisplayCutout)},{value:o.EmulatedDevices.CutoutShape.NOTCH,label:s(a.notchDisplayCutout)},{value:o.EmulatedDevices.CutoutShape.CIRCLE,label:s(a.circleDisplayCutout)},{value:o.EmulatedDevices.CutoutShape.RECTANGLE,label:s(a.rectangleDisplayCutout)}];return E`
    <div class="devices-edit-fields devices-edit-cutout-fields" role="group" aria-labelledby=${n}>
      <b id=${n}>${s(a.displayCutout)}</b>
      <div class="hbox">
        <select
          name="cutout-shape"
          title=${s(a.displayCutout)}
          aria-label=${s(a.displayCutout)}
          .value=${r}
          jslog=${p.dropDown().track({change:!0}).context("cutout-shape")}
          @input=${C=>e("cutout-shape",C.target.value)}
          @change=${C=>e("cutout-shape",C.target.value)}>
          ${B.map(C=>E`
            <option
              value=${C.value}
              .selected=${r===C.value}
              jslog=${p.item(H.StringUtilities.toKebabCase(C.value)).track({click:!0})}>
              ${C.label}
            </option>
          `)}
        </select>
      </div>
      <div class="hbox devices-edit-cutout-rect-row" ?hidden=${D}>
        ${g(l,e,t,"cutout-x",s(a.cutoutX))}
        ${g(l,e,t,"cutout-y",s(a.cutoutY))}
        ${g(l,e,t,"cutout-width",s(a.cutoutWidth))}
        ${g(l,e,t,"cutout-height",s(a.cutoutHeight))}
      </div>
      <div class="hbox devices-edit-cutout-radius-row" ?hidden=${T}>
        ${g(l,e,t,"cutout-border-radius",s(a.cutoutBorderRadius),{hidden:!u})}
        ${g(l,e,t,"cutout-upper-radius",s(a.cutoutUpperRadius),{hidden:!d})}
        ${g(l,e,t,"cutout-lower-radius",s(a.cutoutLowerRadius),{hidden:!d})}
        ${g(l,e,t,"cutout-cx",s(a.cutoutCenterX),{hidden:!h})}
        ${g(l,e,t,"cutout-cy",s(a.cutoutCenterY),{hidden:!h})}
        ${g(l,e,t,"cutout-radius",s(a.cutoutRadius),{hidden:!h})}
      </div>
    </div>
  `}var ne={index:0,isNew:!1,values:R,showSafeAreaAndCutout:!1,clientHintsValue:{},invalidFields:new Set,isClientHintsInvalid:!1,errorMessages:[],hasErrors:!1,showValidationErrors:!1};function re(l,e){let t=l.editorState??ne,n=[o.DeviceModeModel.UA.MOBILE,o.DeviceModeModel.UA.MOBILE_NO_TOUCH,o.DeviceModeModel.UA.DESKTOP,o.DeviceModeModel.UA.DESKTOP_TOUCH],r=t.values["ua-type"];return E`
    <div
      class="editor-container"
      ?hidden=${!l.editorState}
      jslog=${p.pane("editor").track({resize:!0})}
      @keydown=${i=>{H.KeyboardUtilities.isEscKey(i)&&(i.consume(!0),l.onCancelEdit())}}>
      <div
        class="editor-content"
        @keydown=${i=>{i.key==="Enter"&&!i.isComposing&&!(i.target instanceof HTMLSelectElement)&&(i.consume(!0),t.hasErrors||l.onCommitEdit())}}>
        <div class="devices-edit-fields">
          <b>${s(a.device)}</b>
          <div class="hbox">
            ${g(t,l.onEditorInput,e,"title",s(a.deviceName),{id:"custom-device-name-field"})}
          </div>
          <div class="hbox">
            ${g(t,l.onEditorInput,e,"width",s(a.width))}
            ${g(t,l.onEditorInput,e,"height",s(a.height))}
            ${g(t,l.onEditorInput,e,"scale",s(a.devicePixelRatio),{fixedWidth:!0})}
          </div>
          ${t.showSafeAreaAndCutout?E`
            ${G(t,l.onEditorInput,e,"portrait-safe-area-heading",s(a.portraitSafeArea),"")}
            ${G(t,l.onEditorInput,e,"landscape-safe-area-heading",s(a.landscapeSafeArea),"landscape-")}
          `:A}
        </div>
        ${t.showSafeAreaAndCutout?de(t,l.onEditorInput,e):A}
        <div class="devices-edit-fields">
          <b>${s(a.userAgentString)}</b>
          <div class="hbox">
            ${g(t,l.onEditorInput,e,"user-agent",s(a.userAgentString))}
            <select
              name="ua-type"
              class="device-edit-fixed"
              title=${s(a.userAgentType)}
              aria-label=${s(a.userAgentType)}
              .value=${r}
              jslog=${p.dropDown().track({change:!0}).context("ua-type")}
              @input=${i=>l.onEditorInput("ua-type",i.target.value)}
              @change=${i=>l.onEditorInput("ua-type",i.target.value)}>
              ${n.map(i=>E`
                <option
                  value=${i}
                  .selected=${r===i}
                  jslog=${p.item(H.StringUtilities.toKebabCase(i)).track({click:!0})}>
                  ${i}
                </option>
              `)}
            </select>
          </div>
        </div>
        <devtools-widget
          class=${J({"error-input":t.showValidationErrors&&t.isClientHintsInvalid})}
          aria-invalid=${P(t.showValidationErrors&&t.isClientHintsInvalid?"true":void 0)}
          ${le(W.UserAgentClientHintsForm.UserAgentClientHintsForm,{value:t.clientHintsValue})}
          @clienthintschange=${i=>l.onClientHintsChange(i.detail)}>
        </devtools-widget>
      </div>
      <div class="editor-buttons">
        <devtools-button
          .variant=${N.Button.Variant.OUTLINED}
          .jslogContext=${"cancel"}
          jslog=${p.action("cancel").track({click:!0})}
          @click=${l.onCancelEdit}>
          ${s(a.cancel)}
        </devtools-button>
        <devtools-button
          .variant=${N.Button.Variant.PRIMARY}
          .jslogContext=${"commit"}
          .disabled=${t.hasErrors}
          @click=${()=>{t.hasErrors||l.onCommitEdit()}}>
          ${t.isNew?s(a.add):s(a.save)}
        </devtools-button>
      </div>
      <div class="list-widget-input-validation-error" role="alert" aria-live="polite">
        ${t.showValidationErrors&&t.errorMessages.length>0?E`<span>${t.errorMessages.map((i,u)=>E`${u>0?E`<br>`:A}${i}`)}</span>`:A}
      </div>
    </div>
  `}var Z=(l,e,t)=>{let n=l.editorState?.index??null,r=n!==null?l.customDevices.slice(0,n):l.customDevices,i=n!==null?l.customDevices.slice(n+1):[];se(E`
    <style>${q.checkboxStyles}</style>
    <style>${X}</style>
    <div class="settings-card-container-wrapper">
      <div class="settings-card-container ignore-list-settings">
        <devtools-card heading=${s(a.customDevices)}>
          <div class="device-card-content">
            <div
              class="device-success-message"
              aria-live="polite"
              aria-atomic="false"
              aria-label=${l.successMessage}
            ></div>
            <div>
              ${r.length>0?E`
                <devtools-list
                  class="devices-list"
                  .editable=${!0}
                  .deletable=${!0}
                  @edit=${u=>l.onBeginEdit(u.detail.index)}
                  @delete=${u=>l.onRemoveDevice(u.detail.index)}>
                  ${r.map(u=>F({title:u.title,checked:u.show(),onToggle:d=>l.onToggleDevice(u,!0,d)}))}
                </devtools-list>
              `:A}
              ${re(l,e)}
              ${n!==null&&i.length>0?E`
                <devtools-list
                  class="devices-list"
                  .editable=${!0}
                  .deletable=${!0}
                  @edit=${u=>l.onBeginEdit(n+1+u.detail.index)}
                  @delete=${u=>l.onRemoveDevice(n+1+u.detail.index)}>
                  ${i.map(u=>F({title:u.title,checked:u.show(),onToggle:d=>l.onToggleDevice(u,!0,d)}))}
                </devtools-list>
              `:A}
            </div>
            <devtools-button
              id="custom-device-add-button"
              ?hidden=${!!l.editorState}
              .variant=${N.Button.Variant.OUTLINED}
              .jslogContext=${"add-custom-device"}
              @click=${l.onAddCustomDevice}
              ${Q(u=>{u instanceof HTMLElement?e.focusAddCustomButton=()=>{u.scrollIntoViewIfNeeded(),u.focus()}:e.focusAddCustomButton=void 0})}
            >${s(a.addCustomDevice)}</devtools-button>
          </div>
        </devtools-card>
        <devtools-card heading=${s(a.defaultDevices)}>
          ${l.defaultDeviceGroups.map(u=>E`
            <div class="device-group-container" ?hidden=${u.hidden}>
              <div class="device-group-title">${u.title}</div>
              <devtools-list class="devices-list device-card-content" .disableListItemFocus=${!0}>
                ${u.devices.map(d=>F({title:d.title,checked:d.show(),onToggle:h=>l.onToggleDevice(d,!1,h)}))}
              </devtools-list>
            </div>
          `)}
        </devtools-card>
      </div>
    </div>
  `,t,{container:{attributes:{jslog:`${p.pane("devices")}`}}})},ce={"safe-area-left":()=>s(a.safeAreaLeft),"safe-area-top":()=>s(a.safeAreaTop),"safe-area-right":()=>s(a.safeAreaRight),"safe-area-bottom":()=>s(a.safeAreaBottom),"landscape-safe-area-left":()=>s(a.safeAreaLeft),"landscape-safe-area-top":()=>s(a.safeAreaTop),"landscape-safe-area-right":()=>s(a.safeAreaRight),"landscape-safe-area-bottom":()=>s(a.safeAreaBottom),"cutout-x":()=>s(a.cutoutX),"cutout-y":()=>s(a.cutoutY),"cutout-width":()=>s(a.cutoutWidth),"cutout-height":()=>s(a.cutoutHeight),"cutout-border-radius":()=>s(a.cutoutBorderRadius),"cutout-upper-radius":()=>s(a.cutoutUpperRadius),"cutout-lower-radius":()=>s(a.cutoutLowerRadius),"cutout-cx":()=>s(a.cutoutCenterX),"cutout-cy":()=>s(a.cutoutCenterY),"cutout-radius":()=>s(a.cutoutRadius)},k=class extends _.Widget.VBox{#g;#v={};#f="";#n=[];#r=new Map;#m=!1;#i;#l=null;#u=null;#c=!1;#e={...R};#h={};#s;#o=!1;#D=this.#L.bind(this);#C=this.#S.bind(this);#b=this.#V.bind(this);#w=this.#H.bind(this);#y=this.#T.bind(this);#$=this.#U.bind(this);#A=this.commitEdit.bind(this);#I=this.#E.bind(this);constructor(e=Z){super(),this.#g=e,this.#i=o.EmulatedDevices.EmulatedDevicesList.instance();for(let t of o.EmulatedDevices.CATEGORY_ORDER)this.#r.set(t,{title:o.EmulatedDevices.getCategoryTitle(t),hidden:!1,devices:[]});this.#d()}performUpdate(){let e=null;if(this.#l!==null&&this.#u!==null){let n=!!U.Runtime.hostConfig.devToolsMobileSafeAreaEmulation?.enabled,r=this.#B(n);e={index:this.#u,isNew:this.#c,values:this.#e,showSafeAreaAndCutout:n,clientHintsValue:this.#h,invalidFields:r.invalidFields,isClientHintsInvalid:r.isClientHintsInvalid,errorMessages:r.errorMessages,hasErrors:r.hasErrors,showValidationErrors:this.#o}}let t={customDevices:this.#n,defaultDeviceGroups:[...this.#r.values()],editorState:e,successMessage:this.#f,onAddCustomDevice:this.#D,onToggleDevice:this.#C,onBeginEdit:this.#b,onRemoveDevice:this.#w,onEditorInput:this.#y,onClientHintsChange:this.#$,onCommitEdit:this.#A,onCancelEdit:this.#I};this.#g(t,this.#v,this.contentElement)}wasShown(){super.wasShown(),this.#i.addEventListener(o.EmulatedDevices.Events.CUSTOM_DEVICES_UPDATED,this.#d,this),this.#i.addEventListener(o.EmulatedDevices.Events.STANDARD_DEVICES_UPDATED,this.#d,this),this.#d()}willHide(){super.willHide(),this.#i.removeEventListener(o.EmulatedDevices.Events.CUSTOM_DEVICES_UPDATED,this.#d,this),this.#i.removeEventListener(o.EmulatedDevices.Events.STANDARD_DEVICES_UPDATED,this.#d,this)}#d(){if(this.#m)return;this.#n=this.#i.custom().slice(),this.#E();for(let t of this.#r.values())t.devices=[];let e=this.#i.standard().slice();e.sort(o.EmulatedDevices.EmulatedDevice.deviceComparator);for(let t of e){let n=o.EmulatedDevices.deviceCategory(t),r=this.#r.get(n);r&&r.devices.push(t)}for(let t of this.#r.values())t.hidden=t.devices.length===0;this.performUpdate()}#x(e){this.#m=!0,e?this.#i.saveCustomDevices():this.#i.saveStandardDevices(),this.#m=!1}#S(e,t,n){e.setShow(n),this.#x(t),this.performUpdate()}#L(){let e=new o.EmulatedDevices.EmulatedDevice;e.deviceScaleFactor=0,e.horizontal.width=700,e.horizontal.height=400,e.vertical.width=400,e.vertical.height=700,e.userAgent=navigator.userAgent,this.beginEdit(e,this.#n.length,!0)}#V(e){let t=this.#n[e];t&&this.beginEdit(t,e,!1)}#H(e){let t=this.#n[e];t&&this.#i.removeCustomDevice(t)}#E(){this.#l===null&&this.#u===null||(this.#l=null,this.#u=null,this.#c=!1,this.#e={...R},this.#s=void 0,this.#h={},this.#o=!1,this.performUpdate())}#T(e,t){this.#e[e]===t&&this.#o||(this.#e[e]=t,this.#o=!0,this.performUpdate())}#U(e){this.#s=e,this.#o=!0,this.performUpdate()}#a(e){return e?String(e):""}#p(e){return e.modes.find(t=>t.orientation===o.EmulatedDevices.Vertical)||null}#R(e){return e.modes.find(t=>t.orientation===o.EmulatedDevices.Horizontal)||null}#t(e){return L(this.#e[e])??0}beginEdit(e,t=0,n=!1){this.#l=e,this.#u=t,this.#c=n,this.#o=!1;let r;e.mobile()?r=e.touch()?o.DeviceModeModel.UA.MOBILE:o.DeviceModeModel.UA.MOBILE_NO_TOUCH:r=e.touch()?o.DeviceModeModel.UA.DESKTOP_TOUCH:o.DeviceModeModel.UA.DESKTOP;let i=this.#p(e)?.safeAreaInsets,u=this.#R(e)?.safeAreaInsets,d=this.#p(e)?.cutout;this.#e={title:e.title,width:this.#a(e.vertical.width),height:this.#a(e.vertical.height),scale:this.#a(e.deviceScaleFactor),"user-agent":e.userAgent,"ua-type":r,"safe-area-left":this.#a(i?.left||0),"safe-area-top":this.#a(i?.top||0),"safe-area-right":this.#a(i?.right||0),"safe-area-bottom":this.#a(i?.bottom||0),"landscape-safe-area-left":this.#a(u?.left||0),"landscape-safe-area-top":this.#a(u?.top||0),"landscape-safe-area-right":this.#a(u?.right||0),"landscape-safe-area-bottom":this.#a(u?.bottom||0),"cutout-shape":d?.shape||V,"cutout-x":String(d?.x??""),"cutout-y":String(d?.y??""),"cutout-width":String(d?.width??""),"cutout-height":String(d?.height??""),"cutout-border-radius":String(d?.shape===o.EmulatedDevices.CutoutShape.PILL?d.borderRadius:""),"cutout-upper-radius":String(d?.shape===o.EmulatedDevices.CutoutShape.NOTCH?d.upperRadius:""),"cutout-lower-radius":String(d?.shape===o.EmulatedDevices.CutoutShape.NOTCH?d.lowerRadius:""),"cutout-cx":String(d?.shape===o.EmulatedDevices.CutoutShape.CIRCLE?d.cx:""),"cutout-cy":String(d?.shape===o.EmulatedDevices.CutoutShape.CIRCLE?d.cy:""),"cutout-radius":String(d?.shape===o.EmulatedDevices.CutoutShape.CIRCLE?d.radius:"")},this.#s=e.userAgentMetadata||void 0,this.#h={metaData:this.#s},this.performUpdate(),this.#v.focusDeviceNameField?.()}commitEdit(){let e=this.#l;if(!e)return;let t=this.#c;e.title=this.#e.title.trim(),e.vertical.width=this.#e.width?parseInt(this.#e.width,10):0,e.vertical.height=this.#e.height?parseInt(this.#e.height,10):0,e.horizontal.width=e.vertical.height,e.horizontal.height=e.vertical.width,e.deviceScaleFactor=this.#e.scale?parseFloat(this.#e.scale):0,e.userAgent=this.#e["user-agent"],e.modes=[];let n={title:"",orientation:o.EmulatedDevices.Vertical};if(U.Runtime.hostConfig.devToolsMobileSafeAreaEmulation?.enabled){let h=this.#M("");h&&(n.safeAreaInsets=h);let D=this.#N();D&&(n.cutout=D)}e.modes.push(n);let r={title:"",orientation:o.EmulatedDevices.Horizontal};if(U.Runtime.hostConfig.devToolsMobileSafeAreaEmulation?.enabled){let h=this.#M("landscape-");h&&(r.safeAreaInsets=h)}e.modes.push(r),e.capabilities=[];let i=this.#e["ua-type"];(i===o.DeviceModeModel.UA.MOBILE||i===o.DeviceModeModel.UA.MOBILE_NO_TOUCH)&&e.capabilities.push(o.EmulatedDevices.Capability.MOBILE),(i===o.DeviceModeModel.UA.MOBILE||i===o.DeviceModeModel.UA.DESKTOP_TOUCH)&&e.capabilities.push(o.EmulatedDevices.Capability.TOUCH);let u=this.#s,d=e.userAgent.trim().length>0;e.userAgentMetadata=null,d&&u&&(e.userAgentMetadata={...u,mobile:i===o.DeviceModeModel.UA.MOBILE||i===o.DeviceModeModel.UA.MOBILE_NO_TOUCH}),this.#l=null,this.#u=null,this.#c=!1,this.#e={...R},this.#s=void 0,this.#h={},this.#o=!1,t?this.#i.addCustomDevice(e):this.#i.saveCustomDevices(),this.#f=s(a.deviceAddedOrUpdated,{PH1:e.title}),this.performUpdate(),this.#v.focusAddCustomButton?.()}#M(e){let t=this.#t(`${e}safe-area-left`),n=this.#t(`${e}safe-area-top`),r=this.#t(`${e}safe-area-right`),i=this.#t(`${e}safe-area-bottom`);return!t&&!n&&!r&&!i?null:new o.DeviceModeModel.Insets(t,n,r,i)}#N(){let e=this.#e["cutout-shape"],t={x:this.#t("cutout-x"),y:this.#t("cutout-y"),width:this.#t("cutout-width"),height:this.#t("cutout-height")};switch(e){case o.EmulatedDevices.CutoutShape.PILL:return{shape:e,...t,borderRadius:this.#t("cutout-border-radius")};case o.EmulatedDevices.CutoutShape.NOTCH:return{shape:e,...t,upperRadius:this.#t("cutout-upper-radius"),lowerRadius:this.#t("cutout-lower-radius")};case o.EmulatedDevices.CutoutShape.CIRCLE:return{shape:e,...t,cx:this.#t("cutout-cx"),cy:this.#t("cutout-cy"),radius:this.#t("cutout-radius")};case o.EmulatedDevices.CutoutShape.RECTANGLE:return{shape:e,...t};default:return null}}#B(e){let t=new Set,n=[],r=!1,i=(c,v)=>{v.valid||(r=!0,t.add(c),v.errorMessage&&n.push(v.errorMessage))},u=this.#e,d=c=>L(u[c]),h=c=>{let v=d(c);return v&&v>0?v:null},D=c=>{let v=u[c].trim();return v?L(v):null},T=c=>ce[c]?.()??"",B=()=>{let c=u.title.trim();return c.length>=o.DeviceModeModel.MaxDeviceNameLength?{valid:!1,errorMessage:s(a.deviceNameMustBeLessThanS,{PH1:o.DeviceModeModel.MaxDeviceNameLength})}:c.length===0?{valid:!1,errorMessage:s(a.deviceNameCannotBeEmpty)}:{valid:!0}},C=(c,v,m,M,f)=>{if(L(u[f])===null)return{valid:!1,errorMessage:s(a.safeAreaValueMustBeInRange,{PH1:v,PH2:T(f),PH3:o.DeviceModeModel.MaxDeviceSize})};let S=d(`${c}safe-area-left`),I=d(`${c}safe-area-top`),x=d(`${c}safe-area-right`),$=d(`${c}safe-area-bottom`),Y=h(m),K=h(M);return f===`${c}safe-area-right`&&S!==null&&x!==null&&Y!==null&&S+x>Y?{valid:!1,errorMessage:s(a.safeAreaHorizontalInsetsExceedWidth,{PH1:v})}:f===`${c}safe-area-bottom`&&I!==null&&$!==null&&K!==null&&I+$>K?{valid:!1,errorMessage:s(a.safeAreaVerticalInsetsExceedHeight,{PH1:v})}:{valid:!0}},b=c=>{let v=u["cutout-shape"];return v!==V&&(c===void 0||v===c)},w=(c,v=!1)=>{let m=T(c),M=u[c].trim();if(!M)return{valid:!1,errorMessage:s(a.cutoutFieldRequired,{PH1:m})};let f=L(M);return f===null?{valid:!1,errorMessage:s(a.cutoutValueMustBeInRange,{PH1:m,PH2:o.DeviceModeModel.MaxDeviceSize})}:v&&f===0?{valid:!1,errorMessage:s(a.cutoutValueMustBePositiveInteger,{PH1:m})}:{valid:!0}};if(i("title",B()),i("width",o.DeviceModeModel.DeviceModeModel.widthValidator(u.width)),i("height",o.DeviceModeModel.DeviceModeModel.heightValidator(u.height)),i("scale",o.DeviceModeModel.DeviceModeModel.scaleValidator(u.scale)),e){let c=s(a.portraitSafeArea);for(let m of["safe-area-left","safe-area-top","safe-area-right","safe-area-bottom"])i(m,C("",c,"width","height",m));let v=s(a.landscapeSafeArea);for(let m of["landscape-safe-area-left","landscape-safe-area-top","landscape-safe-area-right","landscape-safe-area-bottom"])i(m,C("landscape-",v,"height","width",m));if(i("cutout-shape",{valid:!0}),i("cutout-x",b()?w("cutout-x"):{valid:!0}),i("cutout-y",b()?w("cutout-y"):{valid:!0}),!b())i("cutout-width",{valid:!0});else{let m=w("cutout-width",!0);if(!m.valid)i("cutout-width",m);else{let M=D("cutout-x"),f=h("cutout-width"),y=h("width");y!==null&&M!==null&&f!==null&&M+f>y?i("cutout-width",{valid:!1,errorMessage:s(a.cutoutXAndWidthExceedDeviceWidth)}):i("cutout-width",{valid:!0})}}if(!b())i("cutout-height",{valid:!0});else{let m=w("cutout-height",!0);if(!m.valid)i("cutout-height",m);else{let M=D("cutout-y"),f=h("cutout-height"),y=h("height");y!==null&&M!==null&&f!==null&&M+f>y?i("cutout-height",{valid:!1,errorMessage:s(a.cutoutYAndHeightExceedDeviceHeight)}):i("cutout-height",{valid:!0})}}if(i("cutout-border-radius",b(o.EmulatedDevices.CutoutShape.PILL)?w("cutout-border-radius"):{valid:!0}),i("cutout-upper-radius",b(o.EmulatedDevices.CutoutShape.NOTCH)?w("cutout-upper-radius"):{valid:!0}),i("cutout-lower-radius",b(o.EmulatedDevices.CutoutShape.NOTCH)?w("cutout-lower-radius"):{valid:!0}),i("cutout-cx",b(o.EmulatedDevices.CutoutShape.CIRCLE)?w("cutout-cx"):{valid:!0}),i("cutout-cy",b(o.EmulatedDevices.CutoutShape.CIRCLE)?w("cutout-cy"):{valid:!0}),!b(o.EmulatedDevices.CutoutShape.CIRCLE))i("cutout-radius",{valid:!0});else{let m=w("cutout-radius",!0);if(!m.valid)i("cutout-radius",m);else{let M=D("cutout-x"),f=D("cutout-y"),y=h("cutout-width"),S=h("cutout-height"),I=D("cutout-cx"),x=D("cutout-cy"),$=h("cutout-radius");M!==null&&f!==null&&y!==null&&S!==null&&I!==null&&x!==null&&$!==null&&(I-$<M||I+$>M+y||x-$<f||x+$>f+S)?i("cutout-radius",{valid:!1,errorMessage:s(a.circleMustFitCutoutBounds)}):i("cutout-radius",{valid:!0})}}}i("user-agent",u["user-agent"].trim().length>0?{valid:!0}:{valid:!1,errorMessage:s(a.userAgentStringCannotBeEmpty)}),i("ua-type",{valid:!0});let j=!1,O=W.UserAgentClientHintsForm.UserAgentClientHintsForm.validateMetaData(this.#s);return O.valid||(r=!0,j=!0,O.errorMessage&&n.push(O.errorMessage)),{invalidFields:t,isClientHintsInvalid:j,errorMessages:n,hasErrors:r}}};export{ee as DevicesSettingsTab};
//# sourceMappingURL=emulation.js.map
