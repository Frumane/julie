var Y=Object.defineProperty;var Z=(r,a)=>{for(var o in a)Y(r,o,{get:a[o],enumerable:!0})};var _={};Z(_,{ALL_PROTOCOL_FORM_FACTORS:()=>x,DEFAULT_VIEW:()=>N,Events:()=>P,UserAgentClientHintsForm:()=>w});import"../../../../ui/kit/kit.js";import*as U from"../../../../core/common/common.js";import*as V from"../../../../core/i18n/i18n.js";import*as I from"../../../../core/platform/platform.js";import*as k from"../../../../ui/components/buttons/buttons.js";import*as H from"../../../../ui/components/input/input.js";import*as D from"../../../../ui/legacy/legacy.js";import*as $ from"../../../../ui/lit/lit.js";import*as u from"../../../../ui/visual_logging/visual_logging.js";import*as T from"../utils/utils.js";var S=`@scope to (devtools-widget > *){:scope *{box-sizing:revert}:scope input{margin:revert}.root{color:var(--sys-color-on-surface);width:100%}.tree-title{font-weight:700;display:flex;align-items:center;& > [aria-controls="form-container"]{margin-left:var(--sys-size-2);padding-right:var(--sys-size-3);& > [name="triangle-right"],
      & > [name="triangle-down"]{vertical-align:bottom}&[aria-expanded="true"] > [name="triangle-right"]{display:none}&[aria-expanded="false"] > [name="triangle-down"]{display:none}}}.form-container{display:grid;grid-template-columns:1fr 1fr 1fr auto;align-items:center;gap:var(--sys-size-5) 10px;padding:0 10px}.full-row{grid-column:1/5}.form-factors-checkbox-group{display:grid;grid-template-columns:repeat(2,1fr);gap:var(--sys-size-4) 10px}.form-factor-checkbox-label{display:flex;align-items:center;gap:var(--sys-size-4);white-space:nowrap}hr.section-separator{grid-column:1/5;border:none;margin-top:var(--sys-size-1)}.half-row{grid-column:span 2}.mobile-checkbox-container{display:flex}.device-model-input{grid-column:1/4}.input-field{color:var(--sys-color-on-surface);padding:3px var(--sys-size-4);border-radius:var(--sys-size-2);border:var(--sys-size-1) solid var(--sys-color-neutral-outline);background-color:var(--sys-color-cdt-base-container);font-family:inherit;font-size:inherit;height:18px}.input-field::placeholder{color:var(--sys-color-on-surface-subtle)}.input-field:focus{border:var(--sys-size-1) solid var(--sys-color-state-focus-ring);outline-style:none}.add-container{cursor:pointer;display:flex;align-items:center;gap:var(--sys-size-4)}.add-icon{margin-right:5px}.brand-row{display:flex;align-items:center;gap:10px;justify-content:space-between}.brand-row > input{width:100%}.info-icon{margin-left:5px;margin-right:var(--sys-size-1);height:var(--sys-size-8);width:var(--sys-size-8)}.link,
  .devtools-link{color:var(--sys-color-primary);text-decoration:underline;cursor:pointer;outline-offset:var(--sys-size-2);font-weight:400}devtools-icon + .link{margin-inline-start:var(--sys-size-2)}.hide-container{display:none}.input-field-label-container{display:flex;flex-direction:column;gap:10px}@media (forced-colors: active){.input-field{border:var(--sys-size-1) solid}.tree-title[aria-disabled="true"]{color:GrayText}}}
/*# sourceURL=${import.meta.resolve("./userAgentClientHintsForm.css")} */`;var{html:p,Directives:{ref:ee}}=$,e={title:"User agent client hints",useragent:"User agent (Sec-CH-UA)",fullVersionList:"Full version list (Sec-CH-UA-Full-Version-List)",brandProperties:"User agent properties",brandName:"Brand",brandNameAriaLabel:"Brand {PH1}",significantBrandVersionPlaceholder:"Significant version (e.g. 87)",brandVersionPlaceholder:"Version (e.g. 87.0.4280.88)",brandVersionAriaLabel:"Version {PH1}",addBrand:"Add brand",brandUserAgentDelete:"Delete brand from user agent section",brandFullVersionListDelete:"Delete brand from full version list",formFactorsTitle:"Form factors (Sec-CH-UA-Form-Factors)",formFactorsGroupAriaLabel:"Available form factors",formFactorDesktop:"Desktop",formFactorAutomotive:"Automotive",formFactorMobile:"Mobile",formFactorTablet:"Tablet",formFactorXR:"XR",formFactorEInk:"EInk",formFactorWatch:"Watch",fullBrowserVersion:"Full browser version (Sec-CH-UA-Full-Version)",fullBrowserVersionPlaceholder:"Full browser version (e.g. 87.0.4280.88)",platformLabel:"Platform (Sec-CH-UA-Platform / Sec-CH-UA-Platform-Version)",platformProperties:"Platform properties",platformVersion:"Platform version",platformPlaceholder:"Platform (e.g. Android)",architecture:"Architecture (Sec-CH-UA-Arch)",architecturePlaceholder:"Architecture (e.g. x86)",deviceProperties:"Device properties",deviceModel:"Device model (Sec-CH-UA-Model)",mobileCheckboxLabel:"Mobile",update:"Update",notRepresentable:"Not representable as structured headers string",userAgentClientHintsInfo:"User agent client hints are an alternative to the user agent string that identify the browser and the device in a more structured way with better privacy accounting",addedBrand:"Added brand row",deletedBrand:"Deleted brand row",learnMore:"Learn more"},te=V.i18n.registerUIStrings("panels/settings/emulation/components/UserAgentClientHintsForm.ts",e),t=V.i18n.getLocalizedString.bind(void 0,te),P=(o=>(o.CLIENT_HINTS_CHANGE="clienthintschange",o.CLIENT_HINTS_SUBMIT="clienthintssubmit",o))(P||{}),M={brands:[{brand:"",version:""}],fullVersionList:[{brand:"",version:""}],fullVersion:"",platform:"",platformVersion:"",architecture:"",model:"",mobile:!1,formFactors:[]},x=[e.formFactorDesktop,e.formFactorAutomotive,e.formFactorMobile,e.formFactorTablet,e.formFactorXR,e.formFactorEInk,e.formFactorWatch],re={brands:"ua",fullVersionList:"fvl"},ae={brands:"add-brand-button",fullVersionList:"add-fvl-brand-button"},oe=U.ObjectWrapper.eventMixin(D.Widget.Widget),w=class r extends oe{#i;#a={};#t=!1;#r=!1;#e=M;#s=!1;#o=!1;#n="";constructor(a,o=N){super(a),this.#i=o}set value(a){let{metaData:o=M,showMobileCheckbox:s=!1,showSubmitButton:c=!1}=a;this.#e={...this.#e,...o},this.#s=s,this.#o=c,this.requestUpdate()}get value(){return{metaData:this.#e}}set disabled(a){this.#r!==a&&(this.#r=a,a&&(this.#t=!1),this.requestUpdate())}get disabled(){return this.#r}wasShown(){super.wasShown(),this.requestUpdate()}#d=a=>{this.#r||a==="ArrowLeft"&&!this.#t||a==="ArrowRight"&&this.#t||(this.#t=!this.#t,this.requestUpdate())};#c=(a,o,s,c)=>{let g=this.#e[a]?.map((b,E)=>{if(E===o){let{brand:y,version:A}=b;return s==="brandName"?{brand:c,version:A}:{brand:y,version:c}}return b});this.#e={...this.#e,[a]:g},this.dispatchEventToListeners("clienthintschange",this.#e),this.requestUpdate()};#u=async(a,o)=>{let{[a]:s=[]}=this.#e,c=s.filter((g,b)=>b!==o);this.#e={...this.#e,[a]:c},this.dispatchEventToListeners("clienthintschange",this.#e),this.#n=t(e.deletedBrand),this.requestUpdate(),await this.updateComplete,o<c.length?this.#a.focusBrandInput?.(a,o):this.#a.focusAddBrandButton?.(a)};#m=async a=>{let{[a]:o}=this.#e,s=[...Array.isArray(o)?o:[],{brand:"",version:""}];this.#e={...this.#e,[a]:s},this.dispatchEventToListeners("clienthintschange",this.#e),this.#n=t(e.addedBrand),this.requestUpdate(),await this.updateComplete,this.#a.focusBrandInput?.(a,s.length-1)};#p=(a,o)=>{let s=[...this.#e.formFactors||[]];o?s.includes(a)||s.push(a):s=s.filter(c=>c!==a),this.#e={...this.#e,formFactors:s},this.dispatchEventToListeners("clienthintschange",this.#e),this.requestUpdate()};#l=(a,o)=>{a in this.#e&&(this.#e={...this.#e,[a]:o},this.requestUpdate()),this.dispatchEventToListeners("clienthintschange",this.#e)};#b=()=>{this.#o&&(this.dispatchEventToListeners("clienthintssubmit",this.#e),this.requestUpdate())};static validateMetaData(a){if(!a)return{valid:!0};for(let[o,s]of Object.entries(a))if(o==="brands"||o==="fullVersionList"){if(!(s??[]).every(({brand:b,version:E})=>{let y=T.UserAgentMetadata.validateAsStructuredHeadersString(b,t(e.notRepresentable)),A=T.UserAgentMetadata.validateAsStructuredHeadersString(E,t(e.notRepresentable));return y.valid&&A.valid}))return{valid:!1,errorMessage:t(e.notRepresentable)}}else if(o==="formFactors"){let c=s;if(c)for(let g of c){if(!x.includes(g))return{valid:!1,errorMessage:t(e.notRepresentable)+` (Invalid form factor: ${g})`};let b=T.UserAgentMetadata.validateAsStructuredHeadersString(g,t(e.notRepresentable));if(!b.valid)return b}}else{let c=T.UserAgentMetadata.validateAsStructuredHeadersString(s,t(e.notRepresentable));if(!c.valid)return c}return{valid:!0}}validate=()=>r.validateMetaData(this.#e);performUpdate(){let a={brands:this.#e.brands??[{brand:"",version:""}],fullVersionList:this.#e.fullVersionList??[{brand:"",version:""}],fullVersion:this.#e.fullVersion||"",formFactors:this.#e.formFactors??[],platform:this.#e.platform,platformVersion:this.#e.platformVersion,architecture:this.#e.architecture,model:this.#e.model,mobile:this.#e.mobile,isFormOpened:this.#t,isFormDisabled:this.#r,showMobileCheckbox:this.#s,showSubmitButton:this.#o,useragentModifiedAriaMessage:this.#n,onTreeToggle:this.#d,onBrandAdd:o=>{this.#m(o)},onBrandDelete:(o,s)=>{this.#u(o,s)},onBrandInputChange:this.#c,onTextFieldChange:this.#l,onMobileChange:o=>this.#l("mobile",o),onFormFactorChange:this.#p,onSubmit:this.#b};this.#i(a,this.#a,this.contentElement)}},N=(r,a,o)=>{let s=(i,d,l,n)=>p`
      <label class="full-row label input-field-label-container">
        ${i}
        <input
          class="input-field"
          type="text"
          @input=${h=>{let v=h.target.value;r.onTextFieldChange(n,v)}}
          .value=${l}
          placeholder=${d}
          jslog=${u.textField().track({change:!0}).context(I.StringUtilities.toKebabCase(n))}
          />
      </label>
    `,c=()=>{let i=l=>{let n=l.target.value;r.onTextFieldChange("platform",n)},d=l=>{let n=l.target.value;r.onTextFieldChange("platformVersion",n)};return p`
      <span class="full-row label">${t(e.platformLabel)}</span>
      <div class="full-row brand-row" aria-label=${t(e.platformProperties)} role="group">
        <input
          class="input-field half-row"
          type="text"
          @input=${i}
          .value=${r.platform}
          placeholder=${t(e.platformPlaceholder)}
          aria-label=${t(e.platformLabel)}
          jslog=${u.textField("platform").track({change:!0})}
        />
        <input
          class="input-field half-row"
          type="text"
          @input=${d}
          .value=${r.platformVersion}
          placeholder=${t(e.platformVersion)}
          aria-label=${t(e.platformVersion)}
          jslog=${u.textField("platform-version").track({change:!0})}
        />
      </div>
    `},g=()=>{let i=n=>{let f=n.target.value;r.onTextFieldChange("model",f)},d=n=>{let f=n.target.checked;r.onMobileChange(f)},l=r.showMobileCheckbox?p`
      <label class="mobile-checkbox-container">
        <input type="checkbox" @input=${d} .checked=${r.mobile}
          jslog=${u.toggle("mobile").track({click:!0})}
        />
        ${t(e.mobileCheckboxLabel)}
      </label>
    `:$.nothing;return p`
      <span class="full-row label">${t(e.deviceModel)}</span>
      <div class="full-row brand-row" aria-label=${t(e.deviceProperties)} role="group">
        <input
          class="input-field ${r.showMobileCheckbox?"device-model-input":"full-row"}"
          type="text"
          @input=${i}
          .value=${r.model}
          placeholder=${t(e.deviceModel)}
          jslog=${u.textField("model").track({change:!0})}
        />
        ${l}
      </div>
    `},b=()=>{let i=r.brands.map((l,n)=>{let{brand:f,version:h}=l,v=()=>{r.onBrandDelete("brands",n)},B=m=>{(m.code==="Space"||m.code==="Enter")&&(m.preventDefault(),v())},C=m=>{let L=m.target.value;r.onBrandInputChange("brands",n,"brandName",L)},F=m=>{let L=m.target.value;r.onBrandInputChange("brands",n,"brandVersion",L)};return p`
        <div class="full-row brand-row" aria-label=${t(e.brandProperties)} role="group">
          <input
            class="input-field ua-brand-name-input"
            type="text"
            @input=${C}
            .value=${f}
            id="ua-brand-${n+1}-input"
            placeholder=${t(e.brandName)}
            aria-label=${t(e.brandNameAriaLabel,{PH1:n+1})}
            jslog=${u.textField("brand-name").track({change:!0})}
          />
          <input
            class="input-field"
            type="text"
            @input=${F}
            .value=${h}
            placeholder=${t(e.significantBrandVersionPlaceholder)}
            aria-label=${t(e.brandVersionAriaLabel,{PH1:n+1})}
            jslog=${u.textField("brand-version").track({change:!0})}
          />
          <devtools-icon name="bin"
            title=${t(e.brandUserAgentDelete)}
            class="medium delete-icon"
            tabindex="0"
            role="button"
            @click=${v}
            @keypress=${B}
            aria-label=${t(e.brandUserAgentDelete)}
          >
          </devtools-icon>
        </div>
      `}),d=l=>{(l.code==="Space"||l.code==="Enter")&&(l.preventDefault(),r.onBrandAdd("brands"))};return p`
      <span class="full-row label">${t(e.useragent)}</span>
      ${i}
      <div
        class="add-container full-row"
        role="button"
        tabindex="0"
        id="add-brand-button"
        aria-label=${t(e.addBrand)}
        @click=${()=>r.onBrandAdd("brands")}
        @keypress=${d}
      >
        <devtools-icon
          aria-hidden="true" name="plus" class="medium">
        </devtools-icon>
        ${t(e.addBrand)}
      </div>
    `},E=()=>{let i=r.fullVersionList.map((l,n)=>{let{brand:f,version:h}=l,v=()=>{r.onBrandDelete("fullVersionList",n)},B=m=>{(m.code==="Space"||m.code==="Enter")&&(m.preventDefault(),v())},C=m=>{let L=m.target.value;r.onBrandInputChange("fullVersionList",n,"brandName",L)},F=m=>{let L=m.target.value;r.onBrandInputChange("fullVersionList",n,"brandVersion",L)};return p`
        <div
          class="full-row brand-row"
          aria-label=${t(e.brandProperties)}
          jslog=${u.section("full-version")}
          role="group">
          <input
            class="input-field fvl-brand-name-input"
            type="text"
            @input=${C}
            .value=${f}
            id="fvl-brand-${n+1}-input"
            placeholder=${t(e.brandName)}
            aria-label=${t(e.brandNameAriaLabel,{PH1:n+1})}
            jslog=${u.textField("brand-name").track({change:!0})}
          />
          <input
            class="input-field"
            type="text"
            @input=${F}
            .value=${h}
            placeholder=${t(e.brandVersionPlaceholder)}
            aria-label=${t(e.brandVersionAriaLabel,{PH1:n+1})}
            jslog=${u.textField("brand-version").track({change:!0})}
          />
          <devtools-icon name="bin"
            title=${t(e.brandFullVersionListDelete)}
            class="medium delete-icon"
            tabindex="0"
            role="button"
            @click=${v}
            @keypress=${B}
            aria-label=${t(e.brandFullVersionListDelete)}
          >
          </devtools-icon>
        </div>
      `}),d=l=>{(l.code==="Space"||l.code==="Enter")&&(l.preventDefault(),r.onBrandAdd("fullVersionList"))};return p`
      <span class="full-row label">${t(e.fullVersionList)}</span>
      ${i}
      <div
        class="add-container full-row"
        role="button"
        tabindex="0"
        id="add-fvl-brand-button"
        aria-label=${t(e.addBrand)}
        @click=${()=>r.onBrandAdd("fullVersionList")}
        @keypress=${d}
      >
        <devtools-icon name="plus" class="medium"
          aria-hidden="true">
        </devtools-icon>
        ${t(e.addBrand)}
      </div>
    `},y=()=>{let i=x.map(d=>{let l=r.formFactors.includes(d),n=`formFactor${d}`,f=t(e[n]);return p`
        <label class="form-factor-checkbox-label">
          <input
            type="checkbox"
            .checked=${l}
            value=${d}
            jslog=${u.toggle(I.StringUtilities.toKebabCase(d)).track({click:!0})}
            @change=${h=>r.onFormFactorChange(d,h.target.checked)}
          />
          ${f}
        </label>
      `});return p`
      <span class="full-row label" jslog=${u.sectionHeader("form-factors")}>
        ${t(e.formFactorsTitle)}
      </span>
      <div class="full-row form-factors-checkbox-group" role="group" aria-label=${t(e.formFactorsGroupAriaLabel)}>
        ${i}
      </div>
    `},A=b(),R=E(),z=s(t(e.fullBrowserVersion),t(e.fullBrowserVersionPlaceholder),r.fullVersion,"fullVersion"),K=y(),j=c(),O=s(t(e.architecture),t(e.architecturePlaceholder),r.architecture,"architecture"),W=g(),q=i=>{(i.code==="Space"||i.code==="Enter"||i.code==="ArrowLeft"||i.code==="ArrowRight")&&(i.consume(!0),r.onTreeToggle(i.code))},G=i=>{i.preventDefault(),r.onSubmit()},X=i=>{if(!(i instanceof HTMLFormElement)){a.focusBrandInput=void 0,a.focusAddBrandButton=void 0;return}a.focusBrandInput=(d,l)=>{i.querySelector(`#${re[d]}-brand-${l+1}-input`)?.focus()},a.focusAddBrandButton=d=>{i.querySelector(`#${ae[d]}`)?.focus()}},J=r.showSubmitButton?p`
    <devtools-button
      .variant=${k.Button.Variant.OUTLINED}
      .type=${"submit"}
    >
      ${t(e.update)}
    </devtools-button>
  `:$.nothing,Q=p`
    <style>${H.checkboxStyles}</style>
    <style>${S}</style>
    <section class="root">
      <div class="tree-title">
        <div
          role=button
          @click=${()=>r.onTreeToggle()}
          tabindex=${r.isFormDisabled?"-1":"0"}
          @keydown=${q}
          aria-expanded=${r.isFormOpened}
          aria-controls=form-container
          aria-disabled=${r.isFormDisabled}
          aria-label=${t(e.title)}
          jslog=${u.toggleSubpane().track({click:!0})}>
          <devtools-icon name=triangle-right></devtools-icon>
          <devtools-icon name=triangle-down></devtools-icon>
          ${t(e.title)}
        </div>
        <devtools-icon tabindex=${r.isFormDisabled?"-1":"0"} class=info-icon name=info aria-label=${t(e.userAgentClientHintsInfo)} title=${t(e.userAgentClientHintsInfo)}></devtools-icon>
        <devtools-link
         tabindex=${r.isFormDisabled?"-1":"0"}
         href="https://web.dev/user-agent-client-hints/"
         class="link"
         aria-label=${t(e.learnMore)}
         jslogcontext="learn-more"
        >
          ${t(e.learnMore)}
        </devtools-link>
      </div>
      <form
        id="form-container"
        class="form-container ${r.isFormOpened?"":"hide-container"}"
        @submit=${G}
        ${ee(X)}
      >
        ${A}
        <hr class="section-separator">
        ${R}
        <hr class="section-separator">
        ${z}
        <hr class="section-separator">
        ${K}
        <hr class="section-separator">
        ${j}
        <hr class="section-separator">
        ${O}
        <hr class="section-separator">
        ${W}
        ${J}
      </form>
      <div aria-live="polite" aria-label=${r.useragentModifiedAriaMessage}></div>
    </section>
  `;$.render(Q,o)};export{_ as UserAgentClientHintsForm};
//# sourceMappingURL=components.js.map
