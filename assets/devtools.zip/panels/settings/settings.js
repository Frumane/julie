var Wt=Object.defineProperty;var B=(s,e)=>{for(var t in e)Wt(s,t,{get:e[t],enumerable:!0})};var dt={};B(dt,{ActionDelegate:()=>ke,EXPERIMENTS_SETTINGS_TAB_DEFAULT_VIEW:()=>lt,ExperimentsSettingsTab:()=>ue,GENERIC_SETTINGS_TAB_DEFAULT_VIEW:()=>at,GenericSettingsTab:()=>ee,Revealer:()=>Ce,SETTINGS_SCREEN_DEFAULT_VIEW:()=>rt,SettingsScreen:()=>V});import"../../ui/kit/kit.js";import*as S from"../../core/common/common.js";import*as D from"../../core/host/host.js";import*as Te from"../../core/i18n/i18n.js";import*as ce from"../../core/root/root.js";import*as ge from"../../ui/components/buttons/buttons.js";import*as Ee from"../../ui/helpers/helpers.js";import*as et from"../../ui/legacy/components/settings_ui/settings_ui.js";import*as me from"../../ui/legacy/components/utils/utils.js";import*as c from"../../ui/legacy/legacy.js";import*as he from"../../ui/lit/lit.js";import*as Ue from"../../ui/settings/settings.js";import*as $e from"../../ui/visual_logging/visual_logging.js";import{PanelUtils as tt}from"../utils/utils.js";import*as Ae from"./components/components.js";var W=`.settings-window-main{color:var(--sys-color-on-surface);background-color:var(--sys-color-cdt-base-container)}.settings-experiments-block{padding:0 var(--sys-size-6) var(--sys-size-5) var(--sys-size-4)}fieldset{margin:0;padding:0;border:none}label{padding-right:var(--sys-size-5)}.experiments-filter{width:100%;padding:0 var(--sys-size-9) 0 var(--sys-size-8);max-width:var(--sys-size-35);> devtools-toolbar{min-width:var(--sys-size-31)}}.settings-select{align-items:center;display:grid;row-gap:var(--sys-size-3);margin:var(--sys-size-4) 0}div:has(.settings-select) + div:has(.settings-select){padding-top:var(--sys-size-5)}.settings-window-label-element{flex:none}.settings-window-title{display:flex;align-items:center;font-size:var(--sys-size-9);color:var(--sys-color-on-surface);margin:var(--sys-size-8) var(--sys-size-7);&::before{content:"";width:var(--sys-size-9);height:var(--sys-size-9);margin-right:var(--sys-size-6);background-image:var(--image-file-devtools)}}.settings-card-container-wrapper{scrollbar-gutter:stable;padding:var(--sys-size-8) 0;overflow:auto;position:absolute;inset:var(--sys-size-8) 0 0;container-type:inline-size;container-name:settings-content}.settings-card-container,
.settings-multicolumn-card-container{display:flex;flex-direction:column;align-items:center;gap:var(--sys-size-9);> devtools-button{max-width:var(--sys-size-35);width:calc(100% - var(--sys-size-5));margin-left:var(--sys-size-5)}}@container settings-content (min-width: 850px){.settings-multicolumn-card-container{display:block;column-width:var(--sys-size-32);column-gap:var(--sys-size-11);margin:0 var(--sys-size-9);> * + *{margin-top:var(--sys-size-8)}> devtools-button{align-self:start}}}.settings-card-container-wrapper select{margin-left:10px;width:var(--sys-size-28)}.settings-card-container-wrapper setting-checkbox{min-height:var(--sys-size-13);position:relative;left:calc(var(--sys-size-4) * -1)}.settings-experiment{margin:0;min-height:var(--sys-size-13);display:grid;grid-template-columns:auto min-content auto 1fr;& .devtools-link{display:flex!important;align-items:center}}devtools-button.link-icon{cursor:pointer}.experiment-label{margin:var(--sys-size-3) var(--sys-size-2) var(--sys-size-3) 0;white-space:normal}.settings-experiment .feedback-link{color:var(--sys-color-primary);text-decoration-line:underline;margin-left:var(--sys-size-3)}.experiments-warning-subsection{display:flex;align-items:center;> devtools-icon{color:var(--sys-color-orange-bright);margin-right:var(--sys-size-4)}}@media (forced-colors: active){.settings-window-title{color:canvastext}}
/*# sourceURL=${import.meta.resolve("./settingsScreen.css")} */`;var{html:E,nothing:it,render:Le,Directives:{ref:st,repeat:ot}}=he,{widget:nt,widgetRef:qt}=c.Widget,A={settings:"Settings",shortcuts:"Shortcuts",restoreDefaultsAndReload:"Restore defaults and reload",experiments:"Experiments",experimentsFound:"{n, plural, =1 {# experiment found} other {# experiments found}}",theseExperimentsCouldBeUnstable:"Warning: These experiments could be unstable or unreliable",settingsChangedReloadDevTools:"Settings changed. To apply, reload DevTools.",settingsChangedRestartChrome:"Settings changed. To apply, restart Chrome.",noResults:"No experiments match the filter",learnMore:"Learn more",sendFeedback:"Send feedback",searchExperiments:"Search experiments"},Yt=Te.i18n.registerUIStrings("panels/settings/SettingsScreen.ts",A),k=Te.i18n.getLocalizedString.bind(void 0,Yt),de,rt=(s,e,t)=>{Le(E`
        <style>${W}</style>
        <devtools-tabbed-pane
          vertical
          ?focus-header=${s.focusTabHeader}
          selected-tab=${s.selectedTabId}
          @tabinvoked=${i=>s.onTabInvoked(i.detail)}>
          <div slot="left" class="settings-window-label-element">
            <div class="settings-window-title" role="heading" aria-level="1">
              ${k(A.settings)}
            </div>
          </div>
          ${ot(s.views,i=>i.viewId(),i=>{let o=i.iconName();return E`
              <devtools-widget
                id=${i.viewId()}
                label=${i.title()}
                ${nt(c.ViewManager.ContainerWidget,{view:i})}>
              </devtools-widget>
              ${o?E`<devtools-icon slot="icon-${i.viewId()}" name=${o}></devtools-icon>`:it}
            `})}
        </devtools-tabbed-pane>
      `,t,{container:{classes:["settings-window-main","vbox"]}})},V=class s extends c.Widget.VBox{keybindsTab;reportTabOnReveal;#o;#e=[];#i=this.tabInvoked.bind(this);#t="preferences";#s=!1;constructor(e=rt){super({useShadowDom:!0}),this.#o=e,this.appendApplicableItems(c.ViewManager.ViewLocationValues.SETTINGS_VIEW);let t=this.#e.find(i=>i.viewId()==="keybinds");t&&t.widget().then(i=>{this.keybindsTab=i}),this.reportTabOnReveal=!1}wasShown(){super.wasShown(),this.performUpdate()}performUpdate(){this.#o({views:this.#e,selectedTabId:this.#t,focusTabHeader:this.#s,onTabInvoked:this.#i},void 0,this.contentElement)}static instance(e={forceNew:null}){let{forceNew:t}=e;return(!de||t)&&(de=new s),de}static removeInstanceForTesting(){de=void 0}static revealSettingsScreen(){let e=s.instance();if(e.isShowing())return e;e.reportTabOnReveal=!0;let t=new c.Dialog.Dialog("settings");return t.setAriaLabel(k(A.settings)),t.contentElement.removeAttribute("aria-modal"),t.contentElement.tabIndex=-1,t.addCloseButton(),t.setOutsideClickCallback(()=>{}),t.setPointerEventsBehavior(c.GlassPane.PointerEventsBehavior.PIERCE_GLASS_PANE),t.setOutsideTabIndexBehavior(c.Dialog.OutsideTabIndexBehavior.PRESERVE_MAIN_VIEW_TAB_INDEX),e.show(t.contentElement),t.setEscapeKeyCallback(e.onEscapeKeyPressed.bind(e)),t.setMarginBehavior(c.GlassPane.MarginBehavior.NO_MARGIN),t.show(),t.contentElement.focus(),e}static async showSettingsScreen(e={}){let{name:t,focusTabHeader:i}=e;await s.revealSettingsScreen().selectTab(t||"preferences",!!i)}resolveLocation(e){return this}appendApplicableItems(e){for(let t of c.ViewManager.ViewManager.instance().viewsForLocation(e))t.isTransient()||this.appendView(t)}appendView(e,t){if(this.#e.includes(e))return;let i=t?this.#e.indexOf(t):-1;i!==-1?this.#e.splice(i,0,e):this.#e.push(e),this.requestUpdate()}async showView(e,t,i,o,n=!0){if(this.appendView(e,t),n){let r=this.#t;this.#t=e.viewId(),this.#s=!1,i&&(this.reportTabOnReveal||r!==e.viewId())&&(this.reportTabOnReveal=!1,this.reportSettingsPanelShown(e.viewId()))}this.performUpdate(),await e.widget(),o||this.focus()}removeView(e){let t=this.#e.indexOf(e);t!==-1&&(this.#e.splice(t,1),this.#t===e.viewId()&&(this.#t=this.#e[0]?.viewId()??"preferences"),this.requestUpdate())}isViewVisible(e){return this.isShowing()&&this.#t===e.viewId()}widget(){return this}reveal(){s.revealSettingsScreen()}async selectTab(e,t=!1){let i=this.#t;this.#t=e,this.#s=t,(this.reportTabOnReveal||i!==e)&&(this.reportTabOnReveal=!1,this.reportSettingsPanelShown(e)),this.performUpdate();let o=this.#e.find(n=>n.viewId()===e);o&&await o.widget(),this.focus(),this.#s&&(this.#s=!1,this.requestUpdate())}tabInvoked(e){if(this.#t!==e.tabId&&(this.#t=e.tabId,this.requestUpdate()),!e.isUserGesture)return;this.#s&&(this.#s=!1,this.requestUpdate());let t=e.prevTabId,i=e.tabId;!this.reportTabOnReveal&&t&&t===i||(this.reportTabOnReveal=!1,this.reportSettingsPanelShown(i))}reportSettingsPanelShown(e){if(e===k(A.shortcuts)){c.UIUserMetrics.UIUserMetrics.instance().settingsPanelShown("shortcuts");return}c.UIUserMetrics.UIUserMetrics.instance().settingsPanelShown(e)}onEscapeKeyPressed(e){this.#t==="keybinds"&&this.keybindsTab&&this.keybindsTab.onEscapeKeyPressed(e)}},at=(s,e,t)=>{let i=new Map,o;e.highlightSetting=n=>{let r=i.get(n);r?tt.highlightElement(r):n.name==="receive-gdp-badges"&&o?.highlightReceiveBadgesSetting()},Le(E`
        <div class="settings-card-container-wrapper">
          <div class="settings-multicolumn-card-container">
            ${s.sections.map(n=>E`
              <devtools-card heading=${n.heading}>
                ${n.category===S.Settings.SettingCategory.ACCOUNT?E`<devtools-widget
                        ${nt(Ae.SyncSection.SyncSection,{syncInfo:s.syncInfo})}
                        ${qt(Ae.SyncSection.SyncSection,r=>{o=r})}>
                      </devtools-widget>`:E`
                      <div ${st(r=>{if(!r)return;let p=0;for(let w of n.settings){if(w.type()!==S.Settings.SettingType.BOOLEAN&&w.type()!==S.Settings.SettingType.ENUM)continue;let x=r.children[p++];x instanceof HTMLElement&&i.set(w,x)}})}>
                        ${n.settings.map(r=>et.SettingsUI.renderControlForSetting(r))}
                        ${n.category===S.Settings.SettingCategory.EXTENSIONS?me.Linkifier.LinkHandlerSettingUI.instance().settingElement():it}
                      </div>
                    `}
              </devtools-card>
            `)}
            <devtools-button
              .variant=${ge.Button.Variant.OUTLINED}
              .jslogContext=${"settings.restore-defaults-and-reload"}
              @click=${s.onRestoreDefaults}>
              ${k(A.restoreDefaultsAndReload)}
            </devtools-button>
          </div>
        </div>
      `,t,{container:{classes:["settings-tab-container"],attributes:{id:"preferences-tab-content",jslog:`${$e.pane("preferences")}`}}})},ee=class s extends c.Widget.VBox{#o=[];#e;#i={};#t={isSyncActive:!1};#s=-1;#n=null;constructor(e,t=at){super(e),this.#e=t;let i=[S.Settings.SettingCategory.NONE,S.Settings.SettingCategory.APPEARANCE,S.Settings.SettingCategory.SOURCES,S.Settings.SettingCategory.ELEMENTS,S.Settings.SettingCategory.NETWORK,S.Settings.SettingCategory.PERFORMANCE,S.Settings.SettingCategory.MEMORY,S.Settings.SettingCategory.CONSOLE,S.Settings.SettingCategory.EXTENSIONS,S.Settings.SettingCategory.PERSISTENCE,S.Settings.SettingCategory.DEBUGGER,S.Settings.SettingCategory.GLOBAL,S.Settings.SettingCategory.ACCOUNT],o=Array.from(Ue.SettingUIRegistration.getRegisteredSettings()).sort((n,r)=>{let p=n.uiDescriptor.order,w=r.uiDescriptor.order;return p!==void 0&&w!==void 0?p-w:p?-1:w?1:0});for(let n of i){let r=o.filter(p=>p.uiDescriptor.category===n&&s.isSettingVisible(p));this.createSectionElement(n,r)}this.requestUpdate()}#a(){S.Settings.Settings.instance().clearAll(),me.Reload.reload()}performUpdate(){this.#e({sections:this.#o,syncInfo:this.#t,onRestoreDefaults:this.#a.bind(this)},this.#i,this.contentElement)}static isSettingVisible(e){return!!e.uiDescriptor.title?.()&&!!e.uiDescriptor.category}wasShown(){c.Context.Context.instance().setFlavor(s,this),super.wasShown(),this.performUpdate(),this.updateSyncSection()}willHide(){this.#s>0&&(window.clearTimeout(this.#s),this.#s=-1),super.willHide(),c.Context.Context.instance().setFlavor(s,null)}updateSyncSection(){this.#s>0&&(window.clearTimeout(this.#s),this.#s=-1),this.#n=new Promise(e=>D.InspectorFrontendHost.InspectorFrontendHostInstance.getSyncInformation(e)).then(e=>{this.#t=e,this.requestUpdate(),(!e.isSyncActive||!e.arePreferencesSynced)&&(this.#s=window.setTimeout(this.updateSyncSection.bind(this),500))})}createSectionElement(e,t){e!==S.Settings.SettingCategory.EXTENSIONS&&t.length===0||this.#o.push({category:e,heading:S.Settings.getLocalizedSettingsCategory(e),settings:t.map(i=>S.Settings.Settings.instance().resolve(i.descriptor))})}highlightObject(e){e instanceof S.Settings.Setting&&(e.name==="receive-gdp-badges"?this.#n?.then(()=>{this.#i.highlightSetting?.(e)}):this.#i.highlightSetting?.(e))}},lt=(s,e,t)=>{Le(E`
        <div class="settings-card-container-wrapper">
          <div class="settings-card-container">
            <div class="experiments-filter">
              <devtools-toolbar>
                <devtools-toolbar-input
                  autofocus
                  type="filter"
                  placeholder=${k(A.searchExperiments)}
                  style="flex-grow:1"
                  .value=${s.filterText}
                  @change=${i=>s.onFilterChanged(i.detail)}>
                </devtools-toolbar-input>
              </devtools-toolbar>
            </div>
            <devtools-card heading=${k(A.experiments)}>
              ${s.experiments.length?E`
                <div class="experiments-warning-subsection">
                  <devtools-icon name="warning"></devtools-icon>
                  <span>${k(A.theseExperimentsCouldBeUnstable)}</span>
                </div>
                <div class="settings-experiments-block">
                  ${ot(s.experiments,i=>i.name,i=>E`
                    <p class="settings-experiment" ${st(o=>{o&&e.setExperimentElement(i,o)})}>
                      <devtools-checkbox
                        class="experiment-label"
                        name=${i.name}
                        title=${i.title}
                        .checked=${i.isEnabled()}
                        .jslogContext=${i.name}
                        @click=${o=>{let n=o.currentTarget;s.onExperimentToggled(i,n.checked)}}>
                        ${i.title}
                      </devtools-checkbox>
                      ${i.docLink?E`
                        <devtools-button
                          class="link-icon"
                          title=${k(A.learnMore)}
                          .iconName=${"help"}
                          .variant=${ge.Button.Variant.ICON}
                          .size=${ge.Button.Size.SMALL}
                          .jslogContext=${`${i.name}-documentation`}
                          @click=${()=>{i.docLink&&s.onOpenDocumentation(i.docLink)}}>
                        </devtools-button>
                      `:he.nothing}
                      ${i.feedbackLink?E`
                        <devtools-link
                          class="feedback-link"
                          href=${i.feedbackLink}
                          jslogcontext=${`${i.name}-feedback`}>
                          ${k(A.sendFeedback)}
                        </devtools-link>
                      `:he.nothing}
                    </p>
                  `)}
                </div>
              `:E`
                <span>${k(A.noResults)}</span>
              `}
            </devtools-card>
          </div>
        </div>
      `,t,{container:{classes:["settings-tab-container"],attributes:{id:"experiments-tab-content",jslog:`${$e.pane("experiments")}`}}})},ue=class s extends c.Widget.Widget{#o=new Map;#e;#i={setExperimentElement:(e,t)=>{this.#o.set(e,t)}};#t="";constructor(e,t=lt){super(e),this.#e=t}#s(e){return ce.Runtime.experiments.allConfigurableExperiments().sort((i,o)=>i.title.localeCompare(o.title)).filter(i=>i.title.toLowerCase().includes(e))}#n(e){if(this.#t=e.toLowerCase(),this.#t){let t=this.#s(this.#t);t.length?c.ARIAUtils.LiveAnnouncer.alert(k(A.experimentsFound,{n:t.length})):c.ARIAUtils.LiveAnnouncer.alert(k(A.noResults))}this.requestUpdate()}#a(e,t){D.InspectorFrontendHost.InspectorFrontendHostInstance.setChromeFlag(e.aboutFlag,t),e.setEnabled(t),D.userMetrics.experimentChanged(e.name,e.isEnabled()),e.requiresChromeRestart?c.InspectorView.InspectorView.instance().displayChromeRestartRequiredWarning(k(A.settingsChangedRestartChrome)):c.InspectorView.InspectorView.instance().displayReloadRequiredWarning(k(A.settingsChangedReloadDevTools)),this.requestUpdate()}performUpdate(){let e=this.#s(this.#t);this.#o.clear(),this.#e({filterText:this.#t,experiments:e,onFilterChanged:this.#n.bind(this),onExperimentToggled:this.#a.bind(this),onOpenDocumentation:t=>Ee.openInNewTab(t)},this.#i,this.contentElement)}highlightObject(e){if(e instanceof ce.Runtime.Experiment){let t=this.#o.get(e);t&&tt.highlightElement(t)}}wasShown(){c.Context.Context.instance().setFlavor(s,this),super.wasShown(),this.requestUpdate()}willHide(){super.willHide(),c.Context.Context.instance().setFlavor(s,null)}},ke=class{handleAction(e,t){switch(t){case"settings.show":return V.showSettingsScreen({focusTabHeader:!0}),!0;case"settings.documentation":return Ee.openInNewTab("https://developer.chrome.com/docs/devtools/"),!0;case"settings.shortcuts":return V.showSettingsScreen({name:"keybinds",focusTabHeader:!0}),!0}return!1}},Ce=class{async reveal(e){let t=c.Context.Context.instance();if(e instanceof ce.Runtime.Experiment){D.InspectorFrontendHost.InspectorFrontendHostInstance.bringToFront(),await V.showSettingsScreen({name:"experiments"});let i=t.flavor(ue);i!==null&&i.highlightObject(e);return}for(let i of Ue.SettingUIRegistration.getRegisteredSettings())if(ee.isSettingVisible(i)&&i.descriptor.name===e.name){D.InspectorFrontendHost.InspectorFrontendHostInstance.bringToFront(),await V.showSettingsScreen();let o=t.flavor(ee);o!==null&&o.highlightObject(e);return}for(let i of c.ViewManager.ViewManager.instance().getRegisteredViewExtensions()){let o=i.viewId();if(i.location()!==c.ViewManager.ViewLocationValues.SETTINGS_VIEW)continue;let r=i.settings();if(r&&r.indexOf(e.name)!==-1){D.InspectorFrontendHost.InspectorFrontendHostInstance.bringToFront(),await V.showSettingsScreen({name:o});let p=await i.widget();"highlightObject"in p&&typeof p.highlightObject=="function"&&p.highlightObject(e);return}}}};var vt={};B(vt,{AISettingsTab:()=>Pe,AI_SETTINGS_TAB_DEFAULT_VIEW:()=>pt});import"../../ui/kit/kit.js";import*as R from"../../core/common/common.js";import*as C from"../../core/host/host.js";import*as N from"../../core/i18n/i18n.js";import*as ve from"../../core/platform/platform.js";import*as z from"../../core/root/root.js";import*as y from"../../models/ai_assistance/ai_assistance.js";import*as se from"../../ui/components/buttons/buttons.js";import*as gt from"../../ui/components/input/input.js";import*as Re from"../../ui/components/switch/switch.js";import*as ht from"../../ui/i18n/i18n.js";import*as ut from"../../ui/legacy/legacy.js";import*as Jt from"../../ui/lit/lit.js";import*as q from"../../ui/visual_logging/visual_logging.js";import{PanelUtils as Xt}from"../utils/utils.js";var ct=`@scope to (devtools-widget > *){.ai-settings-container{container-type:inline-size;container-name:ai-settings;@container ai-settings (min-width: 480px){.settings-container-wrapper{align-items:center}}}*{box-sizing:border-box;min-height:auto}.shared-disclaimer{background:linear-gradient(135deg,var(--sys-color-gradient-primary),var(--sys-color-gradient-tertiary));border-radius:var(--sys-size-5);padding:var(--sys-size-9) var(--sys-size-11);max-width:var(--sys-size-35);min-width:var(--sys-size-28);h2{font:var(--sys-typescale-headline5);margin:0 0 var(--sys-size-6)}}.disclaimer-list-header{font:var(--sys-typescale-body5-medium);margin:0}.disclaimer-list{padding:var(--sys-size-6) 0 0;display:grid;grid-template-columns:var(--sys-size-12) auto;gap:var(--sys-size-6) 0;line-height:var(--sys-typescale-body5-line-height)}.settings-container{display:grid;grid-template-columns:1fr auto auto;border-radius:var(--sys-size-5);box-shadow:var(--sys-elevation-level2);margin:var(--sys-size-11) 0 var(--sys-size-4);line-height:var(--sys-typescale-body5-line-height);min-width:var(--sys-size-28);max-width:var(--sys-size-35);background-color:var(--app-color-card-background)}.accordion-header{display:grid;grid-template-columns:auto 1fr auto;&:hover{background-color:var(--sys-color-state-hover-on-subtle)}}.icon-container,
  .dropdown{padding:0 var(--sys-size-8)}.toggle-container{padding:0 var(--sys-size-8) 0 var(--sys-size-9);&:hover{background-color:var(--sys-color-state-hover-on-subtle)}}.expansion-grid{padding:var(--sys-size-4) var(--sys-size-8) var(--sys-size-6);display:grid;grid-template-columns:var(--sys-size-9) auto;gap:var(--sys-size-6) var(--sys-size-8);line-height:var(--sys-typescale-body5-line-height);color:var(--sys-color-on-surface-subtle)}.expansion-grid-whole-row{grid-column:span 2;font-weight:var(--ref-typeface-weight-medium);color:var(--sys-color-on-surface);padding-top:var(--sys-size-4);margin:0;font-size:inherit}.setting-description{color:var(--sys-color-on-surface-subtle)}.centered{display:grid;place-content:center}.setting-card{padding:var(--sys-size-6) 0;h2{margin:0;font:inherit}}.divider{margin:var(--sys-size-5) 0;border-left:var(--sys-size-1) solid var(--sys-color-divider)}.accordion-header ~ .accordion-header,
  .divider ~ .divider,
  .toggle-container ~ .toggle-container{border-top:var(--sys-size-1) solid var(--sys-color-divider)}.whole-row{grid-column:span 5;overflow:hidden;display:grid;grid-template-rows:0fr;transition:grid-template-rows var(--sys-motion-duration-short4) ease-in}.whole-row.open{grid-template-rows:1fr}.overflow-hidden{overflow:hidden}.link,
  .devtools-link{color:var(--sys-color-primary);text-decoration:underline;cursor:pointer;outline-offset:var(--sys-size-2);padding:0;font-weight:var(--ref-typeface-weight-regular)}.padded{padding:var(--sys-size-2) 0}.settings-container-wrapper{position:absolute;inset:var(--sys-size-8) 0 0;overflow:auto;padding:var(--sys-size-3) var(--sys-size-6) var(--sys-size-6);display:flex;flex-direction:column}header{font-size:var(--sys-typescale-headline3-size);font-weight:var(--ref-typeface-weight-regular)}.disabled-explainer{background-color:var(--sys-color-surface-yellow);border-radius:var(--sys-shape-corner-medium-small);margin-top:var(--sys-size-11);padding:var(--sys-size-6) var(--sys-size-11) var(--sys-size-8);width:100%;max-width:var(--sys-size-35);min-width:var(--sys-size-28);color:var(--sys-color-yellow)}.disabled-explainer-row{display:flex;gap:var(--sys-size-6);margin-top:var(--sys-size-4)}.allowed-tools-section{margin-top:var(--sys-size-11);min-width:var(--sys-size-28);max-width:var(--sys-size-35);width:100%;display:flex;flex-direction:column;gap:var(--sys-size-5)}.allowed-tools-title{font:var(--sys-typescale-headline5);color:var(--sys-color-on-surface);margin:0}.allowed-tools-card{border-radius:var(--sys-size-5);box-shadow:var(--sys-elevation-level2);background-color:var(--app-color-card-background);overflow:hidden;width:100%;padding-bottom:var(--sys-size-6)}.allowed-tools-description{padding:var(--sys-size-6) var(--sys-size-7);border-bottom:var(--sys-size-1) solid var(--sys-color-divider);font:var(--sys-typescale-body5-regular);line-height:var(--sys-typescale-body5-line-height);color:var(--sys-color-on-surface)}.allowed-tool-row{display:flex;justify-content:space-between;align-items:center;gap:var(--sys-size-6);padding:var(--sys-size-4) var(--sys-size-7);min-height:var(--sys-size-12);font:var(--sys-typescale-body5-regular);color:var(--sys-color-on-surface)}.allowed-tool-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
/*# sourceURL=${import.meta.resolve("./aiSettingsTab.css")} */`;var{html:U,nothing:te,render:Qt,Directives:{ifDefined:Zt,classMap:ei,ref:ti}}=Jt,a={boostYourProductivity:"Boost your productivity with AI",thingsToConsider:"Things to consider",experimentalFeatures:"These features use generative AI and may provide inaccurate or offensive information that doesn\u2019t represent Google\u2019s views",sendsDataToGoogle:"These features send relevant data to Google. Google collects this data and feedback to improve its products and services with the help of human reviewers. Avoid sharing sensitive or personal information.",sendsDataToGoogleNoLogging:"Your content won\u2019t be used by human reviewers to improve AI. Your organization may change these settings at any time.",dataCollection:"Depending on your region, Google may refrain from data collection",dataCollectionNoLogging:"Depending on your Google account management and/or region, Google may refrain from data collection",helpUnderstandConsole:"Helps you understand and fix console warnings and errors",aIAnnotationsFeatureDescription:"Automatically generate titles for performance trace annotations",helpAnnotatePerformance:"Helps you annotate your performance trace with auto-generated labels",showMore:"Show more",showLess:"Show less",showMoreOfSetting:"Show more of {PH1}",showLessOfSetting:"Show less of {PH1}",whenOn:"When on",explainConsole:"Get explanations for console warnings and errors",receiveSuggestions:"Receive suggestions and code samples to address these issues",consoleInsightsSendsData:"To generate explanations, the console message, associated stack trace, related source code, and the associated network headers are sent to Google. This data may be seen by human reviewers to improve this feature.",consoleInsightsSendsDataNoLogging:"To generate explanations, the console message, associated stack trace, related source code, and the associated network headers are sent to Google. This data won\u2019t be used to improve Google\u2019s AI models. Your organization may change these settings at any time.",termsOfServicePrivacyNotice:"Use of these features is subject to the {PH1} and {PH2}",aiAssistanceDescription:"Get context-aware help on the inspected page",aiAssistanceWhenOnItem1:"Debug styling, network, performance, source code, accessibility and storage issues with DevTools AI assistance",aiAssistanceWhenOnItem2:"Follow the agent\u2019s reasoning step-by-step and quickly jump to the relevant source data",aiAssistanceThingsToConsider:"To generate explanations, chat messages, data accessible for this site via DevTools panels and Web APIs, and items you select such as network requests, files, and performance traces are sent to Google and may be seen by human reviewers to improve this feature. This is an experimental AI feature and won\u2019t always get it right.",aiAssistanceThingsToConsiderNoLogging:"To generate explanations, chat messages, data accessible for this site via DevTools panels and Web APIs, and items you select such as network requests, files, and performance traces are sent to Google. The content you submit and that is generated by this feature won\u2019t be used to improve Google\u2019s AI models. This is an experimental AI feature and won\u2019t always get it right.",helpUnderstandCodeSuggestions:"Write code faster with AI-powered suggestions",learnMore:"Learn more",generatedAiAnnotationsSendData:"To generate annotation suggestions, your performance trace is sent to Google. This data may be seen by human reviewers to improve this feature.",generatedAiAnnotationsSendDataNoLogging:"To generate annotation suggestions, your performance trace is sent to Google. This data won\u2019t be used to improve Google\u2019s AI models. Your organization may change these settings at any time.",asYouTypeCodeSuggestions:"As you type in the Console or Sources panel, you\u2019ll get code suggestions. Press Tab to accept one.",asYouTypeRelevantDataIsBeingSentToGoogle:"As you type, relevant data is being sent to Google to generate code suggestions. Press Tab to accept.",describeCodeInComment:"In Console or Sources, describe the code you need in a comment, then press Ctrl+I to generate it",describeCodeInCommentForMacOs:"In Console or Sources, describe the code you need in a comment, then press Cmd+I to generate it",codeSuggestionsSendData:"To generate code suggestions, your console input, the history of your current console session, the currently inspected CSS, and the contents of the currently open file are shared with Google. This data may be seen by human reviewers to improve this feature.",codeSuggestionsSendDataNoLogging:"To generate code suggestions, your console input, the history of your current console session, the currently inspected CSS, and the contents of the currently open file are shared with Google. This data won\u2019t be used to improve Google\u2019s AI models. Your organization may change these settings at any time.",termsOfService:"Google Terms of Service",privacyNotice:"Google Privacy Policy",enableConsoleInsights:"Enable `Console insights`",enableAiAssistance:"Enable AI assistance",enableAiSuggestedAnnotations:"Enable AI suggestions for performance panel annotations",enableAiCodeSuggestions:"Enable AI code suggestions",ageRestricted:"This feature is only available to users 18 years or older",notLoggedIn:"This feature is only available when you sign in to Chrome with your Google account",offline:"This feature is only available with an active internet connection",notAvailableInIncognitoMode:"AI assistance isn\u2019t available in Incognito mode or Guest mode",wrongLocale:"To use this feature, set your language preference to English in DevTools settings",geoRestricted:"This feature is unavailable in your region",policyRestricted:"This setting is managed by your administrator"},mt=N.i18n.registerUIStrings("panels/settings/AISettingsTab.ts",a),l=N.i18n.getLocalizedString.bind(void 0,mt),pe={allowedTools:"Allowed tools",allowedToolsDescription:"Tools in this list can be run by the AI agent without asking. Remove them if you want to be asked for permission every time.",removeAllowedTool:"Remove from allowed tools",noAllowedTools:"No tools allowed yet"},ie=N.i18n.lockedString,pt=(s,e,t)=>{let i=s.disabledReasons.length?U`
    <div class="disabled-explainer">
      ${s.disabledReasons.map(g=>U`
        <div class="disabled-explainer-row">
          <devtools-icon name="warning" class="medium" style="color: var(--icon-warning);">
          </devtools-icon>
          ${g}
        </div>
      `)}
    </div>
  `:te,o=U`
    <div class="shared-disclaimer">
      <h2>${l(a.boostYourProductivity)}</h2>
      <h3 class="disclaimer-list-header">${l(a.thingsToConsider)}</h3>
      <div class="disclaimer-list">
        ${s.sharedDisclaimerBulletPoints.map(g=>U`<div><devtools-icon .name=${g.icon} class="medium"></devtools-icon>
              </div><div>${g.text}</div>`)}
      </div>
    </div>
  `,n=g=>U`
      <div>
        <devtools-icon class="extra-large" .name=${g.iconName}>
        </devtools-icon>
      </div>
      <div class="padded">${g.text}</div>
    `,r=s.disabledReasons.length>0,p=s.disabledReasons.join(`
`)||void 0,w=Array.from(s.settingToParams.entries()).map(([g,u])=>{let H=u.setting?!!u.setting.get():!1,Ie={"whole-row":!0,open:u.settingExpandState.isSettingExpanded},xe=u.settingExpandState.isSettingExpanded?"0":"-1",_=r||!!u.disabledReasons?.length||u.setting instanceof y.AiSetting.AiSetting&&u.setting.disabled;return U`
      <div class="accordion-header" @click=${s.expandSetting.bind(void 0,g)}>
        <div class="icon-container centered">
          <devtools-icon name=${u.iconName}></devtools-icon>
        </div>
        <div class="setting-card">
          <h2>${u.settingName}</h2>
          <div class="setting-description">${u.settingDescription}</div>
        </div>
        <div class="dropdown centered">
          <devtools-button
            .data=${{title:u.settingExpandState.isSettingExpanded?l(a.showLess):l(a.showMore),accessibleLabel:u.settingExpandState.isSettingExpanded?l(a.showLessOfSetting,{PH1:u.settingName}):l(a.showMoreOfSetting,{PH1:u.settingName}),size:se.Button.Size.SMALL,iconName:u.settingExpandState.isSettingExpanded?"chevron-up":"chevron-down",variant:se.Button.Variant.ICON,jslogContext:u.settingExpandState.expandSettingJSLogContext}}
          ></devtools-button>
        </div>
      </div>
      <div class="divider"></div>
      <div class="toggle-container centered"
        title=${Zt(p)}
        @click=${u.setting?s.toggleSetting.bind(void 0,g):te}
      >
        <devtools-switch
          .checked=${H&&!_}
          .jslogContext=${g}
          .disabled=${_||!u.setting}
          .label=${p||u.enableSettingText}
          data-testid=${u.enableSettingText}
          @switchchange=${u.setting?s.toggleSetting.bind(void 0,g):te}
        ></devtools-switch>
      </div>
      <div class=${ei(Ie)}>
        <div class="overflow-hidden">
          <div class="expansion-grid">
            <h3 class="expansion-grid-whole-row">${l(a.whenOn)}</h3>
            ${u.settingItems.map(L=>n(L))}
            <h3 class="expansion-grid-whole-row">${l(a.thingsToConsider)}</h3>
            ${u.toConsiderSettingItems.map(L=>n(L))}
            <div class="expansion-grid-whole-row">
              <devtools-link
                href=${u.learnMoreLink.url}
                class="link"
                tabindex=${xe}
                .jslogContext=${u.learnMoreLink.linkJSLogContext}
              >${l(a.learnMore)}</devtools-link>
            </div>
          </div>
        </div>
      </div>
    `}),x=g=>U`
    <div class="allowed-tool-row" data-tool-name=${g.toolName}>
      <span class="allowed-tool-name">${g.displayName}</span>
      <devtools-button
        .data=${{variant:se.Button.Variant.ICON,size:se.Button.Size.SMALL,iconName:"bin",title:ie(pe.removeAllowedTool),accessibleLabel:ie(`Remove ${g.displayName} from allowed tools`),jslogContext:"ai-remove-allowed-tool"}}
        @click=${()=>s.removeAllowedTool(g.toolName)}
      ></devtools-button>
    </div>
  `,M=s.isNaturalLanguageInterfaceEnabled?U`
    <div class="allowed-tools-section" jslog=${q.section("ai-allowed-tools")}
      ${ti(g=>{e.highlightAllowedTools=g?()=>Xt.highlightElement(g):void 0})}>
      <h2 class="allowed-tools-title">${ie(pe.allowedTools)}</h2>
      <div class="allowed-tools-card">
        <div class="allowed-tools-description">${ie(pe.allowedToolsDescription)}</div>
        ${s.allowedTools.length?s.allowedTools.map(x):U`
          <div class="allowed-tool-row">
            <span>${ie(pe.noAllowedTools)}</span>
          </div>
        `}
      </div>
    </div>
  `:te;Qt(U`
    <style>${gt.checkboxStyles}</style>
    <style>${ct}</style>
    <div class="ai-settings-container">
    <div class="settings-container-wrapper" jslog=${q.pane("chrome-ai")}>
      ${o}
      ${s.settingToParams.size?U`
        ${i}
        <div class="settings-container">
          ${w}
        </div>
      `:te}
      ${M}
    </div></div>
  `,t)},Pe=class extends ut.Widget.VBox{#o;#e={};#i;#t;#s;#n;#a=C.AidaClient.AidaAccessPreconditions.NO_ACCOUNT_EMAIL;#l;#r=new Map;#d=new y.AlwaysAllowedTools.AlwaysAllowedTools(R.Settings.Settings.instance());constructor(e){super(),this.#i=new y.AiSetting.AiSetting(y.AiUtils.consoleInsightsEnabledSettingDescriptor,C.AidaClient.HostConfigTracker.instance(),R.Settings.Settings.instance()),this.#s=new y.AiSetting.AiSetting(y.AiUtils.aiAssistanceEnabledSettingDescriptor,C.AidaClient.HostConfigTracker.instance(),R.Settings.Settings.instance()),z.Runtime.hostConfig.devToolsAiGeneratedTimelineLabels?.enabled&&(this.#t=R.Settings.Settings.instance().createSetting("ai-annotations-enabled",!1)),z.Runtime.hostConfig.devToolsAiCodeCompletion?.enabled&&(this.#n=R.Settings.Settings.instance().createSetting("ai-code-completion-enabled",!1)),this.#l=this.#v.bind(this),this.#p(),this.#o=e??pt}#c(e){let t=[];for(let i of e)switch(i){case y.AiUtils.DisabledReason.GEO_RESTRICTED:t.push(l(a.geoRestricted));break;case y.AiUtils.DisabledReason.POLICY_RESTRICTED:t.push(l(a.policyRestricted));break;case y.AiUtils.DisabledReason.WRONG_LOCALE:t.push(l(a.wrongLocale));break;case y.AiUtils.DisabledReason.NOT_SUPPORTED:break}return t}#g(){let e=y.AiUtils.getDisabledReasons(this.#a),t=[];for(let o of e)switch(o){case y.AiUtils.FrontendAccessPrecondition.IS_OFF_THE_RECORD:t.push(l(a.notAvailableInIncognitoMode));break;case C.AidaClient.AidaAccessPreconditions.NO_ACCOUNT_EMAIL:case C.AidaClient.AidaAccessPreconditions.SYNC_IS_PAUSED:t.push(l(a.notLoggedIn));break;case C.AidaClient.AidaAccessPreconditions.NO_INTERNET:t.push(l(a.offline));break;case y.AiUtils.FrontendAccessPrecondition.AGE_RESTRICTED:t.push(l(a.ageRestricted));break;default:ve.assertNever(o,`Unknown precondition: ${o}`)}let i=Array.from(new Set([...this.#c(this.#i.disabledReasons),...this.#c(this.#s.disabledReasons)]));return[...t,...i]}performUpdate(){let e={disabledReasons:this.#g(),sharedDisclaimerBulletPoints:this.#w(),settingToParams:this.#r,isNaturalLanguageInterfaceEnabled:y.AiUtils.isNaturalLanguageInterfaceEnabled(),allowedTools:this.#h(),expandSetting:this.#S.bind(this),toggleSetting:this.#b.bind(this),removeAllowedTool:this.#m.bind(this)};this.#o(e,this.#e,this.contentElement)}wasShown(){super.wasShown(),C.AidaClient.HostConfigTracker.instance().addEventListener(C.AidaClient.Events.AIDA_AVAILABILITY_CHANGED,this.#l),this.#d.addEventListener(y.AlwaysAllowedTools.Events.TOOLS_CHANGED,this.requestUpdate,this);let e=C.AidaClient.HostConfigTracker.instance().aidaAvailability;e!==void 0&&this.#u(e),this.requestUpdate()}willHide(){super.willHide(),C.AidaClient.HostConfigTracker.instance().removeEventListener(C.AidaClient.Events.AIDA_AVAILABILITY_CHANGED,this.#l),this.#d.removeEventListener(y.AlwaysAllowedTools.Events.TOOLS_CHANGED,this.requestUpdate,this)}#h(){return this.#d.list().map(e=>{let t=y.ToolRegistry.ToolRegistry.get(e);return{toolName:e,displayName:t?.displayName??e}}).sort((e,t)=>e.displayName.localeCompare(t.displayName))}#m(e){this.#d.remove(e),q.logFunctionCall("ai-permission-revoked",ve.StringUtilities.toKebabCase(e))}highlightObject(e){!(e instanceof R.Settings.Setting)||e.name!==y.AlwaysAllowedTools.alwaysAllowedToolsSettingDescriptor.name||this.updateComplete.then(()=>this.#e.highlightAllowedTools?.())}#p(){let e=z.Runtime.hostConfig.aidaAvailability?.enterprisePolicyValue===z.Runtime.GenAiEnterprisePolicyValue.ALLOW_WITHOUT_LOGGING;if(!this.#i.unavailable){let t={settingName:N.i18n.lockedString("Console Insights"),setting:this.#i,disabledReasons:this.#c(this.#i.disabledReasons),iconName:"lightbulb-spark",settingDescription:l(a.helpUnderstandConsole),enableSettingText:l(a.enableConsoleInsights),settingItems:[{iconName:"lightbulb",text:l(a.explainConsole)},{iconName:"code",text:l(a.receiveSuggestions)}],toConsiderSettingItems:[{iconName:"google",text:l(e?a.consoleInsightsSendsDataNoLogging:a.consoleInsightsSendsData)}],learnMoreLink:{url:"https://developer.chrome.com/docs/devtools/console/understand-messages",linkJSLogContext:"learn-more.console-insights"},settingExpandState:{isSettingExpanded:!1,expandSettingJSLogContext:"console-insights.accordion"}};this.#r.set("console-insights-enabled",t)}if(!this.#s.unavailable){let t={settingName:N.i18n.lockedString("AI assistance"),setting:this.#s,disabledReasons:this.#c(this.#s.disabledReasons),iconName:y.AiUtils.getIconName(),settingDescription:this.#y(),enableSettingText:l(a.enableAiAssistance),settingItems:[{iconName:"info",text:this.#f()},{iconName:"pen-spark",text:l(a.aiAssistanceWhenOnItem2)}],toConsiderSettingItems:[{iconName:"google",text:l(e?a.aiAssistanceThingsToConsiderNoLogging:a.aiAssistanceThingsToConsider)}],learnMoreLink:{url:"https://developer.chrome.com/docs/devtools/ai-assistance",linkJSLogContext:"learn-more.ai-assistance"},settingExpandState:{isSettingExpanded:!1,expandSettingJSLogContext:"freestyler.accordion"}};this.#r.set("ai-assistance-enabled",t)}if(this.#t){let t={settingName:N.i18n.lockedString("Auto annotations"),setting:this.#t,iconName:"pen-spark",settingDescription:l(a.aIAnnotationsFeatureDescription),enableSettingText:l(a.enableAiSuggestedAnnotations),settingItems:[{iconName:"label-auto",text:l(a.helpAnnotatePerformance)}],toConsiderSettingItems:[{iconName:"google",text:l(e?a.generatedAiAnnotationsSendDataNoLogging:a.generatedAiAnnotationsSendData)}],learnMoreLink:{url:"https://developer.chrome.com/docs/devtools/performance/annotations#auto-annotations",linkJSLogContext:"learn-more.auto-annotations"},settingExpandState:{isSettingExpanded:!1,expandSettingJSLogContext:"auto-annotations.accordion"}};this.#r.set("ai-annotations-enabled",t)}if(this.#n){let t=z.Runtime.hostConfig.devToolsAiCodeGeneration?.enabled?[{iconName:"code",text:l(a.asYouTypeRelevantDataIsBeingSentToGoogle)},{iconName:"text-analysis",text:C.Platform.isMac()?l(a.describeCodeInCommentForMacOs):l(a.describeCodeInComment)}]:[{iconName:"code",text:l(a.asYouTypeCodeSuggestions)}],i={settingName:N.i18n.lockedString("Code suggestions"),setting:this.#n,iconName:"text-analysis",settingDescription:l(a.helpUnderstandCodeSuggestions),enableSettingText:l(a.enableAiCodeSuggestions),settingItems:t,toConsiderSettingItems:[{iconName:"google",text:l(e?a.codeSuggestionsSendDataNoLogging:a.codeSuggestionsSendData)}],learnMoreLink:{url:" https://developers.chrome.com/docs/devtools/ai-assistance/code-completion",linkJSLogContext:"learn-more.code-completion"},settingExpandState:{isSettingExpanded:!1,expandSettingJSLogContext:"code-completion.accordion"}};this.#r.set("ai-code-completion-enabled",i)}}#u(e){e!==this.#a&&(this.#a=e,this.requestUpdate())}#v(e){this.#u(e.data)}#y(){return l(a.aiAssistanceDescription)}#f(){return l(a.aiAssistanceWhenOnItem1)}#S(e){let t=this.#r.get(e);t&&(t.settingExpandState.isSettingExpanded=!t.settingExpandState.isSettingExpanded,this.requestUpdate())}#b(e,t){if(t.target instanceof Re.Switch.Switch&&t.type!==Re.Switch.SwitchChangeEvent.eventName)return;let i=this.#r.get(e);if(!i||!i.setting)return;let o=i.setting,n=o.get();o.set(!n),!n&&!i.settingExpandState.isSettingExpanded&&(i.settingExpandState.isSettingExpanded=!0),e==="console-insights-enabled"?n?R.Settings.Settings.instance().createLocalSetting("console-insights-onboarding-finished",!1).set(!1):R.Settings.Settings.instance().createSetting("console-insights-skip-reminder",!0,R.Settings.SettingStorageType.SESSION).set(!0):e==="ai-assistance-enabled"&&(o.get()||y.AiHistoryStorage.AiHistoryStorage.instance().deleteAll(),o.get()&&R.Settings.Settings.instance().resolve(y.AiUtils.aiAssistanceV2OptInChangeDialogSeenSettingDescriptor).set(!0)),this.requestUpdate()}#w(){let e=U`<devtools-link href="https://policies.google.com/terms" .jslogContext=${"terms-of-service"}>${l(a.termsOfService)}</devtools-link>`,t=U`<devtools-link href="https://policies.google.com/privacy" .jslogContext=${"privacy-notice"}>${l(a.privacyNotice)}</devtools-link>`,i=z.Runtime.hostConfig.aidaAvailability?.enterprisePolicyValue===z.Runtime.GenAiEnterprisePolicyValue.ALLOW_WITHOUT_LOGGING;return[{icon:"psychiatry",text:l(a.experimentalFeatures)},{icon:"google",text:l(i?a.sendsDataToGoogleNoLogging:a.sendsDataToGoogle)},{icon:"corporate-fare",text:l(i?a.dataCollectionNoLogging:a.dataCollection)},{icon:"policy",text:ht.getFormatLocalizedStringTemplate(mt,a.termsOfServicePrivacyNotice,{PH1:e,PH2:t})}]}};var wt={};B(wt,{BackendLinkingSettingsTab:()=>Me,DEFAULT_VIEW:()=>bt});import"../../ui/legacy/components/data_grid/data_grid.js";import*as yt from"../../core/common/common.js";import*as He from"../../core/i18n/i18n.js";import*as ye from"../../ui/legacy/legacy.js";import{Directives as ii,html as Ve,nothing as si,render as oi}from"../../ui/lit/lit.js";import*as ft from"../../ui/visual_logging/visual_logging.js";import*as Be from"../network/forward/forward.js";var De=`@scope to (devtools-widget > *){.settings-card-container{align-items:stretch;padding:0 var(--sys-size-8)}devtools-card{max-width:100%}.description-text{color:var(--sys-color-on-surface-subtle);font-size:var(--sys-typescale-body-medium-size);line-height:var(--sys-typescale-body-medium-line-height);margin:0 0 var(--sys-size-5)}.intro-section{display:grid;grid-template-columns:max-content 1fr;gap:var(--sys-size-2) var(--sys-size-6);align-items:baseline;font-size:var(--sys-typescale-body-small-size);line-height:var(--sys-typescale-body-medium-line-height);margin:0;dd{margin:0}.column-header{font-size:var(--sys-typescale-label-small-size);font-weight:var(--ref-typeface-weight-medium);border-bottom:1px solid var(--sys-color-neutral-outline);padding-bottom:var(--sys-size-2);margin-bottom:var(--sys-size-3)}.placeholder,
    .source-header{font-family:var(--monospace-font-family)}.placeholder{color:var(--sys-color-primary)}.placeholder-description{grid-column:1/-1;color:var(--sys-color-on-surface-subtle);margin-bottom:var(--sys-size-6)}}.warning-icon{margin-right:var(--sys-size-3);vertical-align:text-bottom}td.editing .warning-icon{display:none}.warning-footer{display:flex;align-items:center;gap:var(--sys-size-3);color:var(--sys-color-on-surface-subtle);font-size:var(--sys-typescale-body-small-size);line-height:var(--sys-typescale-body-medium-line-height)}}
/*# sourceURL=${import.meta.resolve("./backendLinkingSettingsTab.css")} */`;var{ifDefined:ze}=ii,b={rulesSectionHeading:"Backend linking rules",placeholderDocHeading:"Available placeholders",description:"Configure links to external backend debugging, APM, or tracing tools for matching network requests. Use placeholders to insert correlation IDs extracted from request and response headers.",urlPatternColumn:"URL pattern",targetUrlTemplateColumn:"Target URL template",labelColumn:"Label",placeholderColumn:"Placeholder",headerColumn:"Referenced header / property",devtoolsDebugIdDescription:"Value of the `desc` parameter in the `devtools-debug-id` `Server-Timing` entry",requestIdDescription:"Value of the `X-Request-ID` response header",correlationIdDescription:"Value of the `X-Correlation-ID` or `Correlation-ID` response header",traceIdDescription:"16-byte hex trace ID from the `trace-id` response header or `Server-Timing` `traceparent` entry",spanIdDescription:"8-byte hex parent span ID from the `Server-Timing` `traceparent` entry",urlPatternCannotBeEmpty:"URL pattern can\u2019t be empty",invalidUrlPattern:"URL pattern must be a valid URL pattern",targetUrlTemplateCannotBeEmpty:"Target URL template can\u2019t be empty",templateRequiresPlaceholder:"Target URL template must contain at least one placeholder",labelCannotBeEmpty:"Label can\u2019t be empty",invalidRulesWarning:"Invalid rules won\u2019t be applied or saved"},ni=He.i18n.registerUIStrings("panels/settings/BackendLinkingSettingsTab.ts",b),I=He.i18n.getLocalizedString.bind(void 0,ni);function Ne(s){try{return new URLPattern(s),!0}catch{return!1}}function Fe(s){return Be.BackendLinking.BACKEND_LINKING_PLACEHOLDERS.some(e=>s.includes(e))}function St(s){return!!s.urlPattern&&Ne(s.urlPattern)&&!!s.targetUrlTemplate&&Fe(s.targetUrlTemplate)&&!!s.label}var bt=(s,e,t)=>{let i=n=>{let r=n.detail,p=r.urlPattern?.trim(),w=r.targetUrlTemplate?.trim(),x=r.label?.trim();!p&&!w&&!x||s.onAddRule({urlPattern:p??"",targetUrlTemplate:w??"",label:x??""})},o=(n,r)=>{let{columnId:p,newText:w}=r.detail,x={...n};p==="urlPattern"?x.urlPattern=w.trim():p==="targetUrlTemplate"?x.targetUrlTemplate=w.trim():p==="label"&&(x.label=w.trim()),s.onUpdateRule(n,x)};oi(Ve`
     <style>${De}</style>
      <style>${ye.inspectorCommonStyles}</style>
      <div class="settings-card-container-wrapper" jslog=${ft.pane("backend-linking")}>
        <div class="settings-card-container">
          <devtools-card heading=${I(b.rulesSectionHeading)}>
            <p class="description-text">${I(b.description)}</p>
            <devtools-data-grid
              name=${I(b.rulesSectionHeading)}
              striped
              inline
              deletable
              @delete=${()=>{}}
              @create=${i}>
              <table>
                <style>${De}</style>
                <thead>
                  <tr>
                    <th id="urlPattern" editable>${I(b.urlPatternColumn)}</th>
                    <th id="targetUrlTemplate" editable>${I(b.targetUrlTemplateColumn)}</th>
                    <th id="label" editable>${I(b.labelColumn)}</th>
                  </tr>
                </thead>
                <tbody>
                  ${s.rules.map(n=>Ve`
                    <tr @edit=${r=>o(n,r)}
                        @delete=${()=>s.onDeleteRule(n)}>
                      <td title=${ze(n.urlPattern?Ne(n.urlPattern)?void 0:I(b.invalidUrlPattern):I(b.urlPatternCannotBeEmpty))}>
                        <devtools-icon name="warning-filled" class="small warning-icon"
                          ?hidden=${!!n.urlPattern&&Ne(n.urlPattern)}></devtools-icon>
                        ${n.urlPattern}
                      </td>
                      <td title=${ze(n.targetUrlTemplate?Fe(n.targetUrlTemplate)?void 0:I(b.templateRequiresPlaceholder):I(b.targetUrlTemplateCannotBeEmpty))}>
                        <devtools-icon name="warning-filled" class="small warning-icon"
                          ?hidden=${!!n.targetUrlTemplate&&Fe(n.targetUrlTemplate)}></devtools-icon>
                        ${n.targetUrlTemplate}
                      </td>
                      <td title=${ze(n.label?void 0:I(b.labelCannotBeEmpty))}>
                        <devtools-icon name="warning-filled" class="small warning-icon"
                          ?hidden=${!!n.label}></devtools-icon>
                        ${n.label}
                      </td>
                    </tr>
                  `)}
                  <tr placeholder></tr>
                </tbody>
              </table>
            </devtools-data-grid>
            ${s.rules.some(n=>!St(n))?Ve`
              <div class="warning-footer">
                <devtools-icon name="warning-filled" class="small"></devtools-icon>
                <span>${I(b.invalidRulesWarning)}</span>
              </div>
            `:si}
          </devtools-card>
          <devtools-card heading=${I(b.placeholderDocHeading)}>
            <dl class="intro-section">
              <div class="column-header">${I(b.placeholderColumn)}</div>
              <div class="column-header">${I(b.headerColumn)}</div>
              <dt class="placeholder">${"${devtoolsDebugId}"}</dt>
              <dd class="source-header">Server-Timing: devtools-debug-id</dd>
              <dd class="placeholder-description">${I(b.devtoolsDebugIdDescription)}</dd>
              <dt class="placeholder">${"${requestId}"}</dt>
              <dd class="source-header">X-Request-ID</dd>
              <dd class="placeholder-description">${I(b.requestIdDescription)}</dd>
              <dt class="placeholder">${"${correlationId}"}</dt>
              <dd class="source-header">X-Correlation-ID / Correlation-ID</dd>
              <dd class="placeholder-description">${I(b.correlationIdDescription)}</dd>
              <dt class="placeholder">${"${traceId}"}</dt>
              <dd class="source-header">trace-id / Server-Timing: traceparent</dd>
              <dd class="placeholder-description">${I(b.traceIdDescription)}</dd>
              <dt class="placeholder">${"${spanId}"}</dt>
              <dd class="source-header">Server-Timing: traceparent</dd>
              <dd class="placeholder-description">${I(b.spanIdDescription)}</dd>
            </dl>
          </devtools-card>
        </div>
      </div>`,t)},Me=class extends ye.Widget.VBox{#o;#e;#i=[];#t=!1;constructor(e,t=bt){super(e),this.#o=t;let i=yt.Settings.Settings.instance().maybeResolve(Be.BackendLinking.backendLinkingRulesSettingDescriptor);if(!("setting"in i))throw new Error("Backend linking setting is not available");this.#e=i.setting}wasShown(){super.wasShown(),this.#i=[...this.#e.get()],this.#e.addChangeListener(this.#s,this),this.requestUpdate()}willHide(){super.willHide(),this.#e.removeChangeListener(this.#s,this)}#s(){this.#t||(this.#i=[...this.#e.get()],this.requestUpdate())}#n(){this.#t=!0;try{this.#e.set(this.#i.filter(St))}finally{this.#t=!1}this.requestUpdate()}performUpdate(){let e={rules:[...this.#i],onAddRule:t=>{this.#i.push(t),this.#n()},onUpdateRule:(t,i)=>{let o=this.#i.indexOf(t);o!==-1&&(this.#i[o]=i,this.#n())},onDeleteRule:t=>{let i=this.#i.indexOf(t);i!==-1&&(this.#i.splice(i,1),this.#n())}};this.#o(e,void 0,this.contentElement)}};var Et={};B(Et,{DEFAULT_VIEW:()=>Tt,EditFileSystemView:()=>oe});import"../../ui/components/lists/lists.js";import*as Ke from"../../core/i18n/i18n.js";import*as At from"../../core/platform/platform.js";import*as kt from"../../ui/components/buttons/buttons.js";import*as Ct from"../../ui/legacy/legacy.js";import{Directives as ri,html as Oe,nothing as ai,render as li}from"../../ui/lit/lit.js";var It=`@scope to (devtools-widget > *){.excluded-folder-header{display:flex;flex-direction:column;min-height:var(--sys-size-16);padding:var(--sys-size-4) var(--sys-size-6);gap:var(--sys-size-4);& > .excluded-folder-url{color:var(--sys-color-on-surface-subtle);overflow-wrap:break-word}}.excluded-folder-row{display:flex;align-items:center;flex:auto;min-width:0;padding:var(--sys-size-2) var(--sys-size-4);&:has(devtools-prompt[editing]){align-self:stretch;background-color:var(--app-color-card-background,var(--sys-color-cdt-base-container))}}.excluded-folder-path{flex:auto;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;--devtools-text-prompt-min-width:6em}devtools-prompt.excluded-folder-path{cursor:text}devtools-prompt.excluded-folder-path[editing]{overflow:visible}.add-subfolder-button{align-self:flex-start}}
/*# sourceURL=${import.meta.resolve("./editFileSystemView.css")} */`;var{ifDefined:xt,repeat:di}=ri,O={url:"URL",excludedFolders:"Excluded sub-folders",enterAPath:"Enter a path",enterAUniquePath:"Enter a unique path",addSubfolder:"Add sub-folder",folderPath:"Folder path"},ci=Ke.i18n.registerUIStrings("panels/settings/EditFileSystemView.ts",O),Y=Ke.i18n.getLocalizedString.bind(void 0,ci),gi=Symbol("new-excluded-folder");function hi(s,e,t){let i=t.editingIndex===e,o=n=>{i||(t.onEdit(e),n.consume(!0))};return Oe`
    <div
      class="excluded-folder-row"
      ?editable=${!i}
      ?deletable=${!i}>
      <devtools-prompt
        class="excluded-folder-path"
        render-as-block
        title=${xt(s||void 0)}
        aria-label=${xt(i?Y(O.folderPath):void 0)}
        value=${s}
        ?editing=${i}
        .validator=${n=>t.validateFolder(e,n)}
        @click=${o}
        @commit=${n=>t.onCommit(e,n.detail)}
        @cancel=${t.onCancel}>
        ${s}
      </devtools-prompt>
    </div>
  `}var Tt=(s,e,t)=>{let o=s.editingIndex===s.excludedFolders.length?[...s.excludedFolders,""]:s.excludedFolders;li(Oe`
    <style>${It}</style>
    <div class="excluded-folder-header">
      <span>${Y(O.url)}</span>
      <span class="excluded-folder-url">${s.fileSystemPath}</span>
      <div class="excluded-folders-title">${Y(O.excludedFolders)}</div>
      ${o.length>0?Oe`
        <devtools-list
          ?disable-li-focus=${s.editingIndex!==null}
          @edit=${n=>s.onEdit(n.detail.index)}
          @delete=${n=>s.onDelete(n.detail.index)}>
          ${di(o,(n,r)=>r===s.excludedFolders.length?gi:n,(n,r)=>hi(n,r,s))}
        </devtools-list>
      `:ai}
      <devtools-button
        class="add-subfolder-button"
        .variant=${kt.Button.Variant.OUTLINED}
        .jslogContext=${"settings.add-excluded-folder"}
        @click=${s.onAdd}>
        ${Y(O.addSubfolder)}
      </devtools-button>
    </div>
  `,t)},oe=class s extends Ct.Widget.VBox{#o;#e=[];#i=null;#t;constructor(e,t=Tt){super(e),this.#t=t}set fileSystem(e){this.#o!==e&&(this.#o=e,this.#i=null,this.#s(),this.requestUpdate())}wasShown(){super.wasShown(),this.#i=null,this.#s(),this.requestUpdate()}willHide(){super.willHide(),this.#i=null}#s(){this.#e=this.#o?.excludedFolders().values().toArray()??[]}performUpdate(){let e={fileSystemPath:this.#o?.path()??At.DevToolsPath.urlString``,excludedFolders:[...this.#e],editingIndex:this.#i,onAdd:this.#n.bind(this),onEdit:this.#a.bind(this),onDelete:this.#d.bind(this),onCommit:this.#r.bind(this),onCancel:this.#l.bind(this),validateFolder:this.#c.bind(this)};this.#t(e,void 0,this.contentElement)}#n(){this.#i!==this.#e.length&&(this.#i=this.#e.length,this.requestUpdate())}#a(e){e<0||e>=this.#e.length||(this.#i=e,this.requestUpdate())}#l(){!this.isShowing()||this.#i===null||(this.#i=null,this.requestUpdate())}#r(e,t){if(!this.isShowing()||this.#i===null)return;let i=e===this.#e.length;if(!i&&(e<0||e>=this.#e.length)||this.#c(e,t)!==null)return;let o=s.#g(t.trim());i?(this.#e.push(o),this.#o?.addExcludedFolder(o)):this.#e[e]!==o&&(this.#o?.removeExcludedFolder(this.#e[e]),this.#e[e]=o,this.#o?.addExcludedFolder(o)),this.#i=null,this.requestUpdate()}#d(e){e<0||e>=this.#e.length||(this.#o?.removeExcludedFolder(this.#e[e]),this.#e.splice(e,1),this.#i!==null&&(this.#i===e?this.#i=null:this.#i>e&&this.#i--),this.requestUpdate())}#c(e,t){let i=s.#g(t.trim());return i?this.#e.some((n,r)=>r!==e&&n===i)?Y(O.enterAUniquePath):null:Y(O.enterAPath)}static#g(e){return e?e+(e[e.length-1]==="/"?"":"/"):""}};var Vt={};B(Vt,{DEFAULT_VIEW:()=>Dt,FrameworkIgnoreListSettingsTab:()=>Ge});import"../../ui/components/lists/lists.js";import"../../ui/kit/kit.js";import*as Lt from"../../core/common/common.js";import*as je from"../../core/i18n/i18n.js";import*as Rt from"../../core/platform/platform.js";import*as J from"../../models/workspace/workspace.js";import*as X from"../../ui/components/buttons/buttons.js";import*as Pt from"../../ui/helpers/helpers.js";import*as we from"../../ui/legacy/legacy.js";import{Directives as be,html as ne,nothing as Se,render as ui}from"../../ui/lit/lit.js";import*as K from"../../ui/visual_logging/visual_logging.js";var Ut=`.ignore-list-option{flex:none;display:flex;align-items:center;height:var(--sys-size-13)}.ignore-list-option devtools-button{cursor:pointer;position:relative;top:var(--sys-size-2);margin-left:var(--sys-size-2)}.add-button{padding:var(--sys-size-5) var(--sys-size-6);align-self:flex-start;flex:none}.ignore-list{flex:0 1 auto}.enable-ignore-listing,
.ignore-list-item,
.general-exclusion-group{padding-left:var(--sys-size-4)}.custom-exclusion-group{padding-left:0;padding-right:0}.ignore-list-item{height:var(--sys-size-13);display:flex;align-items:center;position:relative;flex:auto 1 1}.ignore-list-pattern{flex:auto}.ignore-list-item > devtools-checkbox{width:100%}.ignore-list-item .ignore-list-pattern{white-space:nowrap;text-overflow:ellipsis;user-select:none;color:var(--sys-color-on-surface);overflow:hidden}.ignore-list-edit-row{flex:none;display:flex;flex-direction:row;margin:var(--sys-size-4) 5px;align-items:center}.ignore-list-edit-row input,
.ignore-list-edit-row select{width:100%;text-align:inherit}.editor-container{display:flex;flex-direction:column;align-items:stretch;flex:none;background:var(--sys-color-surface1);border-radius:10px;overflow:hidden}.editor-content{flex:auto;display:flex;flex-direction:column;align-items:stretch}.editor-content input{margin-right:10px}.editor-content input.error-input{background-color:var(--sys-color-cdt-base-container)}.editor-buttons{flex:none;display:flex;flex-direction:row;align-items:center;justify-content:flex-start;padding:5px;gap:var(--sys-size-6)}.list-widget-input-validation-error{color:var(--sys-color-error);margin:0 5px}.editor-container ~ .add-button{display:none}.devtools-link:has(devtools-icon){margin-left:var(--sys-size-4)}
/*# sourceURL=${import.meta.resolve("./frameworkIgnoreListSettingsTab.css")} */`;var{bindToSetting:fe}=we.UIUtils,h={frameworkIgnoreList:"Ignore listing",ignoreListingDescription:"When enabled, the debugger will skip over ignore-listed scripts and will ignore exceptions that only affect them and the Performance panel will collapse matching flamechart items",ignoreListContentScripts:"Content scripts injected by extensions",ignoreListAnonymousScripts:"Anonymous scripts from eval or console",automaticallyIgnoreListKnownThirdPartyScripts:"Known third-party scripts from source maps",ignoreListing:"Ignore listing",enableIgnoreListingTooltip:"Uncheck to disable all ignore listing",generalExclusionRules:"General exclusion rules",customExclusionRules:"Custom exclusion rules",addPattern:"Add regex rule",addFilenamePattern:"Add a regular expression rule for the script\u2019s URL",ignoreScriptsWhoseNamesMatchS:"Ignore scripts whose names match ''{PH1}''",pattern:"Add a regular expression rule for the script\u2019s URL",patternCannotBeEmpty:"Rule can\u2019t be empty",patternAlreadyExists:"Rule already exists",patternMustBeAValidRegular:"Rule must be a valid regular expression",learnMore:"Learn more",save:"Save",add:"Add",cancel:"Cancel"},mi=je.i18n.registerUIStrings("panels/settings/FrameworkIgnoreListSettingsTab.ts",h),m=je.i18n.getLocalizedString.bind(void 0,mi);function $t(s,e,t,i){let o=m(h.ignoreScriptsWhoseNamesMatchS,{PH1:s.pattern});return ne`
    <div class="ignore-list-item">
      <devtools-checkbox
          .checked=${!s.disabled}
          .disabled=${!t}
          title=${o}
          aria-label=${o}
          jslogcontext="settings.ignore-list-pattern"
          @change=${n=>i(e,n.target.checked)}>
        ${s.pattern}
      </devtools-checkbox>
    </div>
  `}function pi(s){let e=s.editingIndex===s.patterns.length,t=s.showValidationError&&s.validationError!==null;return ne`
    <div
        class="editor-container"
        jslog=${K.pane("editor").track({resize:!0})}
        @keydown=${i=>{Rt.KeyboardUtilities.isEscKey(i)&&(i.consume(!0),s.onCancelEdit())}}>
      <div
          class="editor-content"
          @keydown=${i=>{i.key==="Enter"&&!i.isComposing&&(i.consume(!0),s.onCommitEdit())}}>
        <div class="ignore-list-edit-row">
          <div class="ignore-list-pattern">${m(h.pattern)}</div>
        </div>
        <div class="ignore-list-edit-row">
          <div class="ignore-list-pattern">
            <input
                class=${be.classMap({"harmony-input":!0,"error-input":t})}
                type="text"
                autofocus
                placeholder="/framework\\.js$"
                aria-label=${m(h.pattern)}
                aria-invalid=${t?"true":"false"}
                .value=${be.live(s.editingValue)}
                jslog=${K.textField().track({change:!0,keydown:"Enter"}).context("pattern")}
                @input=${i=>s.onEditorInput(i.target.value)}>
          </div>
        </div>
      </div>
      <div class="editor-buttons">
        <devtools-button
            .variant=${X.Button.Variant.OUTLINED}
            .jslogContext=${"cancel"}
            jslog=${K.action("cancel").track({click:!0})}
            @click=${s.onCancelEdit}>
          ${m(h.cancel)}
        </devtools-button>
        <devtools-button
            .variant=${X.Button.Variant.PRIMARY}
            .jslogContext=${"commit"}
            .disabled=${s.validationError!==null}
            @click=${s.onCommitEdit}>
          ${m(e?h.add:h.save)}
        </devtools-button>
      </div>
      <div class="list-widget-input-validation-error" role="alert" aria-live="polite">
        ${t&&s.validationError?s.validationError:Se}
      </div>
    </div>
  `}var Dt=(s,e,t)=>{let i=s.editingIndex,o=i!==null?s.patterns.slice(0,i):s.patterns,n=i!==null?s.patterns.slice(i+1):[];ui(ne`
    <style>${Ut}</style>
    <style>${W}</style>
    <div class="settings-card-container-wrapper">
      <div class="settings-card-container ignore-list-settings">
        <devtools-card .heading=${m(h.frameworkIgnoreList)}>
          <span>${m(h.ignoreListingDescription)}</span>
          <div class="enable-ignore-listing" title=${m(h.enableIgnoreListingTooltip)}>
            <devtools-checkbox
                name=${m(h.ignoreListing)}
                title=${m(h.ignoreListing)}
                ${fe(s.enabledSetting)}>
              ${m(h.ignoreListing)}
            </devtools-checkbox>
          </div>
        </devtools-card>
        <devtools-card class="ignore-list-options" .heading=${m(h.generalExclusionRules)}>
          <div class="ignore-list-option-group general-exclusion-group" role="group">
            <div class="ignore-list-option">
              <devtools-checkbox
                  name=${m(h.ignoreListContentScripts)}
                  title=${m(h.ignoreListContentScripts)}
                  ?disabled=${!s.enabled}
                  ${fe(s.skipContentScriptsSetting)}>
                ${m(h.ignoreListContentScripts)}
              </devtools-checkbox>
            </div>
            <div class="ignore-list-option">
              <devtools-checkbox
                  name=${m(h.automaticallyIgnoreListKnownThirdPartyScripts)}
                  title=${m(h.automaticallyIgnoreListKnownThirdPartyScripts)}
                  ?disabled=${!s.enabled}
                  ${fe(s.automaticallyIgnoreListSetting)}>
                ${m(h.automaticallyIgnoreListKnownThirdPartyScripts)}
              </devtools-checkbox>
              <devtools-button
                  .iconName=${"help"}
                  .variant=${X.Button.Variant.ICON}
                  .size=${X.Button.Size.SMALL}
                  .jslogContext=${"learn-more"}
                  .title=${m(h.learnMore)}
                  .disabled=${!s.enabled}
                  @click=${s.onLearnMoreClick}>
              </devtools-button>
            </div>
            <div class="ignore-list-option">
              <devtools-checkbox
                  name=${m(h.ignoreListAnonymousScripts)}
                  title=${m(h.ignoreListAnonymousScripts)}
                  ?disabled=${!s.enabled}
                  ${fe(s.skipAnonymousScriptsSetting)}>
                ${m(h.ignoreListAnonymousScripts)}
              </devtools-checkbox>
            </div>
          </div>
        </devtools-card>
        <devtools-card class="ignore-list-options" .heading=${m(h.customExclusionRules)}>
          <div class="ignore-list-option-group custom-exclusion-group" role="group">
            ${o.length>0?ne`
              <devtools-list
                  class="ignore-list"
                  .editable=${s.enabled}
                  .deletable=${s.enabled}
                  @edit=${r=>s.onBeginEdit(r.detail.index)}
                  @delete=${r=>s.onRemovePattern(r.detail.index)}>
                ${be.repeat(o,r=>r.pattern,(r,p)=>$t(r,p,s.enabled,s.onTogglePattern))}
              </devtools-list>
            `:Se}
            ${i!==null?pi(s):Se}
            ${i!==null&&n.length>0?ne`
              <devtools-list
                  class="ignore-list"
                  .editable=${s.enabled}
                  .deletable=${s.enabled}
                  @edit=${r=>s.onBeginEdit(i+1+r.detail.index)}
                  @delete=${r=>s.onRemovePattern(i+1+r.detail.index)}>
                ${be.repeat(n,r=>r.pattern,(r,p)=>$t(r,i+1+p,s.enabled,s.onTogglePattern))}
              </devtools-list>
            `:Se}
            <devtools-button
                class="add-button"
                .variant=${X.Button.Variant.OUTLINED}
                .jslogContext=${"settings.add-ignore-list-pattern"}
                aria-label=${m(h.addFilenamePattern)}
                .disabled=${!s.enabled}
                @click=${s.onAddPatternClick}>
              ${m(h.addPattern)}
            </devtools-button>
          </div>
        </devtools-card>
      </div>
    </div>
  `,t,{container:{attributes:{jslog:`${K.pane("blackbox")}`}}})},Ge=class extends we.Widget.VBox{setting;enabledSetting;skipContentScriptsSetting;automaticallyIgnoreListSetting;skipAnonymousScriptsSetting;#o;#e=null;#i="";#t=!1;constructor(e=Dt){super({useShadowDom:!0}),this.#o=e;let t=Lt.Settings.Settings.instance();this.enabledSetting=t.resolve(J.IgnoreListManager.enableIgnoreListingSettingDescriptor),this.skipContentScriptsSetting=t.resolve(J.IgnoreListManager.skipContentScriptsSettingDescriptor),this.automaticallyIgnoreListSetting=t.resolve(J.IgnoreListManager.automaticallyIgnoreListKnownThirdPartyScriptsSettingDescriptor),this.skipAnonymousScriptsSetting=t.resolve(J.IgnoreListManager.skipAnonymousScriptsSettingDescriptor),this.setting=t.resolve(J.IgnoreListManager.skipStackFramesPatternSettingDescriptor),this.setting.addChangeListener(this.#s,this),this.enabledSetting.addChangeListener(this.#s,this),this.performUpdate()}performUpdate(){let e=this.setting.getAsArray(),t=this.#e!==null?this.#h(this.#i,this.#e):null;this.#o({enabledSetting:this.enabledSetting,skipContentScriptsSetting:this.skipContentScriptsSetting,automaticallyIgnoreListSetting:this.automaticallyIgnoreListSetting,skipAnonymousScriptsSetting:this.skipAnonymousScriptsSetting,enabled:this.enabledSetting.get(),patterns:e,editingIndex:this.#e,editingValue:this.#i,validationError:t,showValidationError:this.#t,onLearnMoreClick:()=>{Pt.openInNewTab("https://developer.chrome.com/docs/devtools/settings/ignore-list/#skip-third-party")},onAddPatternClick:this.#n.bind(this),onTogglePattern:this.#c.bind(this),onBeginEdit:this.#a.bind(this),onRemovePattern:this.#g.bind(this),onEditorInput:this.#l.bind(this),onCommitEdit:this.#d.bind(this),onCancelEdit:this.#r.bind(this)},void 0,this.contentElement)}wasShown(){super.wasShown(),this.#r()}#s(){this.#e=null,this.#i="",this.#t=!1,this.performUpdate()}#n(){this.#e=this.setting.getAsArray().length,this.#i="",this.#t=!1,this.performUpdate()}#a(e){let t=this.setting.getAsArray();e<0||e>=t.length||(this.#e=e,this.#i=t[e].pattern,this.#t=!1,this.performUpdate())}#l(e){this.#i=e,this.#t=!0,this.performUpdate()}#r(){this.#e=null,this.#i="",this.#t=!1,this.performUpdate()}#d(){if(this.#e===null)return;if(this.#h(this.#i,this.#e)!==null){this.#t=!0,this.performUpdate();return}let t=this.#i.trim(),i=this.setting.getAsArray();this.#e===i.length?i.push({pattern:t,disabled:!1}):i[this.#e]&&(i[this.#e].pattern=t),this.#e=null,this.#i="",this.#t=!1,this.setting.setAsArray(i)}#c(e,t){let i=this.setting.getAsArray(),o=i[e];if(!o)return;let n=!t;o.disabled!==n&&(o.disabled=n,o.disabledForUrl=void 0,this.setting.setAsArray(i))}#g(e){let t=this.setting.getAsArray();t.splice(e,1),this.setting.setAsArray(t)}#h(e,t){let i=e.trim(),o=this.setting.getAsArray();if(!i.length)return m(h.patternCannotBeEmpty);for(let r=0;r<o.length;++r)if(r!==t&&o[r].pattern===i)return m(h.patternAlreadyExists);let n;try{n=new RegExp(i)}catch{}return n?null:m(h.patternMustBeAValidRegular)}};var Bt={};B(Bt,{DEFAULT_VIEW:()=>Ht,KeybindsSettingsTab:()=>Ye});import"../../ui/kit/kit.js";import*as We from"../../core/common/common.js";import*as P from"../../core/host/host.js";import*as Je from"../../core/i18n/i18n.js";import*as Nt from"../../core/platform/platform.js";import*as F from"../../ui/components/buttons/buttons.js";import*as Ft from"../../ui/legacy/components/settings_ui/settings_ui.js";import*as d from"../../ui/legacy/legacy.js";import*as vi from"../../ui/lit/lit.js";import*as qe from"../../ui/settings/settings.js";import*as Q from"../../ui/visual_logging/visual_logging.js";var zt=`.shortcut-list{padding-left:0;padding-right:0}.keybinds-key{display:flex;align-items:center;justify-content:center;height:var(--sys-size-11);min-width:var(--sys-size-11);font:var(--sys-typescale-body5-medium);white-space:nowrap;border-radius:var(--sys-shape-corner-small);background:var(--sys-color-tonal-container);padding:0 var(--sys-size-4)}.keybinds-list-item{margin:0 var(--sys-size-6);padding:var(--sys-size-4) 0;display:grid;grid-template-rows:1fr;grid-template-columns:1fr 30px 2fr 30px 30px;border-top:var(--sys-size-1) solid var(--app-color-card-divider)}.keybinds-list-item:focus-visible{background-color:var(--sys-color-tonal-container)}.keybinds-list-item-wrapper:has(.keybinds-list-item.keybinds-editing){background-color:var(--sys-color-neutral-container)}.keybinds-list-text.keybinds-action-name{grid-row:1/1}.keybinds-shortcut,
.keybinds-info{grid-row:auto;grid-column:3/span 1}.keybinds-error{color:var(--sys-color-error)}.keybinds-shortcut{gap:var(--sys-size-4)}.keybinds-list-item.keybinds-editing .keybinds-shortcut{display:flex}.keybinds-modified{grid-column:2/span 1;margin-top:var(--sys-size-3)}.keybinds-list-item button[disabled]{opacity:40%}.keybinds-cancel-button{grid-column:-1/span 1}.keybinds-edit-button{display:none;grid-row:1/span 1;grid-column:5/span 1}.keybinds-list-item:not(.keybinds-editing):hover .keybinds-edit-button,
.keybinds-list-item-wrapper:focus-within > .keybinds-list-item:not(.keybinds-editing) .keybinds-edit-button{display:inline-block}.keybinds-list-text{min-height:var(--sys-size-12);display:flex;align-items:center;user-select:none;color:var(--sys-color-on-surface);text-align:start;position:relative;margin-right:0}.keybinds-category-header{display:flex;align-items:center;font:var(--sys-typescale-body4-bold);height:var(--sys-size-13);padding:var(--sys-size-4) var(--sys-size-7);white-space:nowrap;+ .keybinds-list-item-wrapper > .keybinds-list-item{border-top:unset}}.keybinds-list-item-wrapper:has(.keybinds-list-item:hover),
.keybinds-list-item-wrapper:has(
  .keybinds-list-item:not(.keybinds-editing)):focus-within{background:var(--sys-color-state-hover-on-subtle)}.keybinds-set-select label p{display:inline;color:var(--sys-color-on-surface)}button.text-button{width:fit-content;align-self:flex-end}.keybinds-list-text input{margin:0 var(--sys-size-2)}.keybinds-set-select{margin:0;padding:var(--sys-size-5) var(--sys-size-7);& .settings-select{display:flex;justify-content:space-between;& label{padding:0}}}.keybinds-list-text:has(.keybinds-delete-button){grid-column:3/-1}.keybinds-delete-button{flex-shrink:0}.docs-link.devtools-link{align-self:flex-start;min-height:2em;line-height:2em;margin-bottom:var(--sys-size-3)}.keybinds-footer{padding:var(--sys-size-5) var(--sys-size-7);display:flex;flex-wrap:wrap;justify-content:space-between;min-height:fit-content;margin-top:10px}@media (forced-colors: active){.keybinds-list-item.keybinds-editing .keybinds-shortcut{& devtools-button{--sys-color-primary:buttonFace}}.keybinds-list-text input{color:buttonText}.keybinds-list-item-wrapper{&:has(.keybinds-list-item:hover),
    &:has(.keybinds-list-item:not(.keybinds-editing)):focus-within,
    &:focus,
    &:focus-visible{background-color:Highlight;forced-color-adjust:none;--icon-default:HighlightText;& .keybinds-list-text,
      & .keybinds-action-name{color:HighlightText}& .keybinds-key{background:HighlightText;color:Highlight}}}.keybinds-list-item-wrapper:has(.keybinds-list-item.keybinds-editing){background-color:Highlight;forced-color-adjust:none;--icon-default:HighlightText;& .keybinds-list-text{color:HighlightText}& .keybinds-error{color:highlightText}}}
/*# sourceURL=${import.meta.resolve("./keybindsSettingsTab.css")} */`;var{html:$,nothing:G,render:yi,Directives:{classMap:_e,repeat:Mt}}=vi,v={shortcuts:"Shortcuts",matchShortcutsFromPreset:"Shortcut preset",keyboardShortcutsList:"Keyboard shortcuts list",shortcutModified:"Shortcut modified",noShortcutForAction:"No shortcut for action",addAShortcut:"Add a shortcut",recordingKeys:"Recording keys",confirmChanges:"Confirm changes",discardChanges:"Discard changes",removeShortcut:"Remove shortcut",editShortcut:"Edit shortcut",shortcutsCannotContainOnly:"Shortcuts can\u2019t contain only modifier keys",thisShortcutIsInUseByS:"This shortcut is in use by {PH1}: {PH2}",RestoreDefaultShortcuts:"Restore default shortcuts",FullListOfDevtoolsKeyboard:"Full list of DevTools keyboard shortcuts and gestures",ResetShortcutsForAction:"Reset shortcuts for action",shortcutRemoved:"{PH1} Shortcut removed",shortcutChangesRestored:"Changes to shortcut restored to default",shortcutChangesApplied:"Changes to shortcut applied",shortcutChangesDiscarded:"Changes to shortcut discarded"},fi=Je.i18n.registerUIStrings("panels/settings/KeybindsSettingsTab.ts",v),f=Je.i18n.getLocalizedString.bind(void 0,fi);function Si(s,e){let t=()=>$`
    <devtools-button
      class="keybinds-edit-button"
      title=${f(v.editShortcut)}
      aria-label=${f(v.editShortcut)}
      .iconName=${"edit"}
      .variant=${F.Button.Variant.ICON}
      .jslogContext=${"edit"}
      @click=${()=>e.onStartEditing(s.action)}>
    </devtools-button>
  `;return $`
    <div
      class="keybinds-list-item-wrapper"
      @focusin=${()=>e.onActionFocused(s.action)}>
      <div
        class=${_e({"keybinds-list-item":!0,"keybinds-editing":s.isEditing})}
        role="listitem"
        aria-level="2"
        tabindex=${s.tabIndex}
        ?autofocus=${s.isAutofocus}
        jslog=${Q.item().context(s.actionId).track({keydown:"Escape",resize:!0})}
        @keydown=${s.isEditing?e.onEditingRowKeyDown:G}>
        <div class="keybinds-action-name keybinds-list-text">${s.actionTitle}</div>
        ${Mt(s.rows,i=>i.shortcut,(i,o)=>$`
          ${i.isModified?$`
            <devtools-icon
              class="keybinds-modified"
              name="keyboard-pen"
              aria-label=${f(v.shortcutModified)}>
            </devtools-icon>
          `:G}
          <div class="keybinds-shortcut keybinds-list-text">
            ${s.isEditing?$`
              <input
                class=${_e({"harmony-input":!0,"error-input":i.isInvalid})}
                jslog=${Q.textField().track({change:!0})}
                placeholder=${f(v.recordingKeys)}
                .spellcheck=${!1}
                maxlength="0"
                ?autofocus=${i.isAutofocus}
                aria-invalid=${i.isInvalid?"true":"false"}
                .value=${i.value}
                @keydown=${n=>e.onShortcutInputKeyDown(i.shortcut,n)}
                @focus=${()=>e.onShortcutInputFocus(i.shortcut)}
                @blur=${e.onShortcutInputBlur}
              />
              <devtools-button
                class="keybinds-delete-button"
                title=${f(v.removeShortcut)}
                aria-label=${f(v.removeShortcut)}
                .iconName=${"bin"}
                .variant=${F.Button.Variant.ICON}
                .jslogContext=${"delete"}
                @click=${()=>e.onDeleteShortcut(i.shortcut)}>
              </devtools-button>
            `:$`
              ${i.keys.map(n=>$`
                <div class="keybinds-key"><span>${n}</span></div>
              `)}
            `}
          </div>
          ${!s.isEditing&&o===0?t():G}
        `)}
        ${s.hasEmptyInfo?$`
          ${s.hasDefaultShortcutWhenEmpty?$`
            <devtools-icon
              class="keybinds-modified"
              name="keyboard-pen"
              aria-label=${f(v.shortcutModified)}>
            </devtools-icon>
          `:G}
          ${s.isEditing?G:$`
            <div
              class="keybinds-shortcut keybinds-list-text"
              aria-label=${f(v.noShortcutForAction)}>
            </div>
            ${t()}
          `}
        `:G}
        ${s.isEditing?$`
          <div class="keybinds-shortcut">
            <devtools-button
              .variant=${F.Button.Variant.OUTLINED}
              .jslogContext=${"add-shortcut"}
              ?autofocus=${s.rows.length===0}
              @click=${e.onAddShortcut}>
              ${f(v.addAShortcut)}
            </devtools-button>
          </div>
          <div
            class=${_e({"keybinds-info":!0,"keybinds-error":!0,hidden:!s.errorMessage})}
            role="alert"
            aria-live="polite">
            ${s.errorMessage??""}
          </div>
          <devtools-button
            title=${f(v.ResetShortcutsForAction)}
            aria-label=${f(v.ResetShortcutsForAction)}
            .iconName=${"undo"}
            .variant=${F.Button.Variant.ICON}
            .jslogContext=${"undo"}
            @click=${e.onResetShortcutsToDefaults}>
          </devtools-button>
          <devtools-button
            class="keybinds-confirm-button"
            title=${f(v.confirmChanges)}
            aria-label=${f(v.confirmChanges)}
            .iconName=${"checkmark"}
            .variant=${F.Button.Variant.ICON}
            .jslogContext=${"confirm"}
            .disabled=${s.isConfirmDisabled}
            @click=${e.onConfirmChanges}>
          </devtools-button>
          <devtools-button
            class="keybinds-cancel-button"
            title=${f(v.discardChanges)}
            aria-label=${f(v.discardChanges)}
            .iconName=${"cross"}
            .variant=${F.Button.Variant.ICON}
            .jslogContext=${"cancel"}
            @click=${e.onDiscardChanges}>
          </devtools-button>
        `:G}
      </div>
    </div>
  `}var Ht=(s,e,t)=>{yi($`
        <style>${zt}</style>
        <style>${W}</style>
        <div class="settings-card-container-wrapper">
          <div class="settings-card-container">
            <devtools-card heading=${f(v.shortcuts)}>
              <div class="keybinds-set-select">
                ${Ft.SettingsUI.renderControlForSetting(s.keybindsSetSetting,f(v.matchShortcutsFromPreset))}
              </div>
              <div
                class="shortcut-list"
                role="list"
                aria-label=${f(v.keyboardShortcutsList)}
                @keydown=${s.onListKeyDown}>
                ${Mt(s.items,i=>typeof i=="string"?i:i.actionId,i=>typeof i=="string"?$`
                          <div
                            class="keybinds-category-header"
                            role="listitem"
                            aria-level="1"
                            tabindex="-1">
                            ${d.ActionRegistration.getLocalizedActionCategory(i)}
                          </div>
                        `:Si(i,s))}
              </div>
              <div class="keybinds-footer">
                <devtools-link
                  class="docs-link"
                  href="https://developer.chrome.com/docs/devtools/shortcuts/"
                  jslogcontext="learn-more">
                  ${f(v.FullListOfDevtoolsKeyboard)}
                </devtools-link>
                <devtools-button
                  .variant=${F.Button.Variant.OUTLINED}
                  .jslogContext=${"restore-default-shortcuts"}
                  @click=${s.onRestoreDefaultShortcuts}>
                  ${f(v.RestoreDefaultShortcuts)}
                </devtools-button>
              </div>
            </devtools-card>
          </div>
        </div>
      `,t,{container:{classes:["flex-auto"],attributes:{jslog:`${Q.pane("keybinds")}`}}})},Ye=class extends d.Widget.VBox{#o;#e;#i=null;#t=null;#s=[];#n=new Map;#a=null;#l=!1;#r=null;#d;#c;#g;constructor(e=Ht){super({useShadowDom:"pure"}),this.#g=e,this.#d=We.Settings.Settings.instance().resolve(qe.MainSettings.activeKeybindSetSettingDescriptor),this.#c=We.Settings.Settings.instance().resolve(qe.MainSettings.userShortcutsSettingDescriptor),this.#d.addChangeListener(this.update,this),this.#o=this.#T(),this.#e=this.#o.filter(t=>t instanceof d.ActionRegistration.Action),this.#i=this.#e[0]??null,this.requestUpdate()}wasShown(){super.wasShown(),this.performUpdate()}#h(){this.#c.set([]),this.#d.set(d.ShortcutRegistry.DefaultShortcutSetting)}#m(e){let t=e===this.#t,i=e===this.#i,o=i&&!this.#t,n=i&&!t?0:-1,r=t?this.#s:d.ShortcutRegistry.ShortcutRegistry.instance().shortcutsForAction(e.id()),p=P.Platform.isMac()?"\u2004":"\u200A+\u200A",w=null,x=!1,M=[];for(let g of r){if(t&&this.#n.has(g)&&!this.#n.get(g))continue;let u=g.type!==d.KeyboardShortcut.Type.UNSET_SHORTCUT&&!g.isDefault(),H=t?this.#n.get(g):void 0,Ie=H?this.#k(H):g.title(),xe=g.descriptors.flatMap(L=>L.name.split(p)),_=!1;if(t&&this.#l&&H)if(H.some(L=>d.KeyboardShortcut.KeyboardShortcut.isModifier(L.key)))x=!0,_=!0,w=f(v.shortcutsCannotContainOnly);else{let L=d.ShortcutRegistry.ShortcutRegistry.instance().actionsForDescriptors(H).filter(le=>le!==e.id());if(L.length&&(x=!0,_=!0,d.ActionRegistry.ActionRegistry.instance().hasAction(L[0]))){let le=d.ActionRegistry.ActionRegistry.instance().getAction(L[0]);w=f(v.thisShortcutIsInUseByS,{PH1:le.category(),PH2:le.title()})}}M.push({shortcut:g,isModified:u,value:Ie,keys:xe,isInvalid:_,isAutofocus:!1})}if(t&&M.length>0){let g=M.find(u=>u.shortcut===this.#a)??M[0];g.isAutofocus=!0}return{action:e,actionId:e.id(),actionTitle:e.title(),isEditing:t,isAutofocus:o,tabIndex:n,hasEmptyInfo:r.length===0,hasDefaultShortcutWhenEmpty:r.length===0&&d.ShortcutRegistry.ShortcutRegistry.instance().actionHasDefaultShortcut(e.id()),rows:M,errorMessage:w,isConfirmDisabled:x}}performUpdate(){let e=this.#o.map(t=>typeof t=="string"?t:this.#m(t));this.#g({keybindsSetSetting:this.#d,items:e,onRestoreDefaultShortcuts:this.#h.bind(this),onListKeyDown:this.#u.bind(this),onActionFocused:this.#p.bind(this),onStartEditing:this.startEditing.bind(this),onAddShortcut:this.#x.bind(this),onResetShortcutsToDefaults:this.#C.bind(this),onConfirmChanges:this.#v.bind(this),onDiscardChanges:this.#y.bind(this),onEditingRowKeyDown:this.#f.bind(this),onShortcutInputKeyDown:this.#I.bind(this),onShortcutInputFocus:this.#S.bind(this),onShortcutInputBlur:this.#b.bind(this),onDeleteShortcut:this.#w.bind(this)},void 0,this.contentElement)}#p(e){this.#i!==e&&(this.#i=e,this.performUpdate())}#u(e){if(this.#t||this.#e.length===0)return;let t=this.#i?this.#e.indexOf(this.#i):-1,i=-1;switch(e.key){case"ArrowDown":case"PageDown":i=t<this.#e.length-1?t+1:this.#e.length-1;break;case"ArrowUp":case"PageUp":i=t>0?t-1:0;break;case"Home":i=0;break;case"End":i=this.#e.length-1;break;default:return}e.consume(!0);let o=this.#e[i];o&&(this.#i=o,this.performUpdate(),this.focus())}commitChanges(e,t){for(let[i,o]of t)i.type!==d.KeyboardShortcut.Type.UNSET_SHORTCUT&&(d.ShortcutRegistry.ShortcutRegistry.instance().removeShortcut(i),o||P.userMetrics.actionTaken(P.UserMetrics.Action.ShortcutRemoved)),o&&(d.ShortcutRegistry.ShortcutRegistry.instance().registerUserShortcut(i.changeKeys(o).changeType(d.KeyboardShortcut.Type.USER_SHORTCUT)),i.type===d.KeyboardShortcut.Type.UNSET_SHORTCUT?P.userMetrics.actionTaken(P.UserMetrics.Action.UserShortcutAdded):P.userMetrics.actionTaken(P.UserMetrics.Action.ShortcutModified));this.stopEditing(e)}startEditing(e){this.#i=e,this.#t&&this.stopEditing(this.#t),d.UIUtils.markBeingEdited(this.element,!0),this.#t=e,this.#n.clear(),this.#a=null,this.#l=!1,this.#s=d.ShortcutRegistry.ShortcutRegistry.instance().shortcutsForAction(e.id()),this.performUpdate(),this.focus()}stopEditing(e){this.#r!==null&&(clearTimeout(this.#r),this.#r=null),d.UIUtils.markBeingEdited(this.element,!1),this.#t=null,this.#s=[],this.#n.clear(),this.#a=null,this.#l=!1,this.performUpdate(),this.focus()}#v(){if(!this.#t)return;let e=this.#t;this.commitChanges(e,this.#n),d.ARIAUtils.LiveAnnouncer.alert(f(v.shortcutChangesApplied,{PH1:e.title()}))}#y(){this.#t&&(this.stopEditing(this.#t),d.ARIAUtils.LiveAnnouncer.alert(f(v.shortcutChangesDiscarded)))}#f(e){this.#t&&Nt.KeyboardUtilities.isEscKey(e)&&(this.stopEditing(this.#t),e.consume(!0))}#S(e){this.#a=e}#b(){this.#a=null,this.#r!==null&&(clearTimeout(this.#r),this.#r=null)}#w(e){if(!this.#t)return;let t=this.#s.indexOf(e);!e.isDefault()&&t!==-1&&this.#s.splice(t,1),this.#n.set(e,null),this.#a=null,this.#l=!0,this.performUpdate(),this.focus(),d.ARIAUtils.LiveAnnouncer.alert(f(v.shortcutRemoved,{PH1:this.#t.title()}))}#x(){if(!this.#t)return;let e=new d.KeyboardShortcut.KeyboardShortcut([],this.#t.id(),d.KeyboardShortcut.Type.UNSET_SHORTCUT);this.#s.push(e),this.#a=e,this.performUpdate(),this.focus()}#I(e,t){if(t.key!=="Tab"){let i=this.#A(t),o=this.#n.get(e)||[];this.#n.set(e,o);let n=o.length===2&&d.KeyboardShortcut.KeyboardShortcut.isModifier(o[1].key);o.length===2&&!n&&o.splice(0,2),this.#r?(clearTimeout(this.#r),this.#r=null,o.push(i)):n?o[1]=i:d.KeyboardShortcut.KeyboardShortcut.isModifier(i.key)?o[0]=i:(o[0]=i,this.#r=window.setTimeout(()=>{this.#r=null},d.ShortcutRegistry.KeyTimeout)),this.#l=!0,this.performUpdate(),t.consume(!0)}}#A(e){let t=d.KeyboardShortcut.KeyboardShortcut.makeKeyFromEvent(e),i=d.KeyboardShortcut.KeyboardShortcut.keyCodeAndModifiersFromKey(t),o=d.KeyboardShortcut.Keys[e.key]||d.KeyboardShortcut.KeyBindings[e.key];if(!o&&!/^[a-z]$/i.test(e.key)){let n=e.code;o=d.KeyboardShortcut.Keys[n]||d.KeyboardShortcut.KeyBindings[n],n.startsWith("Digit")?o=n.slice(5):n.startsWith("Key")&&(o=n.slice(3))}return d.KeyboardShortcut.KeyboardShortcut.makeDescriptor(o||e.key,i.modifiers)}#k(e){return e.map(t=>t.name).join(" ")}#C(){if(!this.#t)return;this.#n.clear();for(let t of this.#s)if(t.type===d.KeyboardShortcut.Type.UNSET_SHORTCUT){let i=this.#s.indexOf(t);this.#s.splice(i,1)}else t.type===d.KeyboardShortcut.Type.USER_SHORTCUT&&this.#n.set(t,null);d.ShortcutRegistry.ShortcutRegistry.instance().disabledDefaultsForAction(this.#t.id()).forEach(t=>{this.#s.includes(t)||(this.#s.push(t),this.#n.set(t,t.descriptors))}),this.#a=null,this.#l=!1,this.performUpdate(),this.focus(),d.ARIAUtils.LiveAnnouncer.alert(f(v.shortcutChangesRestored,{PH1:this.#t.title()}))}#T(){let e=d.ActionRegistry.ActionRegistry.instance().actions().filter(o=>o.configurableBindings()).sort((o,n)=>o.category()<n.category()?-1:o.category()>n.category()?1:o.id()<n.id()?-1:o.id()>n.id()?1:0),t=[],i;return e.forEach(o=>{i!==o.category()&&t.push(o.category()),t.push(o),i=o.category()}),t}onEscapeKeyPressed(e){this.#t&&this.#a&&d.DOMUtilities.deepActiveElement(document)?.nodeName==="INPUT"&&this.#I(this.#a,e)}update(){this.#t&&this.stopEditing(this.#t),!this.#i&&this.#e.length>0&&(this.#i=this.#e[0]),this.performUpdate()}willHide(){super.willHide(),this.#t&&this.stopEditing(this.#t)}};var _t={};B(_t,{DEFAULT_VIEW:()=>jt,WorkspaceSettingsTab:()=>Qe});import"../../ui/legacy/legacy.js";import"../../ui/components/buttons/buttons.js";import"../../ui/kit/kit.js";import*as Gt from"../../core/common/common.js";import*as Ze from"../../core/i18n/i18n.js";import*as T from"../../models/persistence/persistence.js";import*as Xe from"../../ui/components/buttons/buttons.js";import*as ae from"../../ui/legacy/legacy.js";import{html as Kt,render as bi}from"../../ui/lit/lit.js";import*as j from"../../ui/visual_logging/visual_logging.js";var Ot=`@scope to (devtools-widget > *){.mappings-info,
  .folder-exclude-pattern{height:var(--settings-single-item-height)}.mapping-view-container{padding-left:0;padding-right:0}.folder-exclude-pattern{display:flex;align-items:center;& > input{flex:1}}label{padding-bottom:0}.mappings-info{border:none}.add-button-container{max-width:var(--sys-size-35);margin-left:var(--sys-size-8);width:100%;& .add-folder{min-width:var(--sys-size-31);max-width:var(--sys-size-35)}}}
/*# sourceURL=${import.meta.resolve("./workspaceSettingsTab.css")} */`;var Z={workspace:"Workspace",mappingsAreInferredAutomatically:"Mappings are inferred automatically",addFolder:"Add folder",folderExcludePattern:"Exclude from workspace",remove:"Remove"},wi=Ze.i18n.registerUIStrings("panels/settings/WorkspaceSettingsTab.ts",Z),re=Ze.i18n.getLocalizedString.bind(void 0,wi),{widget:Ii}=ae.Widget,jt=(s,e,t)=>{bi(Kt`
    <style>${Ot}</style>
    <div class="settings-card-container-wrapper" jslog=${j.pane("workspace")}>
      <div class="settings-card-container">
        <devtools-card heading=${re(Z.workspace)}>
          <div class="folder-exclude-pattern">
            <label for="workspace-setting-folder-exclude-pattern">${re(Z.folderExcludePattern)}</label>
            <input
              class="harmony-input"
              jslog=${j.textField().track({keydown:"Enter",change:!0}).context(s.excludePatternSetting.name)}
              ${ae.UIUtils.bindToSetting(s.excludePatternSetting,{jslog:!1})}
              id="workspace-setting-folder-exclude-pattern">
          </div>
          <div class="mappings-info">${re(Z.mappingsAreInferredAutomatically)}</div>
        </devtools-card>
        ${s.fileSystems.map(i=>Kt`
          <devtools-card heading=${i.displayName}>
            <devtools-icon name="folder" slot="heading-prefix"></devtools-icon>
            <div class="mapping-view-container">
              ${Ii(oe,{fileSystem:i.fileSystem})}
            </div>
            <devtools-button
              slot="heading-suffix"
              .variant=${Xe.Button.Variant.OUTLINED}
              jslog=${j.action().track({click:!0}).context("settings.remove-file-system")}
              @click=${s.onRemoveClicked.bind(null,i.fileSystem)}>${re(Z.remove)}</devtools-button>
          </devtools-card>
        `)}
        <div class="add-button-container">
          <devtools-button
            class="add-folder"
            .variant=${Xe.Button.Variant.OUTLINED}
            jslog=${j.action().track({click:!0}).context("sources.add-folder-to-workspace")}
            @click=${s.onAddClicked}>${re(Z.addFolder)}</devtools-button>
        </div>
      </div>
    </div>`,t)},Qe=class s extends ae.Widget.VBox{#o;#e=[];constructor(e=jt){super(),this.#o=e}wasShown(){super.wasShown(),this.#e=[T.IsolatedFileSystemManager.IsolatedFileSystemManager.instance().addEventListener(T.IsolatedFileSystemManager.Events.FileSystemAdded,this.requestUpdate.bind(this)),T.IsolatedFileSystemManager.IsolatedFileSystemManager.instance().addEventListener(T.IsolatedFileSystemManager.Events.FileSystemRemoved,this.requestUpdate.bind(this))],this.requestUpdate()}willHide(){super.willHide(),Gt.EventTarget.removeEventListeners(this.#e),this.#e=[]}performUpdate(){let e={excludePatternSetting:T.IsolatedFileSystemManager.IsolatedFileSystemManager.instance().workspaceFolderExcludePatternSetting(),onAddClicked:()=>T.IsolatedFileSystemManager.IsolatedFileSystemManager.instance().addFileSystem(),onRemoveClicked:t=>T.IsolatedFileSystemManager.IsolatedFileSystemManager.instance().removeFileSystem(t),fileSystems:T.IsolatedFileSystemManager.IsolatedFileSystemManager.instance().fileSystems().filter(t=>{let i=T.NetworkPersistenceManager.NetworkPersistenceManager.instance().project();return t instanceof T.IsolatedFileSystem.IsolatedFileSystem&&(!i||T.IsolatedFileSystemManager.IsolatedFileSystemManager.instance().fileSystem(i.fileSystemPath())!==t)}).map(t=>({displayName:s.#i(t),fileSystem:t})).sort((t,i)=>t.displayName.localeCompare(i.displayName))};this.#o(e,void 0,this.contentElement)}static#i(e){let t=e.path(),i=t.lastIndexOf("/"),o=t.substring(i+1);return decodeURIComponent(o)}};export{vt as AISettingsTab,wt as BackendLinkingSettingsTab,Et as EditFileSystemView,Vt as FrameworkIgnoreListSettingsTab,Bt as KeybindsSettingsTab,dt as SettingsScreen,_t as WorkspaceSettingsTab};
//# sourceMappingURL=settings.js.map
