var V=Object.defineProperty;var C=(o,t)=>{for(var r in t)V(o,r,{get:t[r],enumerable:!0})};var M={};C(M,{DEFAULT_VIEW:()=>T,DeveloperResourcesRevealer:()=>L,DeveloperResourcesView:()=>S});import"../../ui/legacy/legacy.js";import*as P from"../../core/i18n/i18n.js";import*as $ from"../../core/platform/platform.js";import*as f from"../../core/sdk/sdk.js";import*as n from"../../ui/legacy/legacy.js";import{html as z,render as _}from"../../ui/lit/lit.js";import*as x from"../../ui/visual_logging/visual_logging.js";import"../../ui/legacy/components/data_grid/data_grid.js";import"../../ui/components/highlighting/highlighting.js";import*as y from"../../core/host/host.js";import*as u from"../../core/i18n/i18n.js";import*as b from"../../core/platform/platform.js";import*as c from"../../core/sdk/sdk.js";import*as v from"../../ui/legacy/legacy.js";import{html as p,nothing as l,render as E}from"../../ui/lit/lit.js";var U=`@scope to (devtools-widget > *){.data-grid{border:none}::part(url-outer){width:100%;display:inline-flex;justify-content:flex-start}::part(filter-highlight){font-weight:bold}::part(url-prefix){overflow-x:hidden;text-overflow:ellipsis}::part(url-suffix){flex:none}}
/*# sourceURL=${import.meta.resolve("./developerResourcesListView.css")} */`;var i={status:"Status",url:"URL",initiator:"Initiator",totalBytes:"Total bytes",duration:"Duration",error:"Error",developerResources:"Developer resources",copyUrl:"Copy URL",copyInitiatorUrl:"Copy initiator URL",pending:"Pending",success:"Success",failure:"Failure",sBytes:"{n, plural, =1 {# byte} other {# bytes}}",numberOfResourceMatch:"{n, plural, =1 {# resource matches} other {# resources match}}",noResourceMatches:"No resource matches"},K=u.i18n.registerUIStrings("panels/developer_resources/DeveloperResourcesListView.ts",i),a=u.i18n.getLocalizedString.bind(void 0,K),{withThousandsSeparator:F}=b.NumberUtilities,H=(o,t,r)=>{function s(e,R){if(!e)return"";let d=o.filters.find(D=>D.key?.split(",")?.includes(R));if(!d?.regex)return"";let w=d.regex.exec(e);return w?.length?`${w.index},${w[0].length}`:""}E(p`
      <style>${U}</style>
      <devtools-data-grid name=${a(i.developerResources)} striped class="flex-auto"
         .filters=${o.filters} @contextmenu=${o.onContextMenu} @selected=${o.onSelect}>
        <table>
          <tr>
            <th id="status" sortable fixed width="60px">
              ${a(i.status)}
            </th>
            <th id="url" sortable width="250px">
              ${a(i.url)}
            </th>
            <th id="initiator" sortable width="80px">
              ${a(i.initiator)}
            </th>
            <th id="size" sortable fixed width="80px" align="right">
              ${a(i.totalBytes)}
            </th>
            <th id="duration" sortable fixed width="80px" align="right">
              ${a(i.duration)}
            </th>
            <th id="error-message" sortable width="200px">
              ${a(i.error)}
            </th>
          </tr>
          ${o.items.map((e,R)=>{let d=/^(.*)(\/[^/]*)$/.exec(e.url);return p`
            <tr selected=${e===o.selectedItem||l}
                data-url=${e.url??l}
                data-initiator-url=${e.initiator.initiatorUrl??l}
                data-index=${R}>
              <td>${e.success===!0?a(i.success):e.success===!1?a(i.failure):a(i.pending)}</td>
              <td title=${e.url} aria-label=${e.url}>
                <devtools-highlight aria-hidden="true" part="url-outer"
                                    ranges=${s(e.url,"url")}>
                  <div part="url-prefix">${d?d[1]:e.url}</div>
                  <div part="url-suffix">${d?d[2]:""}</div>
                </devtools-highlight>
              </td>
              <td title=${e.initiator.initiatorUrl||""}
                  aria-label=${e.initiator.initiatorUrl||""}
                  @mouseenter=${()=>o.onInitiatorMouseEnter(e.initiator.frameId)}
                  @mouseleave=${o.onInitiatorMouseLeave}
              >${e.initiator.initiatorUrl||""}</td>
              <td aria-label=${e.size!==null?a(i.sBytes,{n:e.size}):l}
                  data-value=${e.size??l}>${e.size!==null?p`<span>${F(e.size)}</span>`:""}</td>
              <td aria-label=${e.duration!==null?u.TimeUtilities.millisToString(e.duration):l}
                  data-value=${e.duration??l}>${e.duration!==null?p`<span>${u.TimeUtilities.millisToString(e.duration)}</span>`:""}</td>
              <td class="error-message">
                ${e.errorMessage?p`
                <devtools-highlight ranges=${s(e.errorMessage,"error-message")}>
                  ${e.errorMessage}
                </devtools-highlight>`:l}
              </td>
            </tr>`})}
          </table>
        </devtools-data-grid>`,r)},m=class extends v.Widget.VBox{#e=[];#t=null;#r=null;#o;#s=[];constructor(t,r=H){super(t,{useShadowDom:!0}),this.#o=r}set selectedItem(t){this.#t=t,this.requestUpdate()}set onSelect(t){this.#r=t}#i(t,r){let s=r.dataset.url;s&&t.clipboardSection().appendItem(a(i.copyUrl),()=>{y.InspectorFrontendHost.InspectorFrontendHostInstance.copyText(s)},{jslogContext:"copy-url"});let e=r.dataset.initiatorUrl;e&&t.clipboardSection().appendItem(a(i.copyInitiatorUrl),()=>{y.InspectorFrontendHost.InspectorFrontendHostInstance.copyText(e)},{jslogContext:"copy-initiator-url"})}set items(t){this.#e=[...t],this.requestUpdate()}reset(){this.items=[],this.requestUpdate()}set filters(t){this.#s=t,this.requestUpdate(),this.updateComplete.then(()=>{let r=Number(this.contentElement.querySelector("devtools-data-grid")?.getAttribute("aria-rowcount"))??0,s="";r===0?s=a(i.noResourceMatches):s=a(i.numberOfResourceMatch,{n:r}),v.ARIAUtils.LiveAnnouncer.alert(s)})}performUpdate(){let t={items:this.#e,selectedItem:this.#t,filters:this.#s,onContextMenu:r=>{r.detail?.element&&this.#i(r.detail.menu,r.detail.element)},onSelect:r=>{this.#t=r.detail?this.#e[Number(r.detail.dataset.index)]:null,this.#r?.(this.#t)},onInitiatorMouseEnter:r=>{let s=r?c.FrameManager.FrameManager.instance().getFrame(r):null;s&&s.highlight()},onInitiatorMouseLeave:()=>{c.OverlayModel.OverlayModel.hideDOMNodeHighlight(c.TargetManager.TargetManager.instance())}};this.#o(t,void 0,this.contentElement)}};var I=`@scope to (devtools-widget > *){:scope{overflow:hidden}.developer-resource-view-toolbar-container{display:flex;border-bottom:var(--sys-size-1) solid var(--sys-color-divider);flex:0 0 auto}.developer-resource-view-toolbar{width:100%}.developer-resource-view-toolbar-summary{background-color:var(--sys-color-cdt-base-container);border-top:var(--sys-size-1) solid var(--sys-color-divider);padding-left:var(--sys-size-3);flex:0 0 calc(var(--sys-size-9) - var(--sys-size-1));display:flex;padding-right:var(--sys-size-3)}.developer-resource-view-toolbar-summary .developer-resource-view-message{padding-top:var(--sys-size-2);padding-left:1ex;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.developer-resource-view-results{overflow-y:auto;display:flex;flex:auto}}
/*# sourceURL=${import.meta.resolve("./developerResourcesView.css")} */`;var{widget:j}=n.Widget,{bindToSetting:q}=n.UIUtils,g={filterByText:"Filter by URL and error",loadHttpsDeveloperResources:"Load HTTP(S) developer resources through the website you inspect, not through DevTools",enableLoadingThroughTarget:"Load through website",resourcesCurrentlyLoading:"{PH1} resources, {PH2} currently loading",resources:"{n, plural, =1 {# resource} other {# resources}}"},B=P.i18n.registerUIStrings("panels/developer_resources/DeveloperResourcesView.ts",g),h=P.i18n.getLocalizedString.bind(void 0,B),L=class{async reveal(t){let s=f.PageResourceLoader.PageResourceLoader.instance().getResourcesLoaded().get(t.key);if(s)return await n.ViewManager.ViewManager.instance().showView("developer-resources"),await(await n.ViewManager.ViewManager.instance().view("developer-resources").widget()).select(s)}},T=(o,t,r)=>{_(z`
    <style>
      ${I}
    </style>
    <div class="vbox flex-auto" jslog=${x.panel("developer-resources").track({resize:!0})}>
      <div class="developer-resource-view-toolbar-container" jslog=${x.toolbar()}
          role="toolbar">
        <devtools-toolbar class="developer-resource-view-toolbar" role="presentation">
          <devtools-toolbar-input type="filter" placeholder=${h(g.filterByText)}
              @change=${o.onFilterChanged} style="flex-grow:1">
          </devtools-toolbar-input>
          <devtools-checkbox
              title=${h(g.loadHttpsDeveloperResources)}
              ${q(o.loadThroughTargetSetting)}>
            ${h(g.enableLoadingThroughTarget)}
          </devtools-checkbox>
        </devtools-toolbar>
      </div>
      <div class="developer-resource-view-results">
        ${j(m,{items:o.items,selectedItem:o.selectedItem,onSelect:o.onSelect,filters:o.filters})}
      </div>
      <div class="developer-resource-view-toolbar-summary">
        <div class="developer-resource-view-message">
          ${o.numLoading>0?h(g.resourcesCurrentlyLoading,{PH1:o.numResources,PH2:o.numLoading}):h(g.resources,{n:o.numResources})}
         </div>
      </div>
    </div>`,r)},S=class extends n.Widget.VBox{#e;#t;#r=null;#o=[];constructor(t=T){super({useShadowDom:!0}),this.#t=t,this.#e=f.PageResourceLoader.PageResourceLoader.instance(),this.#e.addEventListener(f.PageResourceLoader.Events.UPDATE,this.requestUpdate,this),this.requestUpdate()}async performUpdate(){let{loading:t,resources:r}=this.#e.getScopedNumberOfResources(),s={onFilterChanged:e=>{this.#s(e.detail)},items:this.#e.getResourcesLoaded().values(),selectedItem:this.#r,onSelect:e=>{this.#r=e},filters:this.#o,numResources:r,numLoading:t,loadThroughTargetSetting:this.#e.getLoadThroughTargetSetting()};this.#t(s,void 0,this.contentElement)}async select(t){await this.updateComplete,this.#r=t,this.requestUpdate()}async selectedItem(){return await this.updateComplete,this.#r}#s(t){let r=t?$.StringUtilities.createPlainTextSearchRegex(t,"i"):null;r?this.#o=[{key:"url,error-message",regex:r,negative:!1}]:this.#o=[],this.requestUpdate()}};export{M as DeveloperResourcesView};
//# sourceMappingURL=developer_resources.js.map
