var h=Object.defineProperty;var b=(r,t)=>{for(var e in t)h(r,e,{get:t[e],enumerable:!0})};import*as C from"../ai-utils/ai-utils.js";var f={};b(f,{AiCodeCompletion:()=>p,consoleAdditionalContextFileContent:()=>A});import*as o from"../../core/host/host.js";import*as s from"../../core/root/root.js";import*as g from"../ai-utils/ai-utils.js";var{debugCodeGenCompleteLog:u}=g.Debug,A=`/**
 * This file describes the execution environment of the Chrome DevTools Console.
 * The code is JavaScript, but with special global functions and variables.
 * Top-level await is available.
 * The console has direct access to the inspected page's \`window\` and \`document\`.
 */

/**
 * @description Returns the value of the most recently evaluated expression.
 */
let $_;

/**
 * @description A reference to the most recently selected DOM element.
 * $0, $1, $2, $3, $4 can be used to reference the last five selected DOM elements.
 */
let $0;

/**
 * @description A query selector alias. $$('.my-class') is equivalent to document.querySelectorAll('.my-class').
 */
function $$(selector, startNode) {}

/**
 * @description An XPath selector. $x('//p') returns an array of all <p> elements.
 */
function $x(path, startNode) {}

function clear() {}

function copy(object) {}

/**
 * @description Selects and reveals the specified element in the Elements panel.
 */
function inspect(object) {}

function keys(object) {}

function values(object) {}

/**
 * @description When the specified function is called, the debugger is invoked.
 */
function debug(func) {}

/**
 * @description Stops the debugging of the specified function.
 */
function undebug(func) {}

/**
 * @description Logs a message to the console whenever the specified function is called,
 * along with the arguments passed to it.
 */
function monitor(func) {}

/**
 * @description Stops monitoring the specified function.
 */
function unmonitor(func) {}

/**
 * @description Logs all events dispatched to the specified object to the console.
 */
function monitorEvents(object, events) {}

/**
 * @description Returns an object containing all event listeners registered on the specified object.
 */
function getEventListeners(object) {}

/**
 * The global \`console\` object has several helpful methods
 */
const console = {
  log: (...args) => {},
  warn: (...args) => {},
  error: (...args) => {},
  info: (...args) => {},
  debug: (...args) => {},
  assert: (assertion, ...args) => {},
  dir: (object) => {}, // Displays an interactive property listing of an object.
  dirxml: (object) => {}, // Displays an XML/HTML representation of an object.
  table: (data, columns) => {}, // Displays tabular data as a table.
  group: (label) => {}, // Creates a new inline collapsible group.
  groupEnd: () => {},
  time: (label) => {}, // Starts a timer.
  timeEnd: (label) => {} // Stops a timer and logs the elapsed time.
};`,v=5,R=3,p=class r{#s;#n;#e;#t;#a;#r=crypto.randomUUID();#i;#o;constructor(t,e,i){this.#i=t.aidaClient,this.#o=t.serverSideLoggingEnabled??!1,this.#s=i??[],this.#a=e}#d(t,e,i=o.AidaClient.AidaInferenceLanguage.JAVASCRIPT,n){let d=o.AidaClient.convertToUserTierEnum(this.#u);function a(l){return typeof l=="number"&&l>=0?l:void 0}t=`
`+t;let c=n;return{client:o.AidaClient.CLIENT_NAME,prefix:t,suffix:e,options:{inference_language:i,temperature:a(this.#l.temperature),model_id:this.#l.modelId||void 0,stop_sequences:this.#s},metadata:{disable_user_content_logging:!(this.#o??!1),string_session_id:this.#r,user_tier:d,client_version:s.Runtime.getChromeVersion()},additional_files:c}}async#c(t){let e=this.#p(t);if(e)return{response:e,fromCache:!0};let i=await this.#i.completeCode(t);return i?(this.#m(t,i),{response:i,fromCache:!1}):{response:null,fromCache:!1}}get#u(){return s.Runtime.hostConfig.devToolsAiCodeCompletion?.userTier}get#l(){let t=s.Runtime.hostConfig.devToolsAiCodeCompletion?.temperature,e=s.Runtime.hostConfig.devToolsAiCodeCompletion?.modelId;return{temperature:t,modelId:e}}#p(t){if(!this.#e||this.#e.request.suffix!==t.suffix||JSON.stringify(this.#e.request.options)!==JSON.stringify(t.options))return null;let e=[];for(let i of this.#e.response.generatedSamples){let n=this.#e.request.prefix+i.generationString;n.startsWith(t.prefix)&&e.push({generationString:n.substring(t.prefix.length),sampleId:i.sampleId,score:i.score,attributionMetadata:i.attributionMetadata})}return e.length===0?null:{generatedSamples:e,metadata:this.#e.response.metadata}}#m(t,e){this.#e={request:t,response:e}}registerUserImpression(t,e,i){let n=Math.floor(e/1e3),d=e%1e3,a=Math.floor(d*1e6);this.#i.registerClientEvent({corresponding_aida_rpc_global_id:t,disable_user_content_logging:!(this.#o??!1),complete_code_client_event:{user_impression:{sample:{sample_id:i},latency:{duration:{seconds:n,nanos:a}}}}}),u("Registered user impression with latency {seconds:",n,", nanos:",a,"}"),o.userMetrics.actionTaken(o.UserMetrics.Action.AiCodeCompletionSuggestionDisplayed)}registerUserAcceptance(t,e){this.#i.registerClientEvent({corresponding_aida_rpc_global_id:t,disable_user_content_logging:!(this.#o??!1),complete_code_client_event:{user_acceptance:{sample:{sample_id:e}}}}),u("Registered user acceptance"),o.userMetrics.actionTaken(o.UserMetrics.Action.AiCodeCompletionSuggestionAccepted)}clearCachedRequest(){this.#e=void 0}async completeCode(t,e,i,n,d){let a=t+e;if(a.length<v)return{response:null,fromCache:!1};if(this.#t&&Math.abs(a.length-this.#t.length)<R)return{response:null,fromCache:!1};let c=this.#d(t,e,n,d),{response:l,fromCache:m}=await this.#c(c);return u("At cursor position",i,{request:c,response:l,fromCache:m}),!l||l.generatedSamples.length===0?(this.#t=a,{response:null,fromCache:!1}):(this.#t=void 0,{response:l,fromCache:m})}remove(){this.#n&&(clearTimeout(this.#n),this.#n=void 0),this.#a?.setAiAutoCompletion(null)}static isAiCodeCompletionAvailable(){return s.Runtime.hostConfig.devToolsAiCodeCompletion?.enabled??!1}static isAiCodeCompletionEnabled(t){if(!t.startsWith("en-"))return!1;let e=s.Runtime.hostConfig.aidaAvailability;return!e||e.blockedByGeo||e.blockedByAge||e.blockedByEnterprisePolicy?!1:!!(e.enabled&&r.isAiCodeCompletionAvailable())}static isAiCodeCompletionStylesAvailable(){return s.Runtime.hostConfig.devToolsAiCodeCompletionStyles?.enabled??!1}static isAiCodeCompletionStylesEnabled(t){if(!t.startsWith("en-"))return!1;let e=s.Runtime.hostConfig.aidaAvailability;return!e||e.blockedByGeo||e.blockedByAge||e.blockedByEnterprisePolicy?!1:!!(e.enabled&&r.isAiCodeCompletionStylesAvailable())}};function y(...r){C.Debug.debugCodeGenCompleteLog(...r)}export{f as AiCodeCompletion,y as debugLog};
//# sourceMappingURL=ai_code_completion.js.map
