var p=Object.defineProperty;var h=(a,t)=>{for(var e in t)p(a,e,{get:t[e],enumerable:!0})};import*as m from"../ai-utils/ai-utils.js";var g={};h(g,{AiCodeGeneration:()=>c,additionalContextForConsole:()=>C,basePreamble:()=>f});import*as i from"../../core/host/host.js";import*as n from"../../core/root/root.js";import*as u from"../ai-utils/ai-utils.js";var{debugCodeGenCompleteLog:l}=u.Debug,f=`You are a highly skilled senior software engineer with deep expertise across multiple web technologies and programming languages, including JavaScript, TypeScript, HTML, and CSS.
Your role is to act as an expert pair programmer within the Chrome DevTools environment.

**Core Directives (Adhere to these strictly):**

1. **Language and Quality:**
    * Generate code that is modern, efficient, and idiomatic for the inferred language (e.g., modern JavaScript/ES6+, semantic HTML5, efficient CSS).
    * Where appropriate, include basic error handling (e.g., for API calls).
    * Determine the programming language from the user's prompt.

2.  **Output Format (Strict):**
    * **Return ONLY code blocks.** * Do NOT include any introductory text, explanations, or concluding remarks.
    * Do NOT provide step-by-step guides or descriptions of how the code works.
    * Inline comments within the code are permitted and encouraged for clarity.

3. **Handling Ambiguity:**
    * If the user's request is vague, unclear, or lacks sufficient detail to generate a functional solution, do NOT generate placeholder code.
    * Instead, output a single comment block asking for specific clarification on the desired task or logic.
    * Example output for vague input: // The request is unclear. Please specify the desired functionality or logic you need implemented.
`,C=`
You are operating within the execution environment of the Chrome DevTools Console.
The console has direct access to the inspected page's \`window\` and \`document\`.

*   **Utilize Console Utilities:** You have access to the Console Utilities API. You **should** use these helper functions and variables when they are the most direct way to accomplish the user's goal.
`,c=class a{#o=crypto.randomUUID();#e;#t;constructor(t){this.#e=t.aidaClient,this.#t=t.serverSideLoggingEnabled??!1}#n(t,e,d=i.AidaClient.AidaInferenceLanguage.JAVASCRIPT){let s=i.AidaClient.convertToUserTierEnum(this.#s);function r(o){return typeof o=="number"&&o>=0?o:void 0}return t=e+t+`
**Target Language:** `+d,{client:i.AidaClient.CLIENT_NAME,preamble:e,current_message:{parts:[{text:t}],role:i.AidaClient.Role.USER},use_case:i.AidaClient.UseCase.CODE_GENERATION,options:{temperature:r(this.#i.temperature),model_id:this.#i.modelId||void 0},metadata:{disable_user_content_logging:!(this.#t??!1),string_session_id:this.#o,user_tier:s,client_version:n.Runtime.getChromeVersion()}}}get#s(){return n.Runtime.hostConfig.devToolsAiCodeGeneration?.userTier}get#i(){let t=n.Runtime.hostConfig.devToolsAiCodeGeneration?.temperature,e=n.Runtime.hostConfig.devToolsAiCodeGeneration?.modelId;return{temperature:t,modelId:e}}registerUserImpression(t,e,d){let s=Math.floor(e/1e3),r=e%1e3,o=Math.floor(r*1e6);this.#e.registerClientEvent({corresponding_aida_rpc_global_id:t,disable_user_content_logging:!(this.#t??!1),generate_code_client_event:{user_impression:{sample:{sample_id:d},latency:{duration:{seconds:s,nanos:o}}}}}),l("Registered user impression with latency {seconds:",s,", nanos:",o,"}"),i.userMetrics.actionTaken(i.UserMetrics.Action.AiCodeGenerationSuggestionDisplayed)}registerUserAcceptance(t,e){this.#e.registerClientEvent({corresponding_aida_rpc_global_id:t,disable_user_content_logging:!(this.#t??!1),generate_code_client_event:{user_acceptance:{sample:{sample_id:e}}}}),l("Registered user acceptance"),i.userMetrics.actionTaken(i.UserMetrics.Action.AiCodeGenerationSuggestionAccepted)}async generateCode(t,e,d,s){let r=this.#n(t,e,d),o=await this.#e.generateCode(r,s);return l({request:r,response:o}),o}static isAiCodeGenerationAvailable(){return n.Runtime.hostConfig.devToolsAiCodeGeneration?.enabled??!1}static isAiCodeGenerationEnabled(t){if(!t.startsWith("en-"))return!1;let e=n.Runtime.hostConfig.aidaAvailability;return!e||e.blockedByGeo||e.blockedByAge||e.blockedByEnterprisePolicy?!1:!!(e.enabled&&a.isAiCodeGenerationAvailable())}};function b(...a){m.Debug.debugCodeGenCompleteLog(...a)}export{g as AiCodeGeneration,b as debugLog};
//# sourceMappingURL=ai_code_generation.js.map
