var fe=.8999999999999999,ve=.5,be=.49999999999999994;function _e(e){let t=Math.sign(e);e=Math.abs(e);let r=.254829592,i=-.284496736,a=1.421413741,l=-1.453152027,o=1.061405429,n=1/(1+.3275911*e),c=n*(r+n*(i+n*(a+n*(l+n*o))));return t*(1-c*Math.exp(-e*e))}function we({median:e,p10:t},r){if(e<=0)throw new Error("median must be greater than zero");if(t<=0)throw new Error("p10 must be greater than zero");if(t>=e)throw new Error("p10 must be less than the median");if(r<=0)return 1;let i=.9061938024368232,a=Math.max(Number.MIN_VALUE,r/e),l=Math.log(a),o=Math.max(Number.MIN_VALUE,t/e),n=-Math.log(o),c=l*i/n,s=(1-_e(c))/2,d;return r<=t?d=Math.max(.9,Math.min(1,s)):r<=e?d=Math.max(ve,Math.min(fe,s)):d=Math.max(0,Math.min(be,s)),d}var $="\u2026",ye="\xA0",he=.9,xe={PASS:{label:"pass",minScore:he},AVERAGE:{label:"average",minScore:.5},FAIL:{label:"fail"},ERROR:{label:"error"}},ke=["com","co","gov","edu","ac","org","go","gob","or","net","in","ne","nic","gouv","web","spb","blog","jus","kiev","mil","wi","qc","ca","bel","on"],C=class G{static get RATINGS(){return xe}static get PASS_THRESHOLD(){return he}static get MS_DISPLAY_VALUE(){return`%10d${ye}ms`}static isPluginCategory(t){return/^(@[a-z0-9-~][a-z0-9-._~]*\/)?lighthouse-plugin-[a-z0-9-._~]*$/.test(t)}static getFinalDisplayedUrl(t){if(t.finalDisplayedUrl)return t.finalDisplayedUrl;if(t.finalUrl)return t.finalUrl;throw new Error("Could not determine final displayed URL")}static getMainDocumentUrl(t){return t.mainDocumentUrl||t.finalUrl}static getFullPageScreenshot(t){return t.fullPageScreenshot?t.fullPageScreenshot:t.audits["full-page-screenshot"]?.details}static getEntityFromUrl(t,r){return r&&r.find(i=>i.origins.find(a=>t.startsWith(a)))||G.getPseudoRootDomain(t)}static splitMarkdownCodeSpans(t){let r=[],i=t.split(/`(.*?)`/g);for(let a=0;a<i.length;a++){let l=i[a];if(!l)continue;let o=a%2!==0;r.push({isCode:o,text:l})}return r}static splitMarkdownLink(t){let r=[],i=t.split(/\[([^\]]+?)\]\((https?:\/\/.*?)\)/g);for(;i.length;){let[a,l,o]=i.splice(0,3);a&&r.push({isLink:!1,text:a}),l&&o&&r.push({isLink:!0,text:l,linkHref:o})}return r}static truncate(t,r,i="\u2026"){if(t.length<=r)return t;let a=new Intl.Segmenter(void 0,{granularity:"grapheme"}).segment(t)[Symbol.iterator](),l=0;for(let o=0;o<=r-i.length;o++){let n=a.next();if(n.done)return t;l=n.value.index}for(let o=0;o<i.length;o++)if(a.next().done)return t;return t.slice(0,l)+i}static getURLDisplayName(t,r){r=r||{numPathParts:void 0,preserveQuery:void 0,preserveHost:void 0};let i=r.numPathParts!==void 0?r.numPathParts:2,a=r.preserveQuery!==void 0?r.preserveQuery:!0,l=r.preserveHost||!1,o;if(t.protocol==="about:"||t.protocol==="data:")o=t.href;else{o=t.pathname;let c=o.split("/").filter(s=>s.length);i&&c.length>i&&(o=$+c.slice(-1*i).join("/")),l&&(o=`${t.host}/${o.replace(/^\//,"")}`),a&&(o=`${o}${t.search}`)}let n=64;if(t.protocol!=="data:"&&(o=o.slice(0,200),o=o.replace(/([a-f0-9]{7})[a-f0-9]{13}[a-f0-9]*/g,`$1${$}`),o=o.replace(/([a-zA-Z0-9-_]{9})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9-_]{10,}/g,`$1${$}`),o=o.replace(/(\d{3})\d{6,}/g,`$1${$}`),o=o.replace(/\u2026+/g,$),o.length>n&&o.includes("?")&&(o=o.replace(/\?([^=]*)(=)?.*/,`?$1$2${$}`),o.length>n&&(o=o.replace(/\?.*/,`?${$}`)))),o.length>n){let c=o.lastIndexOf(".");c>=0?o=o.slice(0,n-1-(o.length-c))+`${$}${o.slice(c)}`:o=o.slice(0,n-1)+$}return o}static getChromeExtensionOrigin(t){let r=new URL(t);return r.protocol+"//"+r.host}static parseURL(t){let r=new URL(t);return{file:G.getURLDisplayName(r),hostname:r.hostname,origin:r.protocol==="chrome-extension:"?G.getChromeExtensionOrigin(t):r.origin}}static createOrReturnURL(t){return t instanceof URL?t:new URL(t)}static getPseudoTld(t){let r=t.split(".").slice(-2);return ke.includes(r[0])?`.${r.join(".")}`:`.${r[r.length-1]}`}static getPseudoRootDomain(t){let r=G.createOrReturnURL(t).hostname,i=G.getPseudoTld(r).split(".");return r.split(".").slice(-i.length).join(".")}static filterRelevantLines(t,r,i){if(r.length===0)return t.slice(0,i*2+1);let a=3,l=new Set;return r=r.sort((o,n)=>(o.lineNumber||0)-(n.lineNumber||0)),r.forEach(({lineNumber:o})=>{let n=o-i,c=o+i;for(;n<1;)n++,c++;l.has(n-a-1)&&(n-=a);for(let s=n;s<=c;s++){let d=s;l.add(d)}}),t.filter(o=>l.has(o.lineNumber))}static computeLogNormalScore(t,r){let i=we(t,r);return i>.9&&(i+=.05*(i-.9)),Math.floor(i*100)/100}};function Ee(e){let t=e.createFragment(),r=e.createElement("style");r.append(`
    .lh-3p-filter {
      color: var(--color-gray-600);
      float: right;
      padding: 6px var(--stackpack-padding-horizontal);
    }
    .lh-3p-filter-label, .lh-3p-filter-input {
      vertical-align: middle;
      user-select: none;
    }
    .lh-3p-filter-input:disabled + .lh-3p-ui-string {
      text-decoration: line-through;
    }
  `),t.append(r);let i=e.createElement("div","lh-3p-filter"),a=e.createElement("label","lh-3p-filter-label"),l=e.createElement("input","lh-3p-filter-input");l.setAttribute("type","checkbox"),l.setAttribute("checked","");let o=e.createElement("span","lh-3p-ui-string");o.append("Show 3rd party resources");let n=e.createElement("span","lh-3p-filter-count");return a.append(" ",l," ",o," (",n,") "),i.append(" ",a," "),t.append(i),t}function Le(e){let t=e.createFragment(),r=e.createElement("div","lh-audit"),i=e.createElement("details","lh-expandable-details"),a=e.createElement("summary"),l=e.createElement("div","lh-audit__header lh-expandable-details__summary"),o=e.createElement("span","lh-audit__score-icon"),n=e.createElement("span","lh-audit__title-and-text"),c=e.createElement("span","lh-audit__title"),s=e.createElement("span","lh-audit__display-text");n.append(" ",c," ",s," ");let d=e.createElement("div","lh-chevron-container");l.append(" ",o," ",n," ",d," "),a.append(" ",l," ");let h=e.createElement("div","lh-audit__description"),u=e.createElement("div","lh-audit__stackpacks");return i.append(" ",a," ",h," ",u," "),r.append(" ",i," "),t.append(r),t}function Ce(e){let t=e.createFragment(),r=e.createElement("div","lh-category-header"),i=e.createElement("div","lh-score__gauge");i.setAttribute("role","heading"),i.setAttribute("aria-level","2");let a=e.createElement("div","lh-category-header__description");return r.append(" ",i," ",a," "),t.append(r),t}function Se(e){let t=e.createFragment(),r=e.createElementNS("http://www.w3.org/2000/svg","svg","lh-chevron");r.setAttribute("viewBox","0 0 100 100");let i=e.createElementNS("http://www.w3.org/2000/svg","g","lh-chevron__lines"),a=e.createElementNS("http://www.w3.org/2000/svg","path","lh-chevron__line lh-chevron__line-left");a.setAttribute("d","M10 50h40");let l=e.createElementNS("http://www.w3.org/2000/svg","path","lh-chevron__line lh-chevron__line-right");return l.setAttribute("d","M90 50H50"),i.append(" ",a," ",l," "),r.append(" ",i," "),t.append(r),t}function Ae(e){let t=e.createFragment(),r=e.createElement("div","lh-audit-group"),i=e.createElement("details","lh-clump"),a=e.createElement("summary"),l=e.createElement("div","lh-audit-group__summary"),o=e.createElement("div","lh-audit-group__header"),n=e.createElement("span","lh-audit-group__title"),c=e.createElement("span","lh-audit-group__itemcount");o.append(" ",n," ",c," "," "," ");let s=e.createElement("div","lh-clump-toggle"),d=e.createElement("span","lh-clump-toggletext--show"),h=e.createElement("span","lh-clump-toggletext--hide");return s.append(" ",d," ",h," "),l.append(" ",o," ",s," "),a.append(" ",l," "),i.append(" ",a," "),r.append(" "," ",i," "),t.append(r),t}function ze(e){let t=e.createFragment(),r=e.createElement("div","lh-crc-container"),i=e.createElement("style");i.append(`
      .lh-crc .lh-tree-marker {
        width: 12px;
        height: 26px;
        display: block;
        float: left;
        background-position: top left;
      }
      .lh-crc .lh-horiz-down {
        background: url('data:image/svg+xml;utf8,<svg width="16" height="26" viewBox="0 0 16 26" xmlns="http://www.w3.org/2000/svg"><g fill="%23D8D8D8" fill-rule="evenodd"><path d="M16 12v2H-2v-2z"/><path d="M9 12v14H7V12z"/></g></svg>');
      }
      .lh-crc .lh-right {
        background: url('data:image/svg+xml;utf8,<svg width="16" height="26" viewBox="0 0 16 26" xmlns="http://www.w3.org/2000/svg"><path d="M16 12v2H0v-2z" fill="%23D8D8D8" fill-rule="evenodd"/></svg>');
      }
      .lh-crc .lh-up-right {
        background: url('data:image/svg+xml;utf8,<svg width="16" height="26" viewBox="0 0 16 26" xmlns="http://www.w3.org/2000/svg"><path d="M7 0h2v14H7zm2 12h7v2H9z" fill="%23D8D8D8" fill-rule="evenodd"/></svg>');
      }
      .lh-crc .lh-vert-right {
        background: url('data:image/svg+xml;utf8,<svg width="16" height="26" viewBox="0 0 16 26" xmlns="http://www.w3.org/2000/svg"><path d="M7 0h2v27H7zm2 12h7v2H9z" fill="%23D8D8D8" fill-rule="evenodd"/></svg>');
      }
      .lh-crc .lh-vert {
        background: url('data:image/svg+xml;utf8,<svg width="16" height="26" viewBox="0 0 16 26" xmlns="http://www.w3.org/2000/svg"><path d="M7 0h2v26H7z" fill="%23D8D8D8" fill-rule="evenodd"/></svg>');
      }
      .lh-crc .lh-crc-tree {
        font-size: 14px;
        width: 100%;
        overflow-x: auto;
      }
      .lh-crc .lh-crc-node {
        height: 26px;
        line-height: 26px;
        white-space: nowrap;
      }
      .lh-crc .lh-crc-node__longest {
        color: var(--color-average-secondary);
      }
      .lh-crc .lh-crc-node__tree-value {
        margin-left: 10px;
      }
      .lh-crc .lh-crc-node__tree-value div {
        display: inline;
      }
      .lh-crc .lh-crc-node__chain-duration {
        font-weight: 700;
      }
      .lh-crc .lh-crc-initial-nav {
        color: #595959;
        font-style: italic;
      }
      .lh-crc__summary-value {
        margin-bottom: 10px;
      }
    `);let a=e.createElement("div"),l=e.createElement("div","lh-crc__summary-value"),o=e.createElement("span","lh-crc__longest_duration_label"),n=e.createElement("b","lh-crc__longest_duration");l.append(" ",o," ",n," "),a.append(" ",l," ");let c=e.createElement("div","lh-crc"),s=e.createElement("div","lh-crc-initial-nav");return c.append(" ",s," "," "),r.append(" ",i," ",a," ",c," "),t.append(r),t}function Me(e){let t=e.createFragment(),r=e.createElement("div","lh-crc-node"),i=e.createElement("span","lh-crc-node__tree-marker"),a=e.createElement("span","lh-crc-node__tree-value");return r.append(" ",i," ",a," "),t.append(r),t}function Te(e){let t=e.createFragment(),r=e.createElement("div","lh-element-screenshot"),i=e.createElement("div","lh-element-screenshot__content"),a=e.createElement("div","lh-element-screenshot__image"),l=e.createElement("div","lh-element-screenshot__mask"),o=e.createElementNS("http://www.w3.org/2000/svg","svg");o.setAttribute("height","0"),o.setAttribute("width","0");let n=e.createElementNS("http://www.w3.org/2000/svg","defs"),c=e.createElementNS("http://www.w3.org/2000/svg","clipPath");c.setAttribute("clipPathUnits","objectBoundingBox"),n.append(" ",c," "," "),o.append(" ",n," "),l.append(" ",o," ");let s=e.createElement("div","lh-element-screenshot__element-marker");return a.append(" ",l," ",s," "),i.append(" ",a," "),r.append(" ",i," "),t.append(r),t}function Fe(e){let t=e.createFragment(),r=e.createElement("div","lh-exp-gauge-component"),i=e.createElement("div","lh-exp-gauge__wrapper");i.setAttribute("target","_blank");let a=e.createElement("div","lh-exp-gauge__svg-wrapper"),l=e.createElementNS("http://www.w3.org/2000/svg","svg","lh-exp-gauge"),o=e.createElementNS("http://www.w3.org/2000/svg","g","lh-exp-gauge__inner"),n=e.createElementNS("http://www.w3.org/2000/svg","circle","lh-exp-gauge__bg"),c=e.createElementNS("http://www.w3.org/2000/svg","circle","lh-exp-gauge__base lh-exp-gauge--faded"),s=e.createElementNS("http://www.w3.org/2000/svg","circle","lh-exp-gauge__arc"),d=e.createElementNS("http://www.w3.org/2000/svg","text","lh-exp-gauge__percentage");o.append(" ",n," ",c," ",s," ",d," ");let h=e.createElementNS("http://www.w3.org/2000/svg","g","lh-exp-gauge__outer"),u=e.createElementNS("http://www.w3.org/2000/svg","circle","lh-cover");h.append(" ",u," ");let f=e.createElementNS("http://www.w3.org/2000/svg","text","lh-exp-gauge__label");return f.setAttribute("text-anchor","middle"),f.setAttribute("x","0"),f.setAttribute("y","60"),l.append(" ",o," ",h," ",f," "),a.append(" ",l," "),i.append(" ",a," "),r.append(" ",i," "),t.append(r),t}function De(e){let t=e.createFragment(),r=e.createElement("style");r.append(`
    .lh-footer {
      padding: var(--footer-padding-vertical) calc(var(--default-padding) * 2);
      max-width: var(--report-content-max-width);
      margin: 0 auto;
    }
    .lh-footer .lh-generated {
      text-align: center;
    }
  `),t.append(r);let i=e.createElement("footer","lh-footer"),a=e.createElement("ul","lh-meta__items");a.append(" ");let l=e.createElement("div","lh-generated"),o=e.createElement("b");o.append("Lighthouse");let n=e.createElement("span","lh-footer__version"),c=e.createElement("a","lh-footer__version_issue");return c.setAttribute("href","https://github.com/GoogleChrome/Lighthouse/issues"),c.setAttribute("target","_blank"),c.setAttribute("rel","noopener"),c.append("File an issue"),l.append(" "," Generated by ",o," ",n," | ",c," "),i.append(" ",a," ",l," "),t.append(i),t}function Re(e){let t=e.createFragment(),r=e.createElement("a","lh-fraction__wrapper"),i=e.createElement("div","lh-fraction__content-wrapper"),a=e.createElement("div","lh-fraction__content"),l=e.createElement("div","lh-fraction__background");a.append(" ",l," "),i.append(" ",a," ");let o=e.createElement("div","lh-fraction__label");return r.append(" ",i," ",o," "),t.append(r),t}function Ne(e){let t=e.createFragment(),r=e.createElement("a","lh-gauge__wrapper"),i=e.createElement("div","lh-gauge__svg-wrapper"),a=e.createElementNS("http://www.w3.org/2000/svg","svg","lh-gauge");a.setAttribute("viewBox","0 0 120 120");let l=e.createElementNS("http://www.w3.org/2000/svg","circle","lh-gauge-base");l.setAttribute("r","56"),l.setAttribute("cx","60"),l.setAttribute("cy","60"),l.setAttribute("stroke-width","8");let o=e.createElementNS("http://www.w3.org/2000/svg","circle","lh-gauge-arc");o.setAttribute("r","56"),o.setAttribute("cx","60"),o.setAttribute("cy","60"),o.setAttribute("stroke-width","8"),a.append(" ",l," ",o," "),i.append(" ",a," ");let n=e.createElement("div","lh-gauge__percentage"),c=e.createElement("div","lh-gauge__label");return r.append(" "," ",i," ",n," "," ",c," "),t.append(r),t}function Pe(e){let t=e.createFragment(),r=e.createElement("style");r.append(`
    /* CSS Fireworks. Originally by Eddie Lin
       https://codepen.io/paulirish/pen/yEVMbP
    */
    .lh-pyro {
      display: none;
      z-index: 1;
      pointer-events: none;
    }
    .lh-score100 .lh-pyro {
      display: block;
    }
    .lh-score100 .lh-lighthouse stop:first-child {
      stop-color: hsla(200, 12%, 95%, 0);
    }
    .lh-score100 .lh-lighthouse stop:last-child {
      stop-color: hsla(65, 81%, 76%, 1);
    }

    .lh-pyro > .lh-pyro-before, .lh-pyro > .lh-pyro-after {
      position: absolute;
      width: 5px;
      height: 5px;
      border-radius: 2.5px;
      box-shadow: 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff;
      animation: 1s bang ease-out infinite backwards,  1s gravity ease-in infinite backwards,  5s position linear infinite backwards;
      animation-delay: 1s, 1s, 1s;
    }

    .lh-pyro > .lh-pyro-after {
      animation-delay: 2.25s, 2.25s, 2.25s;
      animation-duration: 1.25s, 1.25s, 6.25s;
    }

    @keyframes bang {
      to {
        opacity: 1;
        box-shadow: -70px -115.67px #47ebbc, -28px -99.67px #eb47a4, 58px -31.67px #7eeb47, 13px -141.67px #eb47c5, -19px 6.33px #7347eb, -2px -74.67px #ebd247, 24px -151.67px #eb47e0, 57px -138.67px #b4eb47, -51px -104.67px #479eeb, 62px 8.33px #ebcf47, -93px 0.33px #d547eb, -16px -118.67px #47bfeb, 53px -84.67px #47eb83, 66px -57.67px #eb47bf, -93px -65.67px #91eb47, 30px -13.67px #86eb47, -2px -59.67px #83eb47, -44px 1.33px #eb47eb, 61px -58.67px #47eb73, 5px -22.67px #47e8eb, -66px -28.67px #ebe247, 42px -123.67px #eb5547, -75px 26.33px #7beb47, 15px -52.67px #a147eb, 36px -51.67px #eb8347, -38px -12.67px #eb5547, -46px -59.67px #47eb81, 78px -114.67px #eb47ba, 15px -156.67px #eb47bf, -36px 1.33px #eb4783, -72px -86.67px #eba147, 31px -46.67px #ebe247, -68px 29.33px #47e2eb, -55px 19.33px #ebe047, -56px 27.33px #4776eb, -13px -91.67px #eb5547, -47px -138.67px #47ebc7, -18px -96.67px #eb47ac, 11px -88.67px #4783eb, -67px -28.67px #47baeb, 53px 10.33px #ba47eb, 11px 19.33px #5247eb, -5px -11.67px #eb4791, -68px -4.67px #47eba7, 95px -37.67px #eb478b, -67px -162.67px #eb5d47, -54px -120.67px #eb6847, 49px -12.67px #ebe047, 88px 8.33px #47ebda, 97px 33.33px #eb8147, 6px -71.67px #ebbc47;
      }
    }
    @keyframes gravity {
      from {
        opacity: 1;
      }
      to {
        transform: translateY(80px);
        opacity: 0;
      }
    }
    @keyframes position {
      0%, 19.9% {
        margin-top: 4%;
        margin-left: 47%;
      }
      20%, 39.9% {
        margin-top: 7%;
        margin-left: 30%;
      }
      40%, 59.9% {
        margin-top: 6%;
        margin-left: 70%;
      }
      60%, 79.9% {
        margin-top: 3%;
        margin-left: 20%;
      }
      80%, 99.9% {
        margin-top: 3%;
        margin-left: 80%;
      }
    }
  `),t.append(r);let i=e.createElement("div","lh-header-container"),a=e.createElement("div","lh-scores-wrapper-placeholder");return i.append(" ",a," "),t.append(i),t}function $e(e){let t=e.createFragment(),r=e.createElement("div","lh-metric"),i=e.createElement("div","lh-metric__innerwrap"),a=e.createElement("div","lh-metric__icon"),l=e.createElement("span","lh-metric__title"),o=e.createElement("div","lh-metric__value"),n=e.createElement("div","lh-metric__description");return i.append(" ",a," ",l," ",o," ",n," "),r.append(" ",i," "),t.append(r),t}function He(e){let t=e.createFragment(),r=e.createElement("div","lh-scorescale"),i=e.createElement("span","lh-scorescale-range lh-scorescale-range--fail");i.append("0\u201349");let a=e.createElement("span","lh-scorescale-range lh-scorescale-range--average");a.append("50\u201389");let l=e.createElement("span","lh-scorescale-range lh-scorescale-range--pass");return l.append("90\u2013100"),r.append(" ",i," ",a," ",l," "),t.append(r),t}function Ue(e){let t=e.createFragment(),r=e.createElement("style");r.append(`
    .lh-scores-container {
      display: flex;
      flex-direction: column;
      padding: var(--default-padding) 0;
      position: relative;
      width: 100%;
    }

    .lh-sticky-header {
      --gauge-circle-size: var(--gauge-circle-size-sm);
      --plugin-badge-size: 16px;
      --plugin-icon-size: 75%;
      --gauge-wrapper-width: 60px;
      --gauge-percentage-font-size: 13px;
      position: fixed;
      left: 0;
      right: 0;
      top: var(--topbar-height);
      font-weight: 500;
      display: none;
      justify-content: center;
      background-color: var(--sticky-header-background-color);
      border-bottom: 1px solid var(--color-gray-200);
      padding-top: var(--score-container-padding);
      padding-bottom: 4px;
      z-index: 2;
      pointer-events: none;
    }

    .lh-devtools .lh-sticky-header {
      /* The report within DevTools is placed in a container with overflow, which changes the placement of this header unless we change \`position\` to \`sticky.\` */
      position: sticky;
    }

    .lh-sticky-header--visible {
      display: grid;
      grid-auto-flow: column;
      pointer-events: auto;
    }

    /* Disable the gauge arc animation for the sticky header, so toggling display: none
       does not play the animation. */
    .lh-sticky-header .lh-gauge-arc {
      animation: none;
    }

    .lh-sticky-header .lh-gauge__label,
    .lh-sticky-header .lh-fraction__label {
      display: none;
    }

    .lh-highlighter {
      width: var(--gauge-wrapper-width);
      height: 1px;
      background-color: var(--highlighter-background-color);
      /* Position at bottom of first gauge in sticky header. */
      position: absolute;
      grid-column: 1;
      bottom: -1px;
      left: 0px;
      right: 0px;
    }
  `),t.append(r);let i=e.createElement("div","lh-scores-wrapper"),a=e.createElement("div","lh-scores-container"),l=e.createElement("div","lh-pyro"),o=e.createElement("div","lh-pyro-before"),n=e.createElement("div","lh-pyro-after");return l.append(" ",o," ",n," "),a.append(" ",l," "),i.append(" ",a," "),t.append(i),t}function Oe(e){let t=e.createFragment(),r=e.createElement("div","lh-snippet"),i=e.createElement("style");return i.append(`
          :root {
            --snippet-highlight-light: #fbf1f2;
            --snippet-highlight-dark: #ffd6d8;
          }

         .lh-snippet__header {
          position: relative;
          overflow: hidden;
          padding: 10px;
          border-bottom: none;
          color: var(--snippet-color);
          background-color: var(--snippet-background-color);
          border: 1px solid var(--report-border-color-secondary);
        }
        .lh-snippet__title {
          font-weight: bold;
          float: left;
        }
        .lh-snippet__node {
          float: left;
          margin-left: 4px;
        }
        .lh-snippet__toggle-expand {
          padding: 1px 7px;
          margin-top: -1px;
          margin-right: -7px;
          float: right;
          background: transparent;
          border: none;
          cursor: pointer;
          font-size: 14px;
          color: #0c50c7;
        }

        .lh-snippet__snippet {
          overflow: auto;
          border: 1px solid var(--report-border-color-secondary);
        }
        /* Container needed so that all children grow to the width of the scroll container */
        .lh-snippet__snippet-inner {
          display: inline-block;
          min-width: 100%;
        }

        .lh-snippet:not(.lh-snippet--expanded) .lh-snippet__show-if-expanded {
          display: none;
        }
        .lh-snippet.lh-snippet--expanded .lh-snippet__show-if-collapsed {
          display: none;
        }

        .lh-snippet__line {
          background: white;
          white-space: pre;
          display: flex;
        }
        .lh-snippet__line:not(.lh-snippet__line--message):first-child {
          padding-top: 4px;
        }
        .lh-snippet__line:not(.lh-snippet__line--message):last-child {
          padding-bottom: 4px;
        }
        .lh-snippet__line--content-highlighted {
          background: var(--snippet-highlight-dark);
        }
        .lh-snippet__line--message {
          background: var(--snippet-highlight-light);
        }
        .lh-snippet__line--message .lh-snippet__line-number {
          padding-top: 10px;
          padding-bottom: 10px;
        }
        .lh-snippet__line--message code {
          padding: 10px;
          padding-left: 5px;
          color: var(--color-fail);
          font-family: var(--report-font-family);
        }
        .lh-snippet__line--message code {
          white-space: normal;
        }
        .lh-snippet__line-icon {
          padding-top: 10px;
          display: none;
        }
        .lh-snippet__line--message .lh-snippet__line-icon {
          display: block;
        }
        .lh-snippet__line-icon:before {
          content: "";
          display: inline-block;
          vertical-align: middle;
          margin-right: 4px;
          width: var(--score-icon-size);
          height: var(--score-icon-size);
          background-image: var(--fail-icon-url);
        }
        .lh-snippet__line-number {
          flex-shrink: 0;
          width: 40px;
          text-align: right;
          font-family: monospace;
          padding-right: 5px;
          margin-right: 5px;
          color: var(--color-gray-600);
          user-select: none;
        }
    `),r.append(" ",i," "),t.append(r),t}function Ie(e){let t=e.createFragment(),r=e.createElement("div","lh-snippet__snippet"),i=e.createElement("div","lh-snippet__snippet-inner");return r.append(" ",i," "),t.append(r),t}function Ve(e){let t=e.createFragment(),r=e.createElement("div","lh-snippet__header"),i=e.createElement("div","lh-snippet__title"),a=e.createElement("div","lh-snippet__node"),l=e.createElement("button","lh-snippet__toggle-expand"),o=e.createElement("span","lh-snippet__btn-label-collapse lh-snippet__show-if-expanded"),n=e.createElement("span","lh-snippet__btn-label-expand lh-snippet__show-if-collapsed");return l.append(" ",o," ",n," "),r.append(" ",i," ",a," ",l," "),t.append(r),t}function Be(e){let t=e.createFragment(),r=e.createElement("div","lh-snippet__line"),i=e.createElement("div","lh-snippet__line-number"),a=e.createElement("div","lh-snippet__line-icon"),l=e.createElement("code");return r.append(" ",i," ",a," ",l," "),t.append(r),t}function Ge(e){let t=e.createFragment(),r=e.createElement("style");return r.append(`/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/*
  Naming convention:

  If a variable is used for a specific component: --{component}-{property name}-{modifier}

  Both {component} and {property name} should be kebab-case. If the target is the entire page,
  use 'report' for the component. The property name should not be abbreviated. Use the
  property name the variable is intended for - if it's used for multiple, a common descriptor
  is fine (ex: 'size' for a variable applied to 'width' and 'height'). If a variable is shared
  across multiple components, either create more variables or just drop the "{component}-"
  part of the name. Append any modifiers at the end (ex: 'big', 'dark').

  For colors: --color-{hue}-{intensity}

  {intensity} is the Material Design tag - 700, A700, etc.
*/
.lh-vars {
  /* Palette using Material Design Colors
   * https://www.materialui.co/colors */
  --color-amber-50: #FFF8E1;
  --color-blue-200: #90CAF9;
  --color-blue-900: #0D47A1;
  --color-blue-A700: #2962FF;
  --color-blue-primary: #06f;
  --color-cyan-500: #00BCD4;
  --color-gray-100: #F5F5F5;
  --color-gray-300: #CFCFCF;
  --color-gray-200: #E0E0E0;
  --color-gray-400: #BDBDBD;
  --color-gray-50: #FAFAFA;
  --color-gray-500: #9E9E9E;
  --color-gray-600: #757575;
  --color-gray-700: #616161;
  --color-gray-800: #424242;
  --color-gray-900: #212121;
  --color-gray: #000000;
  --color-green-700: #080;
  --color-green: #0c6;
  --color-lime-400: #D3E156;
  --color-orange-50: #FFF3E0;
  --color-orange-700: #C33300;
  --color-orange: #fa3;
  --color-red-700: #c00;
  --color-red: #f33;
  --color-teal-600: #00897B;
  --color-white: #FFFFFF;

  /* Context-specific colors */
  --color-average-secondary: var(--color-orange-700);
  --color-average: var(--color-orange);
  --color-fail-secondary: var(--color-red-700);
  --color-fail: var(--color-red);
  --color-hover: var(--color-gray-50);
  --color-informative: var(--color-blue-900);
  --color-pass-secondary: var(--color-green-700);
  --color-pass: var(--color-green);
  --color-not-applicable: var(--color-gray-600);

  /* Component variables */
  --audit-description-padding-left: calc(var(--score-icon-size) + var(--score-icon-margin-left) + var(--score-icon-margin-right));
  --audit-explanation-line-height: 16px;
  --audit-group-margin-bottom: calc(var(--default-padding) * 6);
  --audit-group-padding-vertical: 8px;
  --audit-margin-horizontal: 5px;
  --audit-padding-vertical: 8px;
  --category-padding: calc(var(--default-padding) * 6) var(--edge-gap-padding) calc(var(--default-padding) * 4);
  --chevron-line-stroke: var(--color-gray-600);
  --chevron-size: 12px;
  --default-padding: 8px;
  --edge-gap-padding: calc(var(--default-padding) * 4);
  --env-item-background-color: var(--color-gray-100);
  --env-item-font-size: 28px;
  --env-item-line-height: 36px;
  --env-item-padding: 10px 0px;
  --env-name-min-width: 220px;
  --footer-padding-vertical: 16px;
  --gauge-circle-size-big: 96px;
  --gauge-circle-size: 48px;
  --gauge-circle-size-sm: 32px;
  --gauge-label-font-size-big: 18px;
  --gauge-label-font-size: var(--report-font-size-secondary);
  --gauge-label-line-height-big: 24px;
  --gauge-label-line-height: var(--report-line-height-secondary);
  --gauge-percentage-font-size-big: 38px;
  --gauge-percentage-font-size: var(--report-font-size-secondary);
  --gauge-wrapper-width: 120px;
  --header-line-height: 24px;
  --highlighter-background-color: var(--report-text-color);
  --icon-square-size: calc(var(--score-icon-size) * 0.88);
  --image-preview-size: 48px;
  --link-color: var(--color-blue-primary);
  --locale-selector-background-color: var(--color-white);
  --metric-toggle-lines-fill: #7F7F7F;
  --metric-value-font-size: calc(var(--report-font-size) * 1.8);
  --metrics-toggle-background-color: var(--color-gray-200);
  --plugin-badge-background-color: var(--color-white);
  --plugin-badge-size-big: calc(var(--gauge-circle-size-big) / 2.7);
  --plugin-badge-size: calc(var(--gauge-circle-size) / 2.7);
  --plugin-icon-size: 65%;
  --report-background-color: #fff;
  --report-border-color-secondary: #ebebeb;
  --report-font-family-monospace: monospace, 'Roboto Mono', 'Menlo', 'dejavu sans mono', 'Consolas', 'Lucida Console';
  --report-font-family: system-ui, Roboto, Helvetica, Arial, sans-serif;
  --report-font-size: 14px;
  --report-font-size-secondary: 12px;
  --report-icon-size: var(--score-icon-background-size);
  --report-line-height: 24px;
  --report-line-height-secondary: 20px;
  --report-monospace-font-size: calc(var(--report-font-size) * 0.85);
  --report-text-color-secondary: var(--color-gray-800);
  --report-text-color: var(--color-gray-900);
  --report-content-max-width: calc(60 * var(--report-font-size)); /* defaults to 840px */
  --report-content-min-width: 360px;
  --report-content-max-width-minus-edge-gap: calc(var(--report-content-max-width) - var(--edge-gap-padding) * 2);
  --score-container-padding: 8px;
  --score-icon-background-size: 24px;
  --score-icon-margin-left: 6px;
  --score-icon-margin-right: 14px;
  --score-icon-margin: 0 var(--score-icon-margin-right) 0 var(--score-icon-margin-left);
  --score-icon-size: 12px;
  --score-icon-size-big: 16px;
  --screenshot-overlay-background: rgba(0, 0, 0, 0.3);
  --section-padding-vertical: calc(var(--default-padding) * 6);
  --snippet-background-color: var(--color-gray-50);
  --snippet-color: #0938C2;
  --stackpack-padding-horizontal: 10px;
  --sticky-header-background-color: var(--report-background-color);
  --sticky-header-buffer: var(--topbar-height);
  --sticky-header-height: calc(var(--gauge-circle-size-sm) + var(--score-container-padding) * 2 + 1em);
  --table-group-header-background-color: #EEF1F4;
  --table-group-header-text-color: var(--color-gray-700);
  --table-higlight-background-color: #F5F7FA;
  --tools-icon-color: var(--color-gray-600);
  --topbar-background-color: var(--color-white);
  --topbar-height: 32px;
  --topbar-logo-size: 24px;
  --topbar-padding: 0 8px;
  --toplevel-warning-background-color: hsla(30, 100%, 75%, 10%);
  --toplevel-warning-message-text-color: var(--color-average-secondary);
  --toplevel-warning-padding: 18px;
  --toplevel-warning-text-color: var(--report-text-color);

  /* SVGs */
  --plugin-icon-url-dark: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="%23FFFFFF"><path d="M0 0h24v24H0z" fill="none"/><path d="M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7 1.49 0 2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z"/></svg>');
  --plugin-icon-url: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="%23757575"><path d="M0 0h24v24H0z" fill="none"/><path d="M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7 1.49 0 2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z"/></svg>');

  --pass-icon-url: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><title>check</title><path fill="%23178239" d="M24 4C12.95 4 4 12.95 4 24c0 11.04 8.95 20 20 20 11.04 0 20-8.96 20-20 0-11.05-8.96-20-20-20zm-4 30L10 24l2.83-2.83L20 28.34l15.17-15.17L38 16 20 34z"/></svg>');
  --average-icon-url: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><title>info</title><path fill="%23E67700" d="M24 4C12.95 4 4 12.95 4 24s8.95 20 20 20 20-8.95 20-20S35.05 4 24 4zm2 30h-4V22h4v12zm0-16h-4v-4h4v4z"/></svg>');
  --fail-icon-url: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><title>warn</title><path fill="%23C7221F" d="M2 42h44L24 4 2 42zm24-6h-4v-4h4v4zm0-8h-4v-8h4v8z"/></svg>');
  --error-icon-url: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 3 15"><title>error</title><path d="M0 15H 3V 12H 0V" fill="%23FF4E42"/><path d="M0 9H 3V 0H 0V" fill="%23FF4E42"/></svg>');

  --swap-locale-icon-url: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="%23000000"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/></svg>');
  
  --baseline-high-icon-url: url("data:image/svg+xml;utf8,<svg width='18' height='10' viewBox='0 0 540 300' fill='none' xmlns='http://www.w3.org/2000/svg'> <path d='M420 30L390 60L480 150L390 240L330 180L300 210L390 300L540 150L420 30Z' fill='%23C4EED0'/> <path d='M150 0L30 120L60 150L150 60L210 120L240 90L150 0Z' fill='%23C4EED0'/> <path d='M390 0L420 30L150 300L0 150L30 120L150 240L390 0Z' fill='%231EA446'/> </svg>");
  --baseline-low-icon-url: url("data:image/svg+xml;utf8,<svg width='18' height='10' viewBox='0 0 540 300' fill='none' xmlns='http://www.w3.org/2000/svg'> <path d='M150 0L180 30L150 60L120 30L150 0Z' fill='%23A8C7FA'/> <path d='M210 60L240 90L210 120L180 90L210 60Z' fill='%23A8C7FA'/> <path d='M450 60L480 90L450 120L420 90L450 60Z' fill='%23A8C7FA'/> <path d='M510 120L540 150L510 180L480 150L510 120Z' fill='%23A8C7FA'/> <path d='M450 180L480 210L450 240L420 210L450 180Z' fill='%23A8C7FA'/> <path d='M390 240L420 270L390 300L360 270L390 240Z' fill='%23A8C7FA'/> <path d='M330 180L360 210L330 240L300 210L330 180Z' fill='%23A8C7FA'/> <path d='M90 60L120 90L90 120L60 90L90 60Z' fill='%23A8C7FA'/> <path d='M390 0L420 30L150 300L0 150L30 120L150 240L390 0Z' fill='%231B6EF3'/> </svg>");
  --baseline-limited-icon-url: url("data:image/svg+xml;utf8,<svg width='18' height='10' viewBox='0 0 540 300' fill='none' xmlns='http://www.w3.org/2000/svg'> <path d='M150 0L240 90L210 120L120 30L150 0Z' fill='%23F09409'/> <path d='M420 30L540 150L420 270L390 240L480 150L390 60L420 30Z' fill='%23C6C6C6'/> <path d='M330 180L300 210L390 300L420 270L330 180Z' fill='%23F09409'/> <path d='M120 30L150 60L60 150L150 240L120 270L0 150L120 30Z' fill='%23C6C6C6'/> <path d='M390 0L420 30L150 300L120 270L390 0Z' fill='%23F09409'/> </svg>");
}

@media not print {
  .lh-dark {
    /* Pallete */
    --color-gray-200: var(--color-gray-800);
    --color-gray-300: #616161;
    --color-gray-400: var(--color-gray-600);
    --color-gray-700: var(--color-gray-400);
    --color-gray-50: #757575;
    --color-gray-600: var(--color-gray-500);
    --color-green-700: var(--color-green);
    --color-orange-700: var(--color-orange);
    --color-red-700: var(--color-red);
    --color-teal-600: var(--color-cyan-500);

    /* Context-specific colors */
    --color-hover: rgba(0, 0, 0, 0.2);
    --color-informative: var(--color-blue-200);

    /* Component variables */
    --env-item-background-color: #393535;
    --link-color: var(--color-blue-200);
    --locale-selector-background-color: var(--color-gray-200);
    --plugin-badge-background-color: var(--color-gray-800);
    --report-background-color: var(--color-gray-900);
    --report-border-color-secondary: var(--color-gray-200);
    --report-text-color-secondary: var(--color-gray-400);
    --report-text-color: var(--color-gray-100);
    --snippet-color: var(--color-cyan-500);
    --topbar-background-color: var(--color-gray);
    --toplevel-warning-background-color: hsl(33deg 14% 18%);
    --toplevel-warning-message-text-color: var(--color-orange-700);
    --toplevel-warning-text-color: var(--color-gray-100);
    --table-group-header-background-color: rgba(186, 196, 206, 0.15);
    --table-group-header-text-color: var(--color-gray-100);
    --table-higlight-background-color: rgba(186, 196, 206, 0.09);

    /* SVGs */
    --plugin-icon-url: var(--plugin-icon-url-dark);
  }
}

/**
* This media query is a temporary fallback for browsers that do not support \`@container query\`.
* TODO: remove this media query when \`@container query\` is fully supported by browsers
* See https://github.com/GoogleChrome/lighthouse/pull/16332
*/
@media only screen and (max-width: 480px) {
  .lh-vars {
    --audit-group-margin-bottom: 20px;
    --edge-gap-padding: var(--default-padding);
    --env-name-min-width: 120px;
    --gauge-circle-size-big: 96px;
    --gauge-circle-size: 72px;
    --gauge-label-font-size-big: 22px;
    --gauge-label-font-size: 14px;
    --gauge-label-line-height-big: 26px;
    --gauge-label-line-height: 20px;
    --gauge-percentage-font-size-big: 34px;
    --gauge-percentage-font-size: 26px;
    --gauge-wrapper-width: 112px;
    --header-padding: 16px 0 16px 0;
    --image-preview-size: 24px;
    --plugin-icon-size: 75%;
    --report-font-size: 14px;
    --report-line-height: 20px;
    --score-icon-margin-left: 2px;
    --score-icon-size: 10px;
    --topbar-height: 28px;
    --topbar-logo-size: 20px;
  }
}

@container lh-container (max-width: 480px) {
  .lh-vars {
    --audit-group-margin-bottom: 20px;
    --edge-gap-padding: var(--default-padding);
    --env-name-min-width: 120px;
    --gauge-circle-size-big: 96px;
    --gauge-circle-size: 72px;
    --gauge-label-font-size-big: 22px;
    --gauge-label-font-size: 14px;
    --gauge-label-line-height-big: 26px;
    --gauge-label-line-height: 20px;
    --gauge-percentage-font-size-big: 34px;
    --gauge-percentage-font-size: 26px;
    --gauge-wrapper-width: 112px;
    --header-padding: 16px 0 16px 0;
    --image-preview-size: 24px;
    --plugin-icon-size: 75%;
    --report-font-size: 14px;
    --report-line-height: 20px;
    --score-icon-margin-left: 2px;
    --score-icon-size: 10px;
    --topbar-height: 28px;
    --topbar-logo-size: 20px;
  }
}

.lh-vars.lh-devtools {
  --audit-explanation-line-height: 14px;
  --audit-group-margin-bottom: 20px;
  --audit-group-padding-vertical: 12px;
  --audit-padding-vertical: 4px;
  --category-padding: 12px;
  --default-padding: 12px;
  --env-name-min-width: 120px;
  --footer-padding-vertical: 8px;
  --gauge-circle-size-big: 72px;
  --gauge-circle-size: 64px;
  --gauge-label-font-size-big: 22px;
  --gauge-label-font-size: 14px;
  --gauge-label-line-height-big: 26px;
  --gauge-label-line-height: 20px;
  --gauge-percentage-font-size-big: 34px;
  --gauge-percentage-font-size: 26px;
  --gauge-wrapper-width: 97px;
  --header-line-height: 20px;
  --header-padding: 16px 0 16px 0;
  --screenshot-overlay-background: transparent;
  --plugin-icon-size: 75%;
  --report-font-size: 12px;
  --report-line-height: 20px;
  --score-icon-margin-left: 2px;
  --score-icon-size: 10px;
  --section-padding-vertical: 8px;
}

.lh-devtools :focus-visible {
  outline: -webkit-focus-ring-color auto 1px;
}

.lh-container:has(.lh-sticky-header) {
  --sticky-header-buffer: calc(var(--topbar-height) + var(--sticky-header-height));
}

.lh-container:not(.lh-topbar + .lh-container) {
  --topbar-height: 0;
  --sticky-header-height: 0;
  --sticky-header-buffer: 0;
}

.lh-max-viewport {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  width: 100%;
}

.lh-devtools.lh-root {
  height: 100%;
}
.lh-devtools.lh-root img {
  /* Override devtools default 'min-width: 0' so svg without size in a flexbox isn't collapsed. */
  min-width: auto;
}
.lh-devtools .lh-container {
  overflow-y: scroll;
  height: calc(100% - var(--topbar-height));
  /** The .lh-container is the scroll parent in DevTools so we exclude the topbar from the sticky header buffer. */
  --sticky-header-buffer: 0;
}
.lh-devtools .lh-container:has(.lh-sticky-header) {
  /** The .lh-container is the scroll parent in DevTools so we exclude the topbar from the sticky header buffer. */
  --sticky-header-buffer: var(--sticky-header-height);
}
@media print {
  .lh-devtools .lh-container {
    overflow: unset;
  }
}
.lh-devtools .lh-sticky-header {
  /* This is normally the height of the topbar, but we want it to stick to the top of our scroll container .lh-container\` */
  top: 0;
}
.lh-devtools .lh-element-screenshot__overlay {
  position: absolute;
}

@keyframes fadeIn {
  0% { opacity: 0;}
  100% { opacity: 0.6;}
}

.lh-root *, .lh-root *::before, .lh-root *::after {
  box-sizing: border-box;
}

.lh-root {
  font-family: var(--report-font-family);
  font-size: var(--report-font-size);
  margin: 0;
  line-height: var(--report-line-height);
  background: var(--report-background-color);
  color: var(--report-text-color);
}

.lh-root [hidden] {
  display: none !important;
}

.lh-root pre {
  margin: 0;
}

.lh-root pre,
.lh-root code {
  font-family: var(--report-font-family-monospace);
}

.lh-root details > summary {
  cursor: pointer;
}

.lh-hidden {
  display: none !important;
}

.lh-container {
  /*
  Text wrapping in the report is so much FUN!
  We have a \`word-break: break-word;\` globally here to prevent a few common scenarios, namely
  long non-breakable text (usually URLs) found in:
    1. The footer
    2. .lh-node (outerHTML)
    3. .lh-code

  With that sorted, the next challenge is appropriate column sizing and text wrapping inside our
  .lh-details tables. Even more fun.
    * We don't want table headers ("Est Savings (ms)") to wrap or their column values, but
      we'd be happy for the URL column to wrap if the URLs are particularly long.
    * We want the narrow columns to remain narrow, providing the most column width for URL
    * We don't want the table to extend past 100% width.
    * Long URLs in the URL column can wrap. Util.getURLDisplayName maxes them out at 64 characters,
      but they do not get any overflow:ellipsis treatment.
  */
  word-break: break-word;

  container-name: lh-container;
  container-type: inline-size;
}

.lh-audit-group a,
.lh-category-header__description a,
.lh-audit__description a,
.lh-warnings a,
.lh-footer a,
.lh-table-column--link a {
  color: var(--link-color);
}

.lh-audit__description, .lh-audit__stackpack, .lh-list-section__description {
  --inner-audit-padding-right: var(--stackpack-padding-horizontal);
  padding-left: var(--audit-description-padding-left);
  padding-right: var(--inner-audit-padding-right);
  padding-top: 8px;
  padding-bottom: 8px;
}

.lh-details {
  margin-top: var(--default-padding);
  margin-bottom: var(--default-padding);
  margin-left: var(--audit-description-padding-left);
}

.lh-audit__stackpack {
  display: flex;
  align-items: center;
}

.lh-audit__stackpack__img {
  max-width: 30px;
  margin-right: var(--default-padding)
}

/* Report header */

.lh-report-icon {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  cursor: pointer;
}
.lh-report-icon[disabled] {
  opacity: 0.3;
  pointer-events: none;
}

.lh-report-icon::before {
  content: "";
  margin: 4px;
  background-repeat: no-repeat;
  width: var(--report-icon-size);
  height: var(--report-icon-size);
  opacity: 0.7;
  display: inline-block;
  vertical-align: middle;
}
.lh-report-icon:hover::before {
  opacity: 1;
}
.lh-dark .lh-report-icon::before {
  filter: invert(1);
}
.lh-report-icon--print::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/><path fill="none" d="M0 0h24v24H0z"/></svg>');
}
.lh-report-icon--copy::before {
  background-image: url('data:image/svg+xml;utf8,<svg height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M0 0h24v24H0z" fill="none"/><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>');
}
.lh-report-icon--open::before {
  background-image: url('data:image/svg+xml;utf8,<svg height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M0 0h24v24H0z" fill="none"/><path d="M19 4H5c-1.11 0-2 .9-2 2v12c0 1.1.89 2 2 2h4v-2H5V8h14v10h-4v2h4c1.1 0 2-.9 2-2V6c0-1.1-.89-2-2-2zm-7 6l-4 4h3v6h2v-6h3l-4-4z"/></svg>');
}
.lh-report-icon--download::before {
  background-image: url('data:image/svg+xml;utf8,<svg height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
}
.lh-report-icon--dark::before {
  background-image:url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 100 125"><path d="M50 23.587c-16.27 0-22.799 12.574-22.799 21.417 0 12.917 10.117 22.451 12.436 32.471h20.726c2.32-10.02 12.436-19.554 12.436-32.471 0-8.843-6.528-21.417-22.799-21.417zM39.637 87.161c0 3.001 1.18 4.181 4.181 4.181h.426l.41 1.231C45.278 94.449 46.042 95 48.019 95h3.963c1.978 0 2.74-.551 3.365-2.427l.409-1.231h.427c3.002 0 4.18-1.18 4.18-4.181V80.91H39.637v6.251zM50 18.265c1.26 0 2.072-.814 2.072-2.073v-9.12C52.072 5.813 51.26 5 50 5c-1.259 0-2.072.813-2.072 2.073v9.12c0 1.259.813 2.072 2.072 2.072zM68.313 23.727c.994.774 2.135.634 2.91-.357l5.614-7.187c.776-.992.636-2.135-.356-2.909-.992-.776-2.135-.636-2.91.357l-5.613 7.186c-.778.993-.636 2.135.355 2.91zM91.157 36.373c-.306-1.222-1.291-1.815-2.513-1.51l-8.85 2.207c-1.222.305-1.814 1.29-1.51 2.512.305 1.223 1.291 1.814 2.513 1.51l8.849-2.206c1.223-.305 1.816-1.291 1.511-2.513zM86.757 60.48l-8.331-3.709c-1.15-.512-2.225-.099-2.736 1.052-.512 1.151-.1 2.224 1.051 2.737l8.33 3.707c1.15.514 2.225.101 2.736-1.05.513-1.149.1-2.223-1.05-2.737zM28.779 23.37c.775.992 1.917 1.131 2.909.357.992-.776 1.132-1.917.357-2.91l-5.615-7.186c-.775-.992-1.917-1.132-2.909-.357s-1.131 1.917-.356 2.909l5.614 7.187zM21.715 39.583c.305-1.223-.288-2.208-1.51-2.513l-8.849-2.207c-1.222-.303-2.208.289-2.513 1.511-.303 1.222.288 2.207 1.511 2.512l8.848 2.206c1.222.304 2.208-.287 2.513-1.509zM21.575 56.771l-8.331 3.711c-1.151.511-1.563 1.586-1.05 2.735.511 1.151 1.586 1.563 2.736 1.052l8.331-3.711c1.151-.511 1.563-1.586 1.05-2.735-.512-1.15-1.585-1.562-2.736-1.052z"/></svg>');
}
.lh-report-icon--treemap::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="black"><path d="M3 5v14h19V5H3zm2 2h15v4H5V7zm0 10v-4h4v4H5zm6 0v-4h9v4h-9z"/></svg>');
}

.lh-report-icon--date::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7 11h2v2H7v-2zm14-5v14a2 2 0 01-2 2H5a2 2 0 01-2-2V6c0-1.1.9-2 2-2h1V2h2v2h8V2h2v2h1a2 2 0 012 2zM5 8h14V6H5v2zm14 12V10H5v10h14zm-4-7h2v-2h-2v2zm-4 0h2v-2h-2v2z"/></svg>');
}
.lh-report-icon--devices::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M4 6h18V4H4a2 2 0 00-2 2v11H0v3h14v-3H4V6zm19 2h-6a1 1 0 00-1 1v10c0 .6.5 1 1 1h6c.6 0 1-.5 1-1V9c0-.6-.5-1-1-1zm-1 9h-4v-7h4v7z"/></svg>');
}
.lh-report-icon--world::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm7 6h-3c-.3-1.3-.8-2.5-1.4-3.6A8 8 0 0 1 18.9 8zm-7-4a14 14 0 0 1 2 4h-4a14 14 0 0 1 2-4zM4.3 14a8.2 8.2 0 0 1 0-4h3.3a16.5 16.5 0 0 0 0 4H4.3zm.8 2h3a14 14 0 0 0 1.3 3.6A8 8 0 0 1 5.1 16zm3-8H5a8 8 0 0 1 4.3-3.6L8 8zM12 20a14 14 0 0 1-2-4h4a14 14 0 0 1-2 4zm2.3-6H9.7a14.7 14.7 0 0 1 0-4h4.6a14.6 14.6 0 0 1 0 4zm.3 5.6c.6-1.2 1-2.4 1.4-3.6h3a8 8 0 0 1-4.4 3.6zm1.8-5.6a16.5 16.5 0 0 0 0-4h3.3a8.2 8.2 0 0 1 0 4h-3.3z"/></svg>');
}
.lh-report-icon--stopwatch::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M15 1H9v2h6V1zm-4 13h2V8h-2v6zm8.1-6.6L20.5 6l-1.4-1.4L17.7 6A9 9 0 0 0 3 13a9 9 0 1 0 16-5.6zm-7 12.6a7 7 0 1 1 0-14 7 7 0 0 1 0 14z"/></svg>');
}
.lh-report-icon--networkspeed::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M15.9 5c-.2 0-.3 0-.4.2v.2L10.1 17a2 2 0 0 0-.2 1 2 2 0 0 0 4 .4l2.4-12.9c0-.3-.2-.5-.5-.5zM1 9l2 2c2.9-2.9 6.8-4 10.5-3.6l1.2-2.7C10 3.8 4.7 5.3 1 9zm20 2 2-2a15.4 15.4 0 0 0-5.6-3.6L17 8.2c1.5.7 2.9 1.6 4.1 2.8zm-4 4 2-2a9.9 9.9 0 0 0-2.7-1.9l-.5 3 1.2.9zM5 13l2 2a7.1 7.1 0 0 1 4-2l1.3-2.9C9.7 10.1 7 11 5 13z"/></svg>');
}
.lh-report-icon--samples-one::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="7" cy="14" r="3"/><path d="M7 18a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm4-2a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm5.6 17.6a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>');
}
.lh-report-icon--samples-many::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7 18a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm4-2a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm5.6 17.6a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/><circle cx="7" cy="14" r="3"/><circle cx="11" cy="6" r="3"/></svg>');
}
.lh-report-icon--chrome::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="-50 -50 562 562"><path d="M256 25.6v25.6a204 204 0 0 1 144.8 60 204 204 0 0 1 60 144.8 204 204 0 0 1-60 144.8 204 204 0 0 1-144.8 60 204 204 0 0 1-144.8-60 204 204 0 0 1-60-144.8 204 204 0 0 1 60-144.8 204 204 0 0 1 144.8-60V0a256 256 0 1 0 0 512 256 256 0 0 0 0-512v25.6z"/><path d="M256 179.2v25.6a51.3 51.3 0 0 1 0 102.4 51.3 51.3 0 0 1 0-102.4v-51.2a102.3 102.3 0 1 0-.1 204.7 102.3 102.3 0 0 0 .1-204.7v25.6z"/><path d="M256 204.8h217.6a25.6 25.6 0 0 0 0-51.2H256a25.6 25.6 0 0 0 0 51.2m44.3 76.8L191.5 470.1a25.6 25.6 0 1 0 44.4 25.6l108.8-188.5a25.6 25.6 0 1 0-44.4-25.6m-88.6 0L102.9 93.2a25.7 25.7 0 0 0-35-9.4 25.7 25.7 0 0 0-9.4 35l108.8 188.5a25.7 25.7 0 0 0 35 9.4 25.9 25.9 0 0 0 9.4-35.1"/></svg>');
}
.lh-report-icon--external::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg"><path d="M3.15 11.9a1.01 1.01 0 0 1-.743-.307 1.01 1.01 0 0 1-.306-.743v-7.7c0-.292.102-.54.306-.744a1.01 1.01 0 0 1 .744-.306H7v1.05H3.15v7.7h7.7V7h1.05v3.85c0 .291-.103.54-.307.743a1.01 1.01 0 0 1-.743.307h-7.7Zm2.494-2.8-.743-.744 5.206-5.206H8.401V2.1h3.5v3.5h-1.05V3.893L5.644 9.1Z"/></svg>');
}
.lh-report-icon--experiment::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="none"><path d="M4.50002 17C3.86136 17 3.40302 16.7187 3.12502 16.156C2.84702 15.5933 2.90936 15.069 3.31202 14.583L7.50002 9.5V4.5H6.75002C6.54202 4.5 6.36502 4.427 6.21902 4.281C6.07302 4.135 6.00002 3.958 6.00002 3.75C6.00002 3.542 6.07302 3.365 6.21902 3.219C6.36502 3.073 6.54202 3 6.75002 3H13.25C13.458 3 13.635 3.073 13.781 3.219C13.927 3.365 14 3.542 14 3.75C14 3.958 13.927 4.135 13.781 4.281C13.635 4.427 13.458 4.5 13.25 4.5H12.5V9.5L16.688 14.583C17.0767 15.069 17.132 15.5933 16.854 16.156C16.5767 16.7187 16.1254 17 15.5 17H4.50002ZM4.50002 15.5H15.5L11 10V4.5H9.00002V10L4.50002 15.5Z" fill="black"/></svg>');
}
.lh-report-icon--plugin::before {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path d="M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7 1.49 0 2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z"/></svg>');
}

/** These are still icons, but w/o the auto-color invert / opacity / etc. that come with .lh-report-icon */

.lh-report-plain-icon {
  display: flex;
  align-items: center;
}
.lh-report-plain-icon::before {
  content: "";
  background-repeat: no-repeat;
  width: var(--report-icon-size);
  height: var(--report-icon-size);
  display: inline-block;
  margin-right: 5px;
}

.lh-report-plain-icon--checklist-pass::before {
  --icon-url: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M8.938 13L13.896 8.062L12.833 7L8.938 10.875L7.167 9.125L6.104 10.188L8.938 13ZM10 18C8.90267 18 7.868 17.7917 6.896 17.375C5.924 16.9583 5.07333 16.3853 4.344 15.656C3.61467 14.9267 3.04167 14.076 2.625 13.104C2.20833 12.132 2 11.0973 2 10C2 8.88867 2.20833 7.85033 2.625 6.885C3.04167 5.92033 3.61467 5.07333 4.344 4.344C5.07333 3.61467 5.924 3.04167 6.896 2.625C7.868 2.20833 8.90267 2 10 2C11.1113 2 12.1497 2.20833 13.115 2.625C14.0797 3.04167 14.9267 3.61467 15.656 4.344C16.3853 5.07333 16.9583 5.92033 17.375 6.885C17.7917 7.85033 18 8.88867 18 10C18 11.0973 17.7917 12.132 17.375 13.104C16.9583 14.076 16.3853 14.9267 15.656 15.656C14.9267 16.3853 14.0797 16.9583 13.115 17.375C12.1497 17.7917 11.1113 18 10 18ZM10 16.5C11.8053 16.5 13.34 15.868 14.604 14.604C15.868 13.34 16.5 11.8053 16.5 10C16.5 8.19467 15.868 6.66 14.604 5.396C13.34 4.132 11.8053 3.5 10 3.5C8.19467 3.5 6.66 4.132 5.396 5.396C4.132 6.66 3.5 8.19467 3.5 10C3.5 11.8053 4.132 13.34 5.396 14.604C6.66 15.868 8.19467 16.5 10 16.5Z" fill="black"/></svg>');
  background-color: var(--color-pass);
  mask: var(--icon-url) center / contain no-repeat;
}
.lh-report-plain-icon--checklist-fail::before {
  --icon-url: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill-rule="evenodd" clip-rule="evenodd" d="M17.5 10C17.5 14.1421 14.1421 17.5 10 17.5C5.85786 17.5 2.5 14.1421 2.5 10C2.5 5.85786 5.85786 2.5 10 2.5C14.1421 2.5 17.5 5.85786 17.5 10ZM16 10C16 13.3137 13.3137 16 10 16C8.6135 16 7.33683 15.5297 6.32083 14.7399L14.7399 6.32083C15.5297 7.33683 16 8.6135 16 10ZM5.26016 13.6793L13.6793 5.26016C12.6633 4.47033 11.3866 4 10 4C6.68629 4 4 6.68629 4 10C4 11.3866 4.47033 12.6633 5.26016 13.6793Z" fill="black"/></svg>');
  background-color: var(--color-fail);
  mask: var(--icon-url) center / contain no-repeat;
}

.lh-buttons {
  display: flex;
  flex-wrap: wrap;
  margin: var(--default-padding) 0;
}
.lh-button {
  height: 32px;
  border: 1px solid var(--report-border-color-secondary);
  border-radius: 3px;
  color: var(--link-color);
  background-color: var(--report-background-color);
  margin: 5px;
}

.lh-button:first-of-type {
  margin-left: 0;
}

/* Node */
.lh-node {
  display: flow-root;
}

.lh-node__snippet {
  font-family: var(--report-font-family-monospace);
  color: var(--snippet-color);
  font-size: var(--report-monospace-font-size);
  line-height: 20px;
}

.lh-checklist {
  list-style: none;
  padding: 0;
}

.lh-checklist-item {
  margin: 10px 0 10px 0;
}

/* Baseline Status */
.lh-baseline-status {
  display: flex;
  align-items: center;
}
.lh-baseline-status::before {
  content: "";
  display: inline-block;
  width: 18px;
  height: 10px;
  margin-right: 6px;
  background-repeat: no-repeat;
  background-size: contain;
}
.lh-baseline-status--high::before {
  background-image: var(--baseline-high-icon-url);
}
.lh-baseline-status--low::before {
  background-image: var(--baseline-low-icon-url);
}
.lh-baseline-status--limited::before {
  background-image: var(--baseline-limited-icon-url);
}

/* Score */

.lh-audit__score-icon {
  width: var(--score-icon-size);
  height: var(--score-icon-size);
  margin: var(--score-icon-margin);
}

.lh-audit--pass .lh-audit__display-text {
  color: var(--color-pass-secondary);
}
.lh-audit--pass .lh-audit__score-icon,
.lh-scorescale-range--pass::before {
  border-radius: 100%;
  background: var(--color-pass);
}

.lh-audit--average .lh-audit__display-text {
  color: var(--color-average-secondary);
}
.lh-audit--average .lh-audit__score-icon,
.lh-scorescale-range--average::before {
  background: var(--color-average);
  width: var(--icon-square-size);
  height: var(--icon-square-size);
}

.lh-audit--fail .lh-audit__display-text {
  color: var(--color-fail-secondary);
}
.lh-audit--fail .lh-audit__score-icon,
.lh-audit--error .lh-audit__score-icon,
.lh-scorescale-range--fail::before {
  border-left: calc(var(--score-icon-size) / 2) solid transparent;
  border-right: calc(var(--score-icon-size) / 2) solid transparent;
  border-bottom: var(--score-icon-size) solid var(--color-fail);
}

.lh-audit--error .lh-audit__score-icon,
.lh-metric--error .lh-metric__icon {
  background-image: var(--error-icon-url);
  background-repeat: no-repeat;
  background-position: center;
  border: none;
}

.lh-gauge__wrapper--fail .lh-gauge--error {
  background-image: var(--error-icon-url);
  background-repeat: no-repeat;
  background-position: center;
  transform: scale(0.5);
  top: var(--score-container-padding);
}

.lh-audit--manual .lh-audit__display-text,
.lh-audit--notapplicable .lh-audit__display-text {
  color: var(--color-gray-600);
}
.lh-audit--manual .lh-audit__score-icon,
.lh-audit--notapplicable .lh-audit__score-icon {
  border: calc(0.2 * var(--score-icon-size)) solid var(--color-gray-400);
  border-radius: 100%;
  background: none;
}

.lh-audit--informative .lh-audit__display-text {
  color: var(--color-gray-600);
}

.lh-audit--informative .lh-audit__score-icon {
  border: calc(0.2 * var(--score-icon-size)) solid var(--color-gray-400);
  border-radius: 100%;
}

.lh-audit__description,
.lh-audit__stackpack {
  color: var(--report-text-color-secondary);
}
.lh-audit__adorn {
  border: 1px solid var(--color-gray-500);
  border-radius: 3px;
  margin: 0 3px;
  padding: 0 2px;
  line-height: 1.1;
  display: inline-block;
  font-size: 90%;
  color: var(--report-text-color-secondary);
}

.lh-category-header__description  {
  text-align: center;
  color: var(--color-gray-700);
  margin: 0px auto;
  max-width: 400px;
}


.lh-audit__display-text,
.lh-chevron-container {
  margin: 0 var(--audit-margin-horizontal);
}
.lh-chevron-container {
  margin-right: 0;
}

.lh-audit__title-and-text {
  flex: 1;
}

.lh-audit__title-and-text code {
  color: var(--snippet-color);
  font-size: var(--report-monospace-font-size);
}

/* Prepend display text with em dash separator. */
.lh-audit__display-text:not(:empty):before {
  content: '\u2014';
  margin-right: var(--audit-margin-horizontal);
}

/* Expandable Details (Audit Groups, Audits) */
.lh-audit__header {
  display: flex;
  align-items: center;
  padding: var(--default-padding);
}


.lh-metricfilter {
  display: grid;
  justify-content: end;
  align-items: center;
  grid-auto-flow: column;
  gap: 4px;
  color: var(--color-gray-700);
}

.lh-metricfilter__radio {
  /*
   * Instead of hiding, position offscreen so it's still accessible to screen readers
   * https://bugs.chromium.org/p/chromium/issues/detail?id=1439785
   */
  position: fixed;
  left: -9999px;
}
.lh-metricfilter input[type='radio']:focus-visible + label {
  outline: -webkit-focus-ring-color auto 1px;
}

.lh-metricfilter__label {
  display: inline-flex;
  padding: 0 4px;
  height: 16px;
  text-decoration: underline;
  align-items: center;
  cursor: pointer;
  font-size: 90%;
}

.lh-metricfilter__label--active {
  background: var(--color-blue-primary);
  color: var(--color-white);
  border-radius: 3px;
  text-decoration: none;
}
/* Give the 'All' choice a more muted display */
.lh-metricfilter__label--active[for="metric-All"] {
  background-color: var(--color-blue-200) !important;
  color: black !important;
}

.lh-metricfilter__text {
  margin-right: 8px;
}

/* If audits are filtered, hide the itemcount for Passed Audits\u2026 */
.lh-category--filtered .lh-audit-group .lh-audit-group__itemcount {
  display: none;
}


.lh-audit__header:hover {
  background-color: var(--color-hover);
}

/* We want to hide the browser's default arrow marker on summary elements. Admittedly, it's complicated. */
.lh-root details > summary {
  /* Blink 89+ and Firefox will hide the arrow when display is changed from (new) default of \`list-item\` to block.  https://chromestatus.com/feature/6730096436051968*/
  display: block;
}
/* Safari and Blink <=88 require using the -webkit-details-marker selector */
.lh-root details > summary::-webkit-details-marker {
  display: none;
}

/* Perf Metric */

.lh-metrics-container {
  display: grid;
  grid-auto-rows: 1fr;
  grid-template-columns: 1fr 1fr;
  grid-column-gap: var(--report-line-height);
  margin-bottom: var(--default-padding);
}

.lh-metric {
  border-top: 1px solid var(--report-border-color-secondary);
}

.lh-category:not(.lh--hoisted-meta) .lh-metric:nth-last-child(-n+2) {
  border-bottom: 1px solid var(--report-border-color-secondary);
}

.lh-metric__innerwrap {
  display: grid;
  /**
   * Icon -- Metric Name
   *      -- Metric Value
   */
  grid-template-columns: calc(var(--score-icon-size) + var(--score-icon-margin-left) + var(--score-icon-margin-right)) 1fr;
  align-items: center;
  padding: var(--default-padding);
}

.lh-metric__details {
  order: -1;
}

.lh-metric__title {
  flex: 1;
}

.lh-calclink {
  padding-left: calc(1ex / 3);
}

.lh-metric__description {
  display: none;
  grid-column-start: 2;
  grid-column-end: 4;
  color: var(--report-text-color-secondary);
}

.lh-metric__value {
  font-size: var(--metric-value-font-size);
  margin: calc(var(--default-padding) / 2) 0;
  white-space: nowrap; /* No wrapping between metric value and the icon */
  grid-column-start: 2;
}

/**
* This media query is a temporary fallback for browsers that do not support \`@container query\`.
* TODO: remove this media query when \`@container query\` is fully supported by browsers
* See https://github.com/GoogleChrome/lighthouse/pull/16332
*/
@media screen and (max-width: 535px) {
  .lh-metrics-container {
    display: block;
  }

  .lh-metric {
    border-bottom: none !important;
  }
  .lh-category:not(.lh--hoisted-meta) .lh-metric:nth-last-child(1) {
    border-bottom: 1px solid var(--report-border-color-secondary) !important;
  }

  /* Change the grid to 3 columns for narrow viewport. */
  .lh-metric__innerwrap {
  /**
   * Icon -- Metric Name -- Metric Value
   */
    grid-template-columns: calc(var(--score-icon-size) + var(--score-icon-margin-left) + var(--score-icon-margin-right)) 2fr 1fr;
  }
  .lh-metric__value {
    justify-self: end;
    grid-column-start: unset;
  }
}

@container lh-container (max-width: 535px) {
  .lh-metrics-container {
    display: block;
  }

  .lh-metric {
    border-bottom: none !important;
  }
  .lh-category:not(.lh--hoisted-meta) .lh-metric:nth-last-child(1) {
    border-bottom: 1px solid var(--report-border-color-secondary) !important;
  }

  /* Change the grid to 3 columns for narrow viewport. */
  .lh-metric__innerwrap {
  /**
   * Icon -- Metric Name -- Metric Value
   */
    grid-template-columns: calc(var(--score-icon-size) + var(--score-icon-margin-left) + var(--score-icon-margin-right)) 2fr 1fr;
  }
  .lh-metric__value {
    justify-self: end;
    grid-column-start: unset;
  }
}

/* No-JS toggle switch */
/* Keep this selector sync'd w/ \`magicSelector\` in report-ui-features-test.js */
 .lh-metrics-toggle__input:checked ~ .lh-metrics-container .lh-metric__description {
  display: block;
}

/* TODO get rid of the SVGS and clean up these some more */
.lh-metrics-toggle__input {
  opacity: 0;
  position: absolute;
  right: 0;
  top: 0px;
}

.lh-metrics-toggle__input + div > label > .lh-metrics-toggle__labeltext--hide,
.lh-metrics-toggle__input:checked + div > label > .lh-metrics-toggle__labeltext--show {
  display: none;
}
.lh-metrics-toggle__input:checked + div > label > .lh-metrics-toggle__labeltext--hide {
  display: inline;
}
.lh-metrics-toggle__input:focus + div > label {
  outline: -webkit-focus-ring-color auto 3px;
}

.lh-metrics-toggle__label {
  cursor: pointer;
  font-size: var(--report-font-size-secondary);
  line-height: var(--report-line-height-secondary);
  color: var(--color-gray-700);
}

/* Pushes the metric description toggle button to the right. */
.lh-audit-group--metrics .lh-audit-group__header {
  display: flex;
  justify-content: space-between;
}

.lh-metric__icon,
.lh-scorescale-range::before {
  content: '';
  width: var(--score-icon-size);
  height: var(--score-icon-size);
  display: inline-block;
  margin: var(--score-icon-margin);
}

.lh-metric--pass .lh-metric__value {
  color: var(--color-pass-secondary);
}
.lh-metric--pass .lh-metric__icon {
  border-radius: 100%;
  background: var(--color-pass);
}

.lh-metric--average .lh-metric__value {
  color: var(--color-average-secondary);
}
.lh-metric--average .lh-metric__icon {
  background: var(--color-average);
  width: var(--icon-square-size);
  height: var(--icon-square-size);
}

.lh-metric--fail .lh-metric__value {
  color: var(--color-fail-secondary);
}
.lh-metric--fail .lh-metric__icon {
  border-left: calc(var(--score-icon-size) / 2) solid transparent;
  border-right: calc(var(--score-icon-size) / 2) solid transparent;
  border-bottom: var(--score-icon-size) solid var(--color-fail);
}

.lh-metric--error .lh-metric__value,
.lh-metric--error .lh-metric__description {
  color: var(--color-fail-secondary);
}

/* Filmstrip */

.lh-filmstrip-container {
  /* smaller gap between metrics and filmstrip */
  margin: -8px auto 0 auto;
}

.lh-filmstrip {
  display: flex;
  justify-content: space-between;
  justify-items: center;
  margin-bottom: var(--default-padding);
  width: 100%;
}

.lh-filmstrip__frame {
  overflow: hidden;
  line-height: 0;
}

.lh-filmstrip__thumbnail {
  border: 1px solid var(--report-border-color-secondary);
  max-height: 150px;
  max-width: 120px;
}

.lh-dark .lh-perf-toggle-text {
  color: rgba(30, 164, 70, 1);
}

.lh-perf-toggle-text a {
  color: var(--link-color);
}

/* Audit */

.lh-audit {
  border-bottom: 1px solid var(--report-border-color-secondary);
}

/* Apply border-top to just the first audit. */
.lh-audit {
  border-top: 1px solid var(--report-border-color-secondary);
}
.lh-audit ~ .lh-audit {
  border-top: none;
}


.lh-audit--error .lh-audit__display-text {
  color: var(--color-fail-secondary);
}

/* Audit Group */

.lh-audit-group {
  margin-bottom: var(--audit-group-margin-bottom);
  position: relative;
}
.lh-audit-group--metrics {
  margin-bottom: calc(var(--audit-group-margin-bottom) / 2);
}

.lh-audit-group--metrics .lh-audit-group__summary {
  margin-top: 0;
  margin-bottom: 0;
}

.lh-audit-group__summary {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.lh-audit-group__header .lh-chevron {
  margin-top: calc((var(--report-line-height) - 5px) / 2);
}

.lh-audit-group__header {
  letter-spacing: 0.8px;
  padding: var(--default-padding);
  padding-left: 0;
}

.lh-audit-group__header, .lh-audit-group__summary {
  font-size: var(--report-font-size-secondary);
  line-height: var(--report-line-height-secondary);
  color: var(--color-gray-700);
}

.lh-audit-group__title {
  text-transform: uppercase;
  font-weight: 500;
}

.lh-audit-group__itemcount {
  color: var(--color-gray-600);
}

.lh-audit-group__footer {
  color: var(--color-gray-600);
  display: block;
  margin-top: var(--default-padding);
}

.lh-details,
.lh-category-header__description,
.lh-audit-group__footer {
  font-size: var(--report-font-size-secondary);
  line-height: var(--report-line-height-secondary);
}

.lh-audit-explanation {
  margin: var(--audit-padding-vertical) 0 calc(var(--audit-padding-vertical) / 2) var(--audit-margin-horizontal);
  line-height: var(--audit-explanation-line-height);
  display: inline-block;
}

.lh-audit--fail .lh-audit-explanation {
  color: var(--color-fail-secondary);
}

/* Report */
.lh-list {
  margin-right: calc(var(--default-padding) * 2);
}
.lh-list > :not(:last-child) {
  margin-bottom: calc(var(--default-padding) * 2);
  border-bottom: 1px solid #A8C7FA;
}
.lh-list-section {
  padding: calc(var(--default-padding) * 2) 0;
}
.lh-list-section__title {
  text-decoration: underline;
}

.lh-header-container {
  display: block;
  margin: 0 auto;
  position: relative;
  word-wrap: break-word;
}

.lh-header-container .lh-scores-wrapper {
  border-bottom: 1px solid var(--color-gray-200);
}


.lh-report {
  min-width: var(--report-content-min-width);
}

.lh-exception {
  font-size: large;
}

.lh-code {
  white-space: normal;
  margin-top: 0;
  font-size: var(--report-monospace-font-size);
}

.lh-warnings {
  --item-margin: calc(var(--report-line-height) / 6);
  color: var(--color-average-secondary);
  margin: var(--audit-padding-vertical) 0;
  padding: var(--default-padding)
    var(--default-padding)
    var(--default-padding)
    calc(var(--audit-description-padding-left));
  background-color: var(--toplevel-warning-background-color);
}
.lh-warnings span {
  font-weight: bold;
}

.lh-warnings--toplevel {
  --item-margin: calc(var(--header-line-height) / 4);
  color: var(--toplevel-warning-text-color);
  margin-left: auto;
  margin-right: auto;
  max-width: var(--report-content-max-width-minus-edge-gap);
  padding: var(--toplevel-warning-padding);
  border-radius: 8px;
}

.lh-warnings__msg {
  color: var(--toplevel-warning-message-text-color);
  margin: 0;
}

.lh-warnings ul {
  margin: 0;
}
.lh-warnings li {
  margin: var(--item-margin) 0;
}
.lh-warnings li:last-of-type {
  margin-bottom: 0;
}

.lh-scores-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
.lh-scores-header__solo {
  padding: 0;
  border: 0;
}

/* Gauge */

.lh-gauge__wrapper--pass {
  color: var(--color-pass-secondary);
  fill: var(--color-pass);
  stroke: var(--color-pass);
}

.lh-gauge__wrapper--average {
  color: var(--color-average-secondary);
  fill: var(--color-average);
  stroke: var(--color-average);
}

.lh-gauge__wrapper--fail {
  color: var(--color-fail-secondary);
  fill: var(--color-fail);
  stroke: var(--color-fail);
}

.lh-gauge__wrapper--not-applicable {
  color: var(--color-not-applicable);
  fill: var(--color-not-applicable);
  stroke: var(--color-not-applicable);
}

.lh-fraction__wrapper .lh-fraction__content::before {
  content: '';
  height: var(--score-icon-size);
  width: var(--score-icon-size);
  margin: var(--score-icon-margin);
  display: inline-block;
}
.lh-fraction__wrapper--pass .lh-fraction__content {
  color: var(--color-pass-secondary);
}
.lh-fraction__wrapper--pass .lh-fraction__background {
  background-color: var(--color-pass);
}
.lh-fraction__wrapper--pass .lh-fraction__content::before {
  background-color: var(--color-pass);
  border-radius: 50%;
}
.lh-fraction__wrapper--average .lh-fraction__content {
  color: var(--color-average-secondary);
}
.lh-fraction__wrapper--average .lh-fraction__background,
.lh-fraction__wrapper--average .lh-fraction__content::before {
  background-color: var(--color-average);
}
.lh-fraction__wrapper--fail .lh-fraction__content {
  color: var(--color-fail);
}
.lh-fraction__wrapper--fail .lh-fraction__background {
  background-color: var(--color-fail);
}
.lh-fraction__wrapper--fail .lh-fraction__content::before {
  border-left: calc(var(--score-icon-size) / 2) solid transparent;
  border-right: calc(var(--score-icon-size) / 2) solid transparent;
  border-bottom: var(--score-icon-size) solid var(--color-fail);
}
.lh-fraction__wrapper--null .lh-fraction__content {
  color: var(--color-gray-700);
}
.lh-fraction__wrapper--null .lh-fraction__background {
  background-color: var(--color-gray-700);
}
.lh-fraction__wrapper--null .lh-fraction__content::before {
  border-radius: 50%;
  border: calc(0.2 * var(--score-icon-size)) solid var(--color-gray-700);
}

.lh-fraction__background {
  position: absolute;
  height: 100%;
  width: 100%;
  border-radius: calc(var(--gauge-circle-size) / 2);
  opacity: 0.1;
  z-index: -1;
}

.lh-fraction__content-wrapper {
  height: var(--gauge-circle-size);
  display: flex;
  align-items: center;
}

.lh-fraction__content {
  display: flex;
  position: relative;
  align-items: center;
  justify-content: center;
  font-size: calc(0.3 * var(--gauge-circle-size));
  line-height: calc(0.4 * var(--gauge-circle-size));
  width: max-content;
  min-width: calc(1.5 * var(--gauge-circle-size));
  padding: calc(0.1 * var(--gauge-circle-size)) calc(0.2 * var(--gauge-circle-size));
  --score-icon-size: calc(0.21 * var(--gauge-circle-size));
  --score-icon-margin: 0 calc(0.15 * var(--gauge-circle-size)) 0 0;
}

.lh-gauge {
  stroke-linecap: round;
  width: var(--gauge-circle-size);
  height: var(--gauge-circle-size);
}

.lh-category .lh-gauge {
  --gauge-circle-size: var(--gauge-circle-size-big);
}

.lh-gauge-base {
  opacity: 0.1;
}

.lh-gauge-arc {
  fill: none;
  transform-origin: 50% 50%;
  animation: load-gauge var(--transition-length) ease both;
  animation-delay: 250ms;
}

.lh-gauge__svg-wrapper {
  position: relative;
  height: var(--gauge-circle-size);
}
.lh-category .lh-gauge__svg-wrapper,
.lh-category .lh-fraction__wrapper {
  --gauge-circle-size: var(--gauge-circle-size-big);
}

/* The plugin badge overlay */
.lh-gauge__wrapper--plugin .lh-gauge__svg-wrapper::before {
  width: var(--plugin-badge-size);
  height: var(--plugin-badge-size);
  background-color: var(--plugin-badge-background-color);
  background-image: var(--plugin-icon-url);
  background-repeat: no-repeat;
  background-size: var(--plugin-icon-size);
  background-position: 58% 50%;
  content: "";
  position: absolute;
  right: -6px;
  bottom: 0px;
  display: block;
  z-index: 100;
  box-shadow: 0 0 4px rgba(0,0,0,.2);
  border-radius: 25%;
}
.lh-category .lh-gauge__wrapper--plugin .lh-gauge__svg-wrapper::before {
  width: var(--plugin-badge-size-big);
  height: var(--plugin-badge-size-big);
}

@keyframes load-gauge {
  from { stroke-dasharray: 0 352; }
}

.lh-gauge__percentage {
  width: 100%;
  height: var(--gauge-circle-size);
  line-height: var(--gauge-circle-size);
  position: absolute;
  font-family: var(--report-font-family-monospace);
  font-size: calc(var(--gauge-circle-size) * 0.34 + 1.3px);
  text-align: center;
  top: var(--score-container-padding);
}

.lh-category .lh-gauge__percentage {
  --gauge-circle-size: var(--gauge-circle-size-big);
  --gauge-percentage-font-size: var(--gauge-percentage-font-size-big);
}

.lh-gauge__wrapper,
.lh-fraction__wrapper {
  position: relative;
  display: flex;
  align-items: center;
  flex-direction: column;
  text-decoration: none;
  padding: var(--score-container-padding);

  --transition-length: 1s;

  /* Contain the layout style paint & layers during animation*/
  contain: content;
  will-change: opacity; /* Only using for layer promotion */
}

.lh-gauge__label,
.lh-fraction__label {
  font-size: var(--gauge-label-font-size);
  font-weight: 500;
  line-height: var(--gauge-label-line-height);
  margin-top: 10px;
  text-align: center;
  color: var(--report-text-color);
  word-break: keep-all;
}

/* TODO(#8185) use more BEM (.lh-gauge__label--big) instead of relying on descendant selector */
.lh-category .lh-gauge__label,
.lh-category .lh-fraction__label {
  --gauge-label-font-size: var(--gauge-label-font-size-big);
  --gauge-label-line-height: var(--gauge-label-line-height-big);
  margin-top: 14px;
}

.lh-scores-header .lh-gauge__wrapper,
.lh-scores-header .lh-fraction__wrapper,
.lh-sticky-header .lh-gauge__wrapper,
.lh-sticky-header .lh-fraction__wrapper {
  width: var(--gauge-wrapper-width);
}

.lh-scorescale {
  display: inline-flex;

  gap: calc(var(--default-padding) * 4);
  margin: 16px auto 0 auto;
  font-size: var(--report-font-size-secondary);
  color: var(--color-gray-700);

}

.lh-scorescale-range {
  display: flex;
  align-items: center;
  font-family: var(--report-font-family-monospace);
  white-space: nowrap;
}

.lh-category-header__finalscreenshot .lh-scorescale {
  border: 0;
  display: flex;
  justify-content: center;
}

.lh-category-header__finalscreenshot .lh-scorescale-range {
  font-family: unset;
  font-size: 12px;
}

.lh-scorescale-wrap {
  display: contents;
}

/* Hide category score gauages if it's a single category report */
.lh-header--solo-category .lh-scores-wrapper {
  display: none;
}


.lh-categories {
  width: 100%;
}

.lh-category {
  padding: var(--category-padding);
  max-width: var(--report-content-max-width);
  margin: 0 auto;

  scroll-margin-top: calc(var(--sticky-header-buffer) - 1em);
}

.lh-category-wrapper {
  border-bottom: 1px solid var(--color-gray-200);
}
.lh-category-wrapper:last-of-type {
  border-bottom: 0;
}

.lh-category-header {
  margin-bottom: var(--section-padding-vertical);
}

.lh-category-header .lh-score__gauge {
  max-width: 400px;
  width: auto;
  margin: 0px auto;
}

.lh-category-header__finalscreenshot {
  display: grid;
  grid-template: none / 1fr 1px 1fr;
  justify-items: center;
  align-items: center;
  gap: var(--report-line-height);
  min-height: 288px;
  margin-bottom: var(--default-padding);
}

.lh-final-ss-image {
  /* constrain the size of the image to not be too large */
  max-height: calc(var(--gauge-circle-size-big) * 2.8);
  max-width: calc(var(--gauge-circle-size-big) * 3.5);
  border: 1px solid var(--color-gray-200);
  padding: 4px;
  border-radius: 3px;
  display: block;
}

.lh-category-headercol--separator {
  background: var(--color-gray-200);
  width: 1px;
  height: var(--gauge-circle-size-big);
}

/**
* This media query is a temporary fallback for browsers that do not support \`@container query\`.
* TODO: remove this media query when \`@container query\` is fully supported by browsers
* See https://github.com/GoogleChrome/lighthouse/pull/16332
*/
@media screen and (max-width: 780px) {
  .lh-category-header__finalscreenshot {
    grid-template: 1fr 1fr / none
  }
  .lh-category-headercol--separator {
    display: none;
  }
}

@container lh-container (max-width: 780px) {
  .lh-category-header__finalscreenshot {
    grid-template: 1fr 1fr / none
  }
  .lh-category-headercol--separator {
    display: none;
  }
}

/**
* This media query is a temporary fallback for browsers that do not support \`@container query\`.
* TODO: remove this media query when \`@container query\` is fully supported by browsers
* See https://github.com/GoogleChrome/lighthouse/pull/16332
*/
@media screen and (max-width: 964px) {
  .lh-report {
    margin-left: 0;
    width: 100%;
  }
}

/* 964 fits the min-width of the filmstrip */
@container lh-container (max-width: 964px) {
  .lh-report {
    margin-left: 0;
    width: 100%;
  }
}

@media print {
  body {
    -webkit-print-color-adjust: exact; /* print background colors */
  }
  .lh-container {
    display: block;
  }
  .lh-report {
    margin-left: 0;
    padding-top: 0;
  }
  .lh-categories {
    margin-top: 0;
  }
  .lh-buttons, .lh-highlighter {
    /* hide stickyheader marker when printing. crbug.com/41486992 */
    display: none;
  }
}

.lh-table {
  position: relative;
  border-collapse: separate;
  border-spacing: 0;
  /* Can't assign padding to table, so shorten the width instead. */
  width: calc(100% - var(--audit-description-padding-left) - var(--stackpack-padding-horizontal));
  border: 1px solid var(--report-border-color-secondary);
}

.lh-table thead th {
  position: sticky;
  top: var(--sticky-header-buffer);
  z-index: 1;
  background-color: var(--report-background-color);
  border-bottom: 1px solid var(--report-border-color-secondary);
  font-weight: normal;
  color: var(--color-gray-600);
  /* See text-wrapping comment on .lh-container. */
  word-break: normal;
}

.lh-row--group {
  background-color: var(--table-group-header-background-color);
}

.lh-row--group td {
  font-weight: bold;
  font-size: 1.05em;
  color: var(--table-group-header-text-color);
}

.lh-row--group td:first-child {
  display: block;
  min-width: max-content;
  font-weight: normal;
}

.lh-row--group .lh-text {
  color: inherit;
  text-decoration: none;
  display: inline-block;
}

.lh-row--group a.lh-link:hover {
  text-decoration: underline;
}

.lh-row--group .lh-audit__adorn {
  text-transform: capitalize;
  font-weight: normal;
  padding: 2px 3px 1px 3px;
}

.lh-row--group .lh-audit__adorn1p {
  color: var(--link-color);
  border-color: var(--link-color);
}

.lh-row--group .lh-report-icon--external::before {
  content: "";
  background-repeat: no-repeat;
  width: 14px;
  height: 16px;
  opacity: 0.7;
  display: inline-block;
  vertical-align: middle;
}

.lh-row--group .lh-report-icon--external {
  visibility: hidden;
}

.lh-row--group:hover .lh-report-icon--external {
  visibility: visible;
}

.lh-dark .lh-report-icon--external::before {
  filter: invert(1);
}

/** Manages indentation of two-level and three-level nested adjacent rows */

.lh-row--group ~ [data-entity]:not(.lh-row--group) td:first-child {
  padding-left: 20px;
}

.lh-row--group ~ [data-entity]:not(.lh-row--group) ~ .lh-sub-item-row td:first-child {
  margin-left: 20px;
  padding-left: 10px;
  border-left: 1px solid #A8C7FA;
  display: block;
}

.lh-row--even {
  background-color: var(--table-group-header-background-color);
}
.lh-row--hidden {
  display: none;
}

.lh-table th,
.lh-table td {
  padding: var(--default-padding);
}

.lh-table tr {
  vertical-align: middle;
}

.lh-table tr:hover {
  background-color: var(--table-higlight-background-color);
}

/* Looks unnecessary, but mostly for keeping the <th>s left-aligned */
.lh-table-column--text,
.lh-table-column--source-location,
.lh-table-column--url,
/* .lh-table-column--thumbnail, */
/* .lh-table-column--empty,*/
.lh-table-column--code,
.lh-table-column--node {
  text-align: left;
}

.lh-table-column--code {
  min-width: 100px;
}

.lh-table-column--bytes,
.lh-table-column--timespanMs,
.lh-table-column--ms,
.lh-table-column--numeric {
  text-align: right;
  word-break: normal;
}



.lh-table .lh-table-column--thumbnail {
  width: var(--image-preview-size);
}

.lh-table-column--url {
  min-width: 250px;
}

.lh-table-column--text {
  min-width: 80px;
}

/* Keep columns narrow if they follow the URL column */
/* 12% was determined to be a decent narrow width, but wide enough for column headings */
.lh-table-column--url + th.lh-table-column--bytes,
.lh-table-column--url + .lh-table-column--bytes + th.lh-table-column--bytes,
.lh-table-column--url + .lh-table-column--ms,
.lh-table-column--url + .lh-table-column--ms + th.lh-table-column--bytes,
.lh-table-column--url + .lh-table-column--bytes + th.lh-table-column--timespanMs {
  width: 12%;
}

/** Tweak styling for tables in insight audits. */
.lh-audit[id$="-insight"] .lh-table {
  border: none;
}

.lh-audit[id$="-insight"] .lh-table thead th {
  font-weight: bold;
  color: unset;
}

.lh-audit[id$="-insight"] .lh-table th,
.lh-audit[id$="-insight"] .lh-table td {
  padding: calc(var(--default-padding) / 2);
}

.lh-audit[id$="-insight"] .lh-table .lh-row--even,
.lh-audit[id$="-insight"] .lh-table tr:not(.lh-row--group):hover {
  background-color: unset;
}

.lh-text__url-host {
  display: inline;
}

.lh-text__url-host {
  margin-left: calc(var(--report-font-size) / 2);
  opacity: 0.6;
  font-size: 90%
}

.lh-thumbnail {
  object-fit: cover;
  width: var(--image-preview-size);
  height: var(--image-preview-size);
  display: block;
}

.lh-unknown pre {
  overflow: scroll;
  border: solid 1px var(--color-gray-200);
}

.lh-text__url > a {
  color: inherit;
  text-decoration: none;
}

.lh-text__url > a:hover {
  text-decoration: underline dotted #999;
}

.lh-sub-item-row {
  margin-left: 20px;
  margin-bottom: 0;
  color: var(--color-gray-700);
}

.lh-sub-item-row td {
  padding-top: 4px;
  padding-bottom: 4px;
  padding-left: 20px;
}

.lh-sub-item-row .lh-element-screenshot {
  zoom: 0.6;
}

/* Chevron
   https://codepen.io/paulirish/pen/LmzEmK
 */
.lh-chevron {
  --chevron-angle: 42deg;
  /* Edge doesn't support transform: rotate(calc(...)), so we define it here */
  --chevron-angle-right: -42deg;
  width: var(--chevron-size);
  height: var(--chevron-size);
  margin-top: calc((var(--report-line-height) - 12px) / 2);
}

.lh-chevron__lines {
  transition: transform 0.4s;
  transform: translateY(var(--report-line-height));
}
.lh-chevron__line {
 stroke: var(--chevron-line-stroke);
 stroke-width: var(--chevron-size);
 stroke-linecap: square;
 transform-origin: 50%;
 transform: rotate(var(--chevron-angle));
 transition: transform 300ms, stroke 300ms;
}

.lh-expandable-details .lh-chevron__line-right,
.lh-expandable-details[open] .lh-chevron__line-left {
 transform: rotate(var(--chevron-angle-right));
}

.lh-expandable-details[open] .lh-chevron__line-right {
  transform: rotate(var(--chevron-angle));
}


.lh-expandable-details[open]  .lh-chevron__lines {
 transform: translateY(calc(var(--chevron-size) * -1));
}

.lh-expandable-details[open] {
  animation: 300ms openDetails forwards;
  padding-bottom: var(--default-padding);
}

@keyframes openDetails {
  from {
    outline: 1px solid var(--report-background-color);
  }
  to {
   outline: 1px solid;
   box-shadow: 0 2px 4px rgba(0, 0, 0, .24);
  }
}

/**
* This media query is a temporary fallback for browsers that do not support \`@container query\`.
* TODO: remove this media query when \`@container query\` is fully supported by browsers
* See https://github.com/GoogleChrome/lighthouse/pull/16332
*/
@media screen and (max-width: 780px) {
  /* no black outline if we're not confident the entire table can be displayed within bounds */
  .lh-expandable-details[open] {
    animation: none;
  }
}

@container lh-container (max-width: 780px) {
  /* no black outline if we're not confident the entire table can be displayed within bounds */
  .lh-expandable-details[open] {
    animation: none;
  }
}

.lh-expandable-details[open] summary, details.lh-clump > summary {
  border-bottom: 1px solid var(--report-border-color-secondary);
}
details.lh-clump[open] > summary {
  border-bottom-width: 0;
}



details .lh-clump-toggletext--hide,
details[open] .lh-clump-toggletext--show { display: none; }
details[open] .lh-clump-toggletext--hide { display: block;}


/* Tooltip */
.lh-tooltip-boundary {
  position: relative;
}

.lh-tooltip {
  position: absolute;
  display: none; /* Don't retain these layers when not needed */
  opacity: 0;
  background: #ffffff;
  white-space: pre-line; /* Render newlines in the text */
  min-width: 246px;
  max-width: 275px;
  padding: 15px;
  border-radius: 5px;
  text-align: initial;
  line-height: 1.4;
}

/**
* This media query is a temporary fallback for browsers that do not support \`@container query\`.
* TODO: remove this media query when \`@container query\` is fully supported by browsers
* See https://github.com/GoogleChrome/lighthouse/pull/16332
*/
@media screen and (max-width: 535px) {
  .lh-tooltip {
    min-width: 45cqi;
    padding: 3cqi;
  }
}

/* shrink tooltips to not be cutoff on left edge of narrow container
   45vw is chosen to be ~= width of the left column of metrics
*/
@container lh-container (max-width: 535px) {
  .lh-tooltip {
    min-width: 45cqi;
    padding: 3cqi;
  }
}

.lh-tooltip-boundary:hover .lh-tooltip {
  display: block;
  animation: fadeInTooltip 250ms;
  animation-fill-mode: forwards;
  animation-delay: 850ms;
  bottom: 100%;
  z-index: 1;
  will-change: opacity;
  right: 0;
  pointer-events: none;
}

.lh-tooltip::before {
  content: "";
  border: solid transparent;
  border-bottom-color: #fff;
  border-width: 10px;
  position: absolute;
  bottom: -20px;
  right: 6px;
  transform: rotate(180deg);
  pointer-events: none;
}

@keyframes fadeInTooltip {
  0% { opacity: 0; }
  75% { opacity: 1; }
  100% { opacity: 1;  filter: drop-shadow(1px 0px 1px #aaa) drop-shadow(0px 2px 4px hsla(206, 6%, 25%, 0.15)); pointer-events: auto; }
}

/* Element screenshot */
.lh-element-screenshot {
  float: left;
  margin-right: 20px;
}
.lh-element-screenshot__content {
  overflow: hidden;
  min-width: 110px;
  display: flex;
  justify-content: center;
  background-color: var(--report-background-color);
}
.lh-element-screenshot__image {
  position: relative;
  /* Set by ElementScreenshotRenderer.installFullPageScreenshotCssVariable */
  background-image: var(--element-screenshot-url);
  outline: 2px solid #777;
  background-color: white;
  background-repeat: no-repeat;
}
.lh-element-screenshot__mask {
  position: absolute;
  background: #555;
  opacity: 0.8;
}
.lh-element-screenshot__element-marker {
  position: absolute;
  outline: 2px solid var(--color-lime-400);
}
.lh-element-screenshot__overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 2000; /* .lh-topbar is 1000 */
  background: var(--screenshot-overlay-background);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: zoom-out;
}

.lh-element-screenshot__overlay .lh-element-screenshot {
  margin-right: 0; /* clearing margin used in thumbnail case */
  outline: 1px solid var(--color-gray-700);
}

.lh-screenshot-overlay--enabled .lh-element-screenshot {
  cursor: zoom-out;
}
.lh-screenshot-overlay--enabled .lh-node .lh-element-screenshot {
  cursor: zoom-in;
}


.lh-meta__items {
  --meta-icon-size: calc(var(--report-icon-size) * 0.667);
  padding: var(--default-padding);
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  background-color: var(--env-item-background-color);
  border-radius: 3px;
  margin: 0 0 var(--default-padding) 0;
  font-size: 12px;
  column-gap: var(--default-padding);
  color: var(--color-gray-700);
}

.lh-meta__item {
  display: block;
  list-style-type: none;
  position: relative;
  padding: 0 0 0 calc(var(--meta-icon-size) + var(--default-padding) * 2);
  cursor: unset; /* disable pointer cursor from report-icon */
}

.lh-meta__item a {
  color: inherit;
}

.lh-meta__item.lh-tooltip-boundary {
  text-decoration: dotted underline var(--color-gray-500);
  cursor: help;
}

.lh-meta__item.lh-report-icon::before {
  position: absolute;
  left: var(--default-padding);
  width: var(--meta-icon-size);
  height: var(--meta-icon-size);
}

.lh-meta__item.lh-report-icon:hover::before {
  opacity: 0.7;
}

.lh-meta__item .lh-tooltip {
  color: var(--color-gray-800);
}

.lh-meta__item .lh-tooltip::before {
  right: auto; /* Set the tooltip arrow to the leftside */
  left: 6px;
}

.lh-meta__item:hover .lh-tooltip {
  right: auto;
  left: 6px;
}
/**
* This media query is a temporary fallback for browsers that do not support \`@container query\`.
* TODO: remove this media query when \`@container query\` is fully supported by browsers
* See https://github.com/GoogleChrome/lighthouse/pull/16332
*/
@media screen and (max-width: 640px) {
  .lh-meta__items {
    grid-template-columns: 1fr 1fr;
  }
}

/* Change the grid for narrow container */
@container lh-container (max-width: 640px) {
  .lh-meta__items {
    grid-template-columns: 1fr 1fr;
  }
}

/**
* This media query is a temporary fallback for browsers that do not support \`@container query\`.
* TODO: remove this media query when \`@container query\` is fully supported by browsers
* See https://github.com/GoogleChrome/lighthouse/pull/16332
*/
@media screen and (max-width: 535px) {
  .lh-meta__items {
    display: block;
  }
}

@container lh-container (max-width: 535px) {
  .lh-meta__items {
    display: block;
  }
}

/* Explodey gauge */

.lh-exp-gauge-component {
  margin-bottom: 10px;
}

.lh-exp-gauge-component circle {
  stroke: currentcolor;
  r: var(--radius);
}

.lh-exp-gauge-component text {
  font-size: calc(var(--radius) * 0.2);
}

.lh-exp-gauge-component .lh-exp-gauge {
  margin: 0 auto;
  width: 225px;
  stroke-width: var(--stroke-width);
  stroke-linecap: round;

  /* for better rendering perf */
  contain: strict;
  height: 225px;
  will-change: transform;
}
.lh-exp-gauge-component .lh-exp-gauge--faded {
  opacity: 0.1;
}
.lh-exp-gauge-component .lh-exp-gauge__wrapper {
  font-family: var(--report-font-family-monospace);
  text-align: center;
  text-decoration: none;
  transition: .3s;
}
.lh-exp-gauge-component .lh-exp-gauge__wrapper--pass {
  color: var(--color-pass);
}
.lh-exp-gauge-component .lh-exp-gauge__wrapper--average {
  color: var(--color-average);
}
.lh-exp-gauge-component .lh-exp-gauge__wrapper--fail {
  color: var(--color-fail);
}
.lh-exp-gauge-component .state--expanded {
  transition: color .3s;
}
.lh-exp-gauge-component .state--highlight {
  color: var(--color-highlight);
}
.lh-exp-gauge-component .lh-exp-gauge__svg-wrapper {
  display: flex;
  flex-direction: column-reverse;
}

.lh-exp-gauge-component .lh-exp-gauge__label {
  fill: var(--report-text-color);
  font-family: var(--report-font-family);
  font-size: 12px;
}

.lh-exp-gauge-component .lh-exp-gauge__cutout {
  opacity: .999;
  transition: opacity .3s;
}
.lh-exp-gauge-component .state--highlight .lh-exp-gauge__cutout {
  opacity: 0;
}

.lh-exp-gauge-component .lh-exp-gauge__inner {
  color: inherit;
}
.lh-exp-gauge-component .lh-exp-gauge__base {
  fill: currentcolor;
}


.lh-exp-gauge-component .lh-exp-gauge__arc {
  fill: none;
  transition: opacity .3s;
}
.lh-exp-gauge-component .lh-exp-gauge__arc--metric {
  color: var(--metric-color);
  stroke-dashoffset: var(--metric-offset);
  opacity: 0.3;
}
.lh-exp-gauge-component .lh-exp-gauge-hovertarget {
  color: currentcolor;
  opacity: 0.001;
  stroke-linecap: butt;
  stroke-width: 24;
  /* hack. move the hover target out of the center. ideally i tweak the r instead but that rquires considerably more math. */
  transform: scale(1.15);
}
.lh-exp-gauge-component .lh-exp-gauge__arc--metric.lh-exp-gauge--miniarc {
  opacity: 0;
  stroke-dasharray: 0 calc(var(--circle-meas) * var(--radius));
  transition: 0s .005s;
}
.lh-exp-gauge-component .state--expanded .lh-exp-gauge__arc--metric.lh-exp-gauge--miniarc {
  opacity: .999;
  stroke-dasharray: var(--metric-array);
  transition: 0.3s; /*  calc(.005s + var(--i)*.05s); entrace animation */
}
.lh-exp-gauge-component .state--expanded .lh-exp-gauge__inner .lh-exp-gauge__arc {
  opacity: 0;
}


.lh-exp-gauge-component .lh-exp-gauge__percentage {
  text-anchor: middle;
  dominant-baseline: middle;
  opacity: .999;
  font-size: calc(var(--radius) * 0.625);
  transition: opacity .3s ease-in;
}
.lh-exp-gauge-component .state--highlight .lh-exp-gauge__percentage {
  opacity: 0;
}

.lh-exp-gauge-component .lh-exp-gauge__wrapper--fail .lh-exp-gauge__percentage {
  fill: var(--color-fail);
}
.lh-exp-gauge-component .lh-exp-gauge__wrapper--average .lh-exp-gauge__percentage {
  fill: var(--color-average);
}
.lh-exp-gauge-component .lh-exp-gauge__wrapper--pass .lh-exp-gauge__percentage {
  fill: var(--color-pass);
}

.lh-exp-gauge-component .lh-cover {
  fill: none;
  opacity: .001;
  pointer-events: none;
}
.lh-exp-gauge-component .state--expanded .lh-cover {
  pointer-events: auto;
}

.lh-exp-gauge-component .metric {
  transform: scale(var(--scale-initial));
  opacity: 0;
  transition: transform .1s .2s ease-out,  opacity .3s ease-out;
  pointer-events: none;
}
.lh-exp-gauge-component .metric text {
  pointer-events: none;
}
.lh-exp-gauge-component .metric__value {
  fill: currentcolor;
  opacity: 0;
  transition: opacity 0.2s;
}
.lh-exp-gauge-component .state--expanded .metric {
  transform: scale(1);
  opacity: .999;
  transition: transform .3s ease-out,  opacity .3s ease-in,  stroke-width .1s ease-out;
  transition-delay: calc(var(--i)*.05s);
  pointer-events: auto;
}
.lh-exp-gauge-component .state--highlight .metric {
  opacity: .3;
}
.lh-exp-gauge-component .state--highlight .metric--highlight {
  opacity: .999;
  stroke-width: calc(1.5*var(--stroke-width));
}
.lh-exp-gauge-component .state--highlight .metric--highlight .metric__value {
  opacity: 0.999;
}


/*
 the initial first load peek
*/
.lh-exp-gauge-component .lh-exp-gauge__bg {  /* needed for the use zindex stacking w/ transparency */
  fill: var(--report-background-color);
  stroke: var(--report-background-color);
}
.lh-exp-gauge-component .state--peek .metric {
  transition-delay: 0ms;
  animation: peek var(--peek-dur) cubic-bezier(0.46, 0.03, 0.52, 0.96);
  animation-fill-mode: forwards;
}
.lh-exp-gauge-component .state--peek .lh-exp-gauge__inner .lh-exp-gauge__arc {
  opacity: 0.1;
}
/* do i need to set expanded and override this? */
.lh-exp-gauge-component .state--peek .lh-exp-gauge__arc--metric.lh-exp-gauge--miniarc {
  transition: opacity 0.3s;
}
.lh-exp-gauge-component .state--peek {
  color: unset;
}
.lh-exp-gauge-component .state--peek .metric__label {
  display: none;
}

.lh-exp-gauge-component .metric__label {
  fill: var(--report-text-color);
}

@keyframes peek {
  /* biggest it should go is 0.92. smallest is 0.8 */
  0% {
    transform: scale(0.8);
    opacity: 0.8;
  }

  50% {
    transform: scale(0.92);
    opacity: 1;
  }

  100% {
    transform: scale(0.8);
    opacity: 0.8;
  }
}

.lh-exp-gauge-component .wrapper {
  width: 620px;
}

/*# sourceURL=report-styles.css */
`),t.append(r),t}function qe(e){let t=e.createFragment(),r=e.createElement("style");r.append(`
    .lh-topbar {
      position: sticky;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      display: flex;
      align-items: center;
      height: var(--topbar-height);
      padding: var(--topbar-padding);
      font-size: var(--report-font-size-secondary);
      background-color: var(--topbar-background-color);
      border-bottom: 1px solid var(--color-gray-200);
    }

    .lh-topbar__logo {
      width: var(--topbar-logo-size);
      height: var(--topbar-logo-size);
      user-select: none;
      flex: none;
    }

    .lh-topbar__url {
      margin: var(--topbar-padding);
      text-decoration: none;
      color: var(--report-text-color);
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }

    .lh-tools {
      display: flex;
      align-items: center;
      margin-left: auto;
      will-change: transform;
      min-width: var(--report-icon-size);
    }
    .lh-tools__button {
      width: var(--report-icon-size);
      min-width: 24px;
      height: var(--report-icon-size);
      cursor: pointer;
      margin-right: 5px;
      /* This is actually a button element, but we want to style it like a transparent div. */
      display: flex;
      background: none;
      color: inherit;
      border: none;
      padding: 0;
      font: inherit;
    }
    .lh-tools__button svg {
      fill: var(--tools-icon-color);
    }
    .lh-dark .lh-tools__button svg {
      filter: invert(1);
    }
    .lh-tools__button.lh-active + .lh-tools__dropdown {
      opacity: 1;
      clip: rect(-1px, 194px, 270px, -3px);
      visibility: visible;
    }
    .lh-tools__dropdown {
      position: absolute;
      background-color: var(--report-background-color);
      border: 1px solid var(--report-border-color);
      border-radius: 3px;
      padding: calc(var(--default-padding) / 2) 0;
      cursor: pointer;
      top: 36px;
      right: 0;
      box-shadow: 1px 1px 3px #ccc;
      min-width: 125px;
      clip: rect(0, 164px, 0, 0);
      visibility: hidden;
      opacity: 0;
      transition: all 200ms cubic-bezier(0,0,0.2,1);
    }
    .lh-tools__dropdown a {
      color: currentColor;
      text-decoration: none;
      white-space: nowrap;
      padding: 0 6px;
      line-height: 2;
    }
    .lh-tools__dropdown a:hover,
    .lh-tools__dropdown a:focus {
      background-color: var(--color-gray-200);
      outline: none;
    }
    /* save-gist option hidden in report. */
    .lh-tools__dropdown a[data-action='save-gist'] {
      display: none;
    }

    .lh-locale-selector {
      width: 100%;
      color: var(--report-text-color);
      background-color: var(--locale-selector-background-color);
      padding: 2px;
    }
    .lh-tools-locale {
      display: flex;
      align-items: center;
      flex-direction: row-reverse;
    }
    .lh-tools-locale__selector-wrapper {
      transition: opacity 0.15s;
      opacity: 0;
      max-width: 200px;
    }
    .lh-button.lh-tool-locale__button {
      height: var(--topbar-height);
      color: var(--tools-icon-color);
      padding: calc(var(--default-padding) / 2);
    }
    .lh-tool-locale__button.lh-active + .lh-tools-locale__selector-wrapper {
      opacity: 1;
      clip: rect(-1px, 255px, 242px, -3px);
      visibility: visible;
      margin: 0 4px;
    }

    /**
    * This media query is a temporary fallback for browsers that do not support \`@container query\`.
    * TODO: remove this media query when \`@container query\` is fully supported by browsers
    * See https://github.com/GoogleChrome/lighthouse/pull/16332
    */
    @media screen and (max-width: 964px) {
      .lh-tools__dropdown {
        right: 0;
        left: initial;
      }
    }

    @container lh-container (max-width: 964px) {
      .lh-tools__dropdown {
        right: 0;
        left: initial;
      }
    }

    @media print {
      .lh-topbar {
        position: static;
        margin-left: 0;
      }

      .lh-tools__dropdown {
        display: none;
      }
    }
  `),t.append(r);let i=e.createElement("div","lh-topbar"),a=e.createElementNS("http://www.w3.org/2000/svg","svg","lh-topbar__logo");a.setAttribute("role","img"),a.setAttribute("title","Lighthouse logo"),a.setAttribute("fill","none"),a.setAttribute("xmlns","http://www.w3.org/2000/svg"),a.setAttribute("viewBox","0 0 48 48");let l=e.createElementNS("http://www.w3.org/2000/svg","path");l.setAttribute("d","m14 7 10-7 10 7v10h5v7h-5l5 24H9l5-24H9v-7h5V7Z"),l.setAttribute("fill","#F63");let o=e.createElementNS("http://www.w3.org/2000/svg","path");o.setAttribute("d","M31.561 24H14l-1.689 8.105L31.561 24ZM18.983 48H9l1.022-4.907L35.723 32.27l1.663 7.98L18.983 48Z"),o.setAttribute("fill","#FFA385");let n=e.createElementNS("http://www.w3.org/2000/svg","path");n.setAttribute("fill","#FF3"),n.setAttribute("d","M20.5 10h7v7h-7z"),a.append(" ",l," ",o," ",n," ");let c=e.createElement("a","lh-topbar__url");c.setAttribute("href",""),c.setAttribute("target","_blank"),c.setAttribute("rel","noopener");let s=e.createElement("div","lh-tools"),d=e.createElement("div","lh-tools-locale lh-hidden"),h=e.createElement("button","lh-button lh-tool-locale__button");h.setAttribute("id","lh-button__swap-locales"),h.setAttribute("title","Show Language Picker"),h.setAttribute("aria-label","Toggle language picker"),h.setAttribute("aria-haspopup","menu"),h.setAttribute("aria-expanded","false"),h.setAttribute("aria-controls","lh-tools-locale__selector-wrapper");let u=e.createElementNS("http://www.w3.org/2000/svg","svg");u.setAttribute("width","20px"),u.setAttribute("height","20px"),u.setAttribute("viewBox","0 0 24 24"),u.setAttribute("fill","currentColor");let f=e.createElementNS("http://www.w3.org/2000/svg","path");f.setAttribute("d","M0 0h24v24H0V0z"),f.setAttribute("fill","none");let m=e.createElementNS("http://www.w3.org/2000/svg","path");m.setAttribute("d","M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"),u.append(f,m),h.append(" ",u," ");let p=e.createElement("div","lh-tools-locale__selector-wrapper");p.setAttribute("id","lh-tools-locale__selector-wrapper"),p.setAttribute("role","menu"),p.setAttribute("aria-labelledby","lh-button__swap-locales"),p.setAttribute("aria-hidden","true"),p.append(" "," "),d.append(" ",h," ",p," ");let g=e.createElement("button","lh-tools__button");g.setAttribute("id","lh-tools-button"),g.setAttribute("title","Tools menu"),g.setAttribute("aria-label","Toggle report tools menu"),g.setAttribute("aria-haspopup","menu"),g.setAttribute("aria-expanded","false"),g.setAttribute("aria-controls","lh-tools-dropdown");let b=e.createElementNS("http://www.w3.org/2000/svg","svg");b.setAttribute("width","100%"),b.setAttribute("height","100%"),b.setAttribute("viewBox","0 0 24 24");let w=e.createElementNS("http://www.w3.org/2000/svg","path");w.setAttribute("d","M0 0h24v24H0z"),w.setAttribute("fill","none");let y=e.createElementNS("http://www.w3.org/2000/svg","path");y.setAttribute("d","M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"),b.append(" ",w," ",y," "),g.append(" ",b," ");let S=e.createElement("div","lh-tools__dropdown");S.setAttribute("id","lh-tools-dropdown"),S.setAttribute("role","menu"),S.setAttribute("aria-labelledby","lh-tools-button");let k=e.createElement("a","lh-report-icon lh-report-icon--print");k.setAttribute("role","menuitem"),k.setAttribute("tabindex","-1"),k.setAttribute("href","#"),k.setAttribute("data-i18n","dropdownPrintSummary"),k.setAttribute("data-action","print-summary");let F=e.createElement("a","lh-report-icon lh-report-icon--print");F.setAttribute("role","menuitem"),F.setAttribute("tabindex","-1"),F.setAttribute("href","#"),F.setAttribute("data-i18n","dropdownPrintExpanded"),F.setAttribute("data-action","print-expanded");let U=e.createElement("a","lh-report-icon lh-report-icon--copy");U.setAttribute("role","menuitem"),U.setAttribute("tabindex","-1"),U.setAttribute("href","#"),U.setAttribute("data-i18n","dropdownCopyJSON"),U.setAttribute("data-action","copy");let D=e.createElement("a","lh-report-icon lh-report-icon--download lh-hidden");D.setAttribute("role","menuitem"),D.setAttribute("tabindex","-1"),D.setAttribute("href","#"),D.setAttribute("data-i18n","dropdownSaveHTML"),D.setAttribute("data-action","save-html");let R=e.createElement("a","lh-report-icon lh-report-icon--download");R.setAttribute("role","menuitem"),R.setAttribute("tabindex","-1"),R.setAttribute("href","#"),R.setAttribute("data-i18n","dropdownSaveJSON"),R.setAttribute("data-action","save-json");let T=e.createElement("a","lh-report-icon lh-report-icon--open");T.setAttribute("role","menuitem"),T.setAttribute("tabindex","-1"),T.setAttribute("href","#"),T.setAttribute("data-i18n","dropdownViewer"),T.setAttribute("data-action","open-viewer");let N=e.createElement("a","lh-report-icon lh-report-icon--open");N.setAttribute("role","menuitem"),N.setAttribute("tabindex","-1"),N.setAttribute("href","#"),N.setAttribute("data-i18n","dropdownSaveGist"),N.setAttribute("data-action","save-gist");let O=e.createElement("a","lh-report-icon lh-report-icon--open lh-hidden");O.setAttribute("role","menuitem"),O.setAttribute("tabindex","-1"),O.setAttribute("href","#"),O.setAttribute("data-i18n","dropdownViewUnthrottledTrace"),O.setAttribute("data-action","view-unthrottled-trace");let _=e.createElement("a","lh-report-icon lh-report-icon--dark");return _.setAttribute("role","menuitem"),_.setAttribute("tabindex","-1"),_.setAttribute("href","#"),_.setAttribute("data-i18n","dropdownDarkTheme"),_.setAttribute("data-action","toggle-dark"),S.append(" ",k," ",F," ",U," "," ",D," ",R," ",T," ",N," "," ",O," ",_," "),s.append(" ",d," ",g," ",S," "),i.append(" "," ",a," ",c," ",s," "),t.append(i),t}function je(e){let t=e.createFragment(),r=e.createElement("div","lh-warnings lh-warnings--toplevel"),i=e.createElement("p","lh-warnings__msg"),a=e.createElement("ul");return r.append(" ",i," ",a," "),t.append(r),t}function We(e,t){switch(t){case"3pFilter":return Ee(e);case"audit":return Le(e);case"categoryHeader":return Ce(e);case"chevron":return Se(e);case"clump":return Ae(e);case"crc":return ze(e);case"crcChain":return Me(e);case"elementScreenshot":return Te(e);case"explodeyGauge":return Fe(e);case"footer":return De(e);case"fraction":return Re(e);case"gauge":return Ne(e);case"heading":return Pe(e);case"metric":return $e(e);case"scorescale":return He(e);case"scoresWrapper":return Ue(e);case"snippet":return Oe(e);case"snippetContent":return Ie(e);case"snippetHeader":return Ve(e);case"snippetLine":return Be(e);case"styles":return Ge(e);case"topbar":return qe(e);case"warningsToplevel":return je(e)}throw new Error("unexpected component: "+t)}var Ke=class{constructor(e,t){this._document=e,this._lighthouseChannel="unknown",this._componentCache=new Map,this.rootEl=t}createElement(e,t){let r=this._document.createElement(e);if(t)for(let i of t.split(/\s+/))i&&r.classList.add(i);return r}createElementNS(e,t,r){let i=this._document.createElementNS(e,t);if(r)for(let a of r.split(/\s+/))a&&i.classList.add(a);return i}createSVGElement(e,t){return this._document.createElementNS("http://www.w3.org/2000/svg",e,t)}createFragment(){return this._document.createDocumentFragment()}createTextNode(e){return this._document.createTextNode(e)}createChildOf(e,t,r){let i=this.createElement(t,r);return e.append(i),i}createComponent(e){let t=this._componentCache.get(e);if(t){let r=t.cloneNode(!0);return this.findAll("style",r).forEach(i=>i.remove()),r}return t=We(this,e),this._componentCache.set(e,t),t.cloneNode(!0)}clearComponentCache(){this._componentCache.clear()}convertMarkdownLinkSnippets(e,t={}){let r=this.createElement("span");for(let i of C.splitMarkdownLink(e)){let a=i.text.includes("`")?this.convertMarkdownCodeSnippets(i.text):i.text;if(!i.isLink){r.append(a);continue}let l=new URL(i.linkHref);(["https://developers.google.com","https://web.dev","https://developer.chrome.com"].includes(l.origin)||t.alwaysAppendUtmSource)&&(l.searchParams.set("utm_source","lighthouse"),l.searchParams.set("utm_medium",this._lighthouseChannel));let o=this.createElement("a");o.rel="noopener",o.target="_blank",o.append(a),this.safelySetHref(o,l.href),r.append(o)}return r}safelySetHref(e,t){if(t=t||"",t.startsWith("#")){e.href=t;return}let r=["https:","http:"],i;try{i=new URL(t)}catch{}i&&r.includes(i.protocol)?e.href=i.href:e.removeAttribute("href")}safelySetBlobHref(e,t){if(t.type!=="text/html"&&t.type!=="application/json")throw new Error("Unsupported blob type");let r=URL.createObjectURL(t);e.href=r}safelySetImageSrc(e,t){if(t=t||"",t.startsWith("data:image/")){e.src=t;return}let r=["https:","http:"],i;try{i=new URL(t)}catch{}i&&r.includes(i.protocol)?e.src=i.href:e.removeAttribute("src")}convertMarkdownCodeSnippets(e){let t=this.createElement("span");for(let r of C.splitMarkdownCodeSpans(e))if(r.isCode){let i=this.createElement("code");i.textContent=r.text,t.append(i)}else t.append(this._document.createTextNode(r.text));return t}setLighthouseChannel(e){this._lighthouseChannel=e}document(){return this._document}isDevTools(){return!!this._document.querySelector(".lh-devtools")}find(e,t=this.rootEl??this._document){let r=this.maybeFind(e,t);if(r===null)throw new Error(`query ${e} not found`);return r}maybeFind(e,t=this.rootEl??this._document){return t.querySelector(e)}findAll(e,t){return Array.from(t.querySelectorAll(e))}fireEventOn(e,t=this._document,r){let i=new CustomEvent(e,r?{detail:r}:void 0);t.dispatchEvent(i)}saveFile(e,t){let r=this.createElement("a");r.download=t,this.safelySetBlobHref(r,e),this._document.body.append(r),r.click(),this._document.body.removeChild(r),setTimeout(()=>URL.revokeObjectURL(r.href),500)}},se=0,v=class Z{static i18n=null;static strings={};static reportJson=null;static apply(t){Z.strings={...Je,...t.providedStrings},Z.i18n=t.i18n,Z.reportJson=t.reportJson}static getUniqueSuffix(){return se++}static resetUniqueSuffix(){se=0}},ce="data:image/jpeg;base64,";function Ze(e){e.configSettings.locale||(e.configSettings.locale="en"),e.configSettings.formFactor||(e.configSettings.formFactor=e.configSettings.emulatedFormFactor),e.finalDisplayedUrl=C.getFinalDisplayedUrl(e),e.mainDocumentUrl=C.getMainDocumentUrl(e);for(let i of Object.values(e.audits))if((i.scoreDisplayMode==="not_applicable"||i.scoreDisplayMode==="not-applicable")&&(i.scoreDisplayMode="notApplicable"),i.scoreDisplayMode==="informative"&&(i.score=1),i.details){if((i.details.type===void 0||i.details.type==="diagnostic")&&(i.details.type="debugdata"),i.details.type==="filmstrip")for(let a of i.details.items)a.data.startsWith(ce)||(a.data=ce+a.data);if(i.details.type==="table")for(let a of i.details.headings){let{itemType:l,text:o}=a;l!==void 0&&(a.valueType=l,delete a.itemType),o!==void 0&&(a.label=o,delete a.text);let n=a.subItemsHeading?.itemType;a.subItemsHeading&&n!==void 0&&(a.subItemsHeading.valueType=n,delete a.subItemsHeading.itemType)}if(i.id==="third-party-summary"&&(i.details.type==="opportunity"||i.details.type==="table")){let{headings:a,items:l}=i.details;if(a[0].valueType==="link"){a[0].valueType="text";for(let o of l)typeof o.entity=="object"&&o.entity.type==="link"&&(o.entity=o.entity.text);i.details.isEntityGrouped=!0}}}let[t]=e.lighthouseVersion.split(".").map(Number),r=e.categories.performance;if(r){if(t<9){e.categoryGroups||(e.categoryGroups={}),e.categoryGroups.hidden={title:""};for(let i of r.auditRefs)i.group?i.group==="load-opportunities"&&(i.group="diagnostics"):i.group="hidden"}else if(t<12)for(let i of r.auditRefs)i.group||(i.group="diagnostics")}if(t<12&&r){let i=new Map;for(let a of r.auditRefs){let l=a.relevantAudits;if(!(!l||!a.acronym))for(let o of l){let n=i.get(o)||[];n.push(a.acronym),i.set(o,n)}}for(let[a,l]of i){if(!l.length)continue;let o=e.audits[a];if(o&&!o.metricSavings){o.metricSavings={};for(let n of l)o.metricSavings[n]=0}}}if(e.environment||(e.environment={benchmarkIndex:0,networkUserAgent:e.userAgent,hostUserAgent:e.userAgent}),e.configSettings.screenEmulation||(e.configSettings.screenEmulation={width:-1,height:-1,deviceScaleFactor:-1,mobile:/mobile/i.test(e.environment.hostUserAgent),disabled:!1}),e.i18n||(e.i18n={}),e.audits["full-page-screenshot"]){let i=e.audits["full-page-screenshot"].details;i?e.fullPageScreenshot={screenshot:i.screenshot,nodes:i.nodes}:e.fullPageScreenshot=null,delete e.audits["full-page-screenshot"]}}var H=C.RATINGS,E=class J{static prepareReportResult(t){let r=JSON.parse(JSON.stringify(t));Ze(r);for(let a of Object.values(r.audits))a.details&&(a.details.type==="opportunity"||a.details.type==="table")&&!a.details.isEntityGrouped&&r.entities&&J.classifyEntities(r.entities,a.details);if(typeof r.categories!="object")throw new Error("No categories provided.");let i=new Map;for(let a of Object.values(r.categories))a.auditRefs.forEach(l=>{l.acronym&&i.set(l.acronym,l)}),a.auditRefs.forEach(l=>{let o=r.audits[l.id];l.result=o;let n=Object.keys(l.result.metricSavings||{});if(n.length){l.relevantMetrics=[];for(let c of n){let s=i.get(c);s&&l.relevantMetrics.push(s)}}if(r.stackPacks){let c=[l.id,...l.result.replacesAudits??[]];r.stackPacks.forEach(s=>{let d=c.find(h=>s.descriptions[h]);d&&s.descriptions[d]&&(l.stackPacks=l.stackPacks||[],l.stackPacks.push({title:s.title,iconDataURL:s.iconDataURL,description:s.descriptions[d]}))})}});return r}static getUrlLocatorFn(t){let r=t.find(a=>a.valueType==="url")?.key;if(r&&typeof r=="string")return a=>{let l=a[r];if(typeof l=="string")return l};let i=t.find(a=>a.valueType==="source-location")?.key;if(i)return a=>{let l=a[i];if(typeof l=="object"&&l.type==="source-location")return l.url}}static classifyEntities(t,r){let{items:i,headings:a}=r;if(!i.length||i.some(o=>o.entity))return;let l=J.getUrlLocatorFn(a);if(l)for(let o of i){let n=l(o);if(!n)continue;let c="";try{c=C.parseURL(n).origin}catch{}if(!c)continue;let s=t.find(d=>d.origins.includes(c));s&&(o.entity=s.name)}}static getTableItemSortComparator(t){return(r,i)=>{for(let a of t){let l=r[a],o=i[a];if((typeof l!=typeof o||!["number","string"].includes(typeof l))&&console.warn(`Warning: Attempting to sort unsupported value type: ${a}.`),typeof l=="number"&&typeof o=="number"&&l!==o)return o-l;if(typeof l=="string"&&typeof o=="string"&&l!==o)return l.localeCompare(o)}return 0}}static getEmulationDescriptions(t){let r,i,a,l=t.throttling,o=v.i18n,n=v.strings;switch(t.throttlingMethod){case"provided":a=i=r=n.throttlingProvided;break;case"devtools":{let{cpuSlowdownMultiplier:u,requestLatencyMs:f}=l;r=`${o.formatNumber(u)}x slowdown (DevTools)`,i=`${o.formatMilliseconds(f)} HTTP RTT, ${o.formatKbps(l.downloadThroughputKbps)} down, ${o.formatKbps(l.uploadThroughputKbps)} up (DevTools)`,a=f===150*3.75&&l.downloadThroughputKbps===1.6*1024*.9&&l.uploadThroughputKbps===750*.9?n.runtimeSlow4g:n.runtimeCustom;break}case"simulate":{let{cpuSlowdownMultiplier:u,rttMs:f,throughputKbps:m}=l;r=`${o.formatNumber(u)}x slowdown (Simulated)`,i=`${o.formatMilliseconds(f)} TCP RTT, ${o.formatKbps(m)} throughput (Simulated)`,a=f===150&&m===1.6*1024?n.runtimeSlow4g:n.runtimeCustom;break}default:a=r=i=n.runtimeUnknown}let c=t.channel==="devtools"?!1:t.screenEmulation.disabled,s=t.channel==="devtools"?t.formFactor==="mobile":t.screenEmulation.mobile,d=n.runtimeMobileEmulation;c?d=n.runtimeNoEmulation:s||(d=n.runtimeDesktopEmulation);let h=c?void 0:`${t.screenEmulation.width}x${t.screenEmulation.height}, DPR ${t.screenEmulation.deviceScaleFactor}`;return{deviceEmulation:d,screenEmulation:h,cpuThrottling:r,networkThrottling:i,summary:a}}static showAsPassed(t){switch(t.scoreDisplayMode){case"manual":case"notApplicable":return!0;case"error":case"informative":return!1;default:return Number(t.score)>=H.PASS.minScore}}static calculateRating(t,r){if(r==="manual"||r==="notApplicable")return H.PASS.label;if(r==="error")return H.ERROR.label;if(t===null)return H.FAIL.label;let i=H.FAIL.label;return t>=H.PASS.minScore?i=H.PASS.label:t>=H.AVERAGE.minScore&&(i=H.AVERAGE.label),i}static calculateCategoryFraction(t){let r=0,i=0,a=0,l=0;for(let o of t.auditRefs){let n=J.showAsPassed(o.result);if(!(o.group==="hidden"||o.result.scoreDisplayMode==="manual"||o.result.scoreDisplayMode==="notApplicable")){if(o.result.scoreDisplayMode==="informative"){n||++a;continue}++r,l+=o.weight,n&&i++}}return{numPassed:i,numPassableAudits:r,numInformative:a,totalWeight:l}}static isPluginCategory(t){return C.isPluginCategory(t)}static shouldDisplayAsFraction(t,r){return t==="timespan"||t==="snapshot"||r?.categoryScoreDisplayMode==="fraction"}},Je={varianceDisclaimer:"Values are estimated and may vary. The [performance score is calculated](https://developer.chrome.com/docs/lighthouse/performance/performance-scoring/) directly from these metrics.",calculatorLink:"See calculator.",showRelevantAudits:"Show audits relevant to:",opportunityResourceColumnLabel:"Opportunity",opportunitySavingsColumnLabel:"Estimated Savings",errorMissingAuditInfo:"Report error: no audit information",errorLabel:"Error!",warningHeader:"Warnings: ",warningAuditsGroupTitle:"Passed audits but with warnings",passedAuditsGroupTitle:"Passed audits",notApplicableAuditsGroupTitle:"Not applicable",manualAuditsGroupTitle:"Additional items to manually check",toplevelWarningsMessage:"There were issues affecting this run of Lighthouse:",crcInitialNavigation:"Initial Navigation",crcLongestDurationLabel:"Maximum critical path latency:",snippetExpandButtonLabel:"Expand snippet",snippetCollapseButtonLabel:"Collapse snippet",lsPerformanceCategoryDescription:"[Lighthouse](https://developers.google.com/web/tools/lighthouse/) analysis of the current page on an emulated mobile network. Values are estimated and may vary.",labDataTitle:"Lab Data",thirdPartyResourcesLabel:"Show 3rd-party resources",viewTreemapLabel:"View Treemap",viewTraceLabel:"View Trace",dropdownPrintSummary:"Print Summary",dropdownPrintExpanded:"Print Expanded",dropdownCopyJSON:"Copy JSON",dropdownSaveHTML:"Save as HTML",dropdownSaveJSON:"Save as JSON",dropdownViewer:"Open in Viewer",dropdownSaveGist:"Save as Gist",dropdownDarkTheme:"Toggle Dark Theme",dropdownViewUnthrottledTrace:"View Unthrottled Trace",runtimeSettingsDevice:"Device",runtimeSettingsNetworkThrottling:"Network throttling",runtimeSettingsCPUThrottling:"CPU throttling",runtimeSettingsUANetwork:"User agent (network)",runtimeSettingsBenchmark:"Unthrottled CPU/Memory Power",runtimeSettingsAxeVersion:"Axe version",runtimeSettingsArdVersion:"ARD version",runtimeSettingsScreenEmulation:"Screen emulation",footerIssue:"File an issue",runtimeNoEmulation:"No emulation",runtimeMobileEmulation:"Emulated Moto G Power",runtimeDesktopEmulation:"Emulated Desktop",runtimeUnknown:"Unknown",runtimeSingleLoad:"Single page session",runtimeAnalysisWindow:"Initial page load",runtimeAnalysisWindowTimespan:"User interactions timespan",runtimeAnalysisWindowSnapshot:"Point-in-time snapshot",runtimeSingleLoadTooltip:"This data is taken from a single page session, as opposed to field data summarizing many sessions.",throttlingProvided:"Provided by environment",show:"Show",hide:"Hide",expandView:"Expand view",collapseView:"Collapse view",runtimeSlow4g:"Slow 4G throttling",runtimeCustom:"Custom throttling",firstPartyChipLabel:"1st party",openInANewTabTooltip:"Open in a new tab",unattributable:"Unattributable",unscoredLabel:"Unscored",unscoredTitle:"This audit does not contribute to the overall category score."},pe=class{constructor(e,t){this.dom=e,this.detailsRenderer=t}get _clumpTitles(){return{warning:v.strings.warningAuditsGroupTitle,manual:v.strings.manualAuditsGroupTitle,passed:v.strings.passedAuditsGroupTitle,notApplicable:v.strings.notApplicableAuditsGroupTitle}}renderAudit(e){let t=v.strings,r=this.dom.createComponent("audit"),i=this.dom.find("div.lh-audit",r);i.id=e.result.id;let a=e.result.scoreDisplayMode;e.result.displayValue&&(this.dom.find(".lh-audit__display-text",i).textContent=e.result.displayValue);let l=this.dom.find(".lh-audit__title",i);l.append(this.dom.convertMarkdownCodeSnippets(e.result.title));let o=this.dom.find(".lh-audit__description",i);o.append(this.dom.convertMarkdownLinkSnippets(e.result.description));for(let h of e.relevantMetrics||[]){let u=this.dom.createChildOf(o,"span","lh-audit__adorn");u.title=`Relevant to ${h.result.title}`,u.textContent=h.acronym||h.id}if(e.weight===0){let h=this.dom.createChildOf(o,"span","lh-audit__adorn");h.title=v.strings.unscoredTitle,h.textContent=v.strings.unscoredLabel}e.stackPacks&&e.stackPacks.forEach(h=>{let u=this.dom.createElement("img","lh-audit__stackpack__img");this.dom.safelySetImageSrc(u,h.iconDataURL),u.alt=h.title;let f=this.dom.convertMarkdownLinkSnippets(h.description,{alwaysAppendUtmSource:!0}),m=this.dom.createElement("div","lh-audit__stackpack");m.append(u,f),this.dom.find(".lh-audit__stackpacks",i).append(m)});let n=this.dom.find("details",i);if(e.result.details){let h=this.detailsRenderer.render(e.result.details);h&&(h.classList.add("lh-details"),n.append(h))}if(this.dom.find(".lh-chevron-container",i).append(this._createChevron()),this._setRatingClass(i,e.result.score,a),e.result.scoreDisplayMode==="error"){i.classList.add("lh-audit--error");let h=this.dom.find(".lh-audit__display-text",i);h.textContent=t.errorLabel,h.classList.add("lh-tooltip-boundary");let u=this.dom.createChildOf(h,"div","lh-tooltip lh-tooltip--error");u.textContent=e.result.errorMessage||t.errorMissingAuditInfo}else if(e.result.explanation){let h=this.dom.createChildOf(l,"div","lh-audit-explanation");h.textContent=e.result.explanation}let c=e.result.warnings;if(!c||c.length===0)return i;let s=this.dom.find("summary",n),d=this.dom.createChildOf(s,"div","lh-warnings");if(this.dom.createChildOf(d,"span").textContent=t.warningHeader,c.length===1)d.append(this.dom.createTextNode(c.join("")));else{let h=this.dom.createChildOf(d,"ul");for(let u of c){let f=this.dom.createChildOf(h,"li");f.textContent=u}}return i}injectFinalScreenshot(e,t,r){let i=t["final-screenshot"];if(!i||i.scoreDisplayMode==="error"||!i.details||i.details.type!=="screenshot")return null;let a=this.dom.createElement("img","lh-final-ss-image"),l=i.details.data;this.dom.safelySetImageSrc(a,l),a.alt=i.title;let o=this.dom.find(".lh-category .lh-category-header",e),n=this.dom.createElement("div","lh-category-headercol"),c=this.dom.createElement("div","lh-category-headercol lh-category-headercol--separator"),s=this.dom.createElement("div","lh-category-headercol");n.append(...o.childNodes),n.append(r),s.append(a),o.append(n,c,s),o.classList.add("lh-category-header__finalscreenshot")}_createChevron(){let e=this.dom.createComponent("chevron");return this.dom.find("svg.lh-chevron",e)}_setRatingClass(e,t,r){let i=E.calculateRating(t,r);return e.classList.add(`lh-audit--${r.toLowerCase()}`),r!=="informative"&&e.classList.add(`lh-audit--${i}`),e}renderCategoryHeader(e,t,r){let i=this.dom.createComponent("categoryHeader"),a=this.dom.find(".lh-score__gauge",i),l=this.renderCategoryScore(e,t,r);if(a.append(l),e.description){let o=this.dom.convertMarkdownLinkSnippets(e.description);this.dom.find(".lh-category-header__description",i).append(o)}return i}renderAuditGroup(e){let t=this.dom.createElement("div","lh-audit-group"),r=this.dom.createElement("div","lh-audit-group__header");this.dom.createChildOf(r,"span","lh-audit-group__title").textContent=e.title,t.append(r);let i=null;return e.description&&(i=this.dom.convertMarkdownLinkSnippets(e.description),i.classList.add("lh-audit-group__description","lh-audit-group__footer"),t.append(i)),[t,i]}_renderGroupedAudits(e,t){let r=new Map,i="NotAGroup";r.set(i,[]);for(let l of e){let o=l.group||i,n=r.get(o)||[];n.push(l),r.set(o,n)}let a=[];for(let[l,o]of r){if(l===i){for(let d of o)a.push(this.renderAudit(d));continue}let n=t[l],[c,s]=this.renderAuditGroup(n);for(let d of o)c.insertBefore(this.renderAudit(d),s);c.classList.add(`lh-audit-group--${l}`),a.push(c)}return a}renderUnexpandableClump(e,t){let r=this.dom.createElement("div");return this._renderGroupedAudits(e,t).forEach(i=>r.append(i)),r}renderClump(e,{auditRefsOrEls:t,description:r,openByDefault:i}){let a=this.dom.createComponent("clump"),l=this.dom.find(".lh-clump",a);i&&l.setAttribute("open","");let o=this.dom.find(".lh-audit-group__header",l),n=this._clumpTitles[e];this.dom.find(".lh-audit-group__title",o).textContent=n;let c=this.dom.find(".lh-audit-group__itemcount",l);c.textContent=`(${t.length})`;let s=t.map(h=>h instanceof HTMLElement?h:this.renderAudit(h));l.append(...s);let d=this.dom.find(".lh-audit-group",a);if(r){let h=this.dom.convertMarkdownLinkSnippets(r);h.classList.add("lh-audit-group__description","lh-audit-group__footer"),d.append(h)}return this.dom.find(".lh-clump-toggletext--show",d).textContent=v.strings.show,this.dom.find(".lh-clump-toggletext--hide",d).textContent=v.strings.hide,l.classList.add(`lh-clump--${e.toLowerCase()}`),d}renderCategoryScore(e,t,r){let i;if(r&&E.shouldDisplayAsFraction(r.gatherMode,e)?i=this.renderCategoryFraction(e):i=this.renderScoreGauge(e,t),r?.omitLabel&&this.dom.find(".lh-gauge__label,.lh-fraction__label",i).remove(),r?.onPageAnchorRendered){let a=this.dom.find("a",i);r.onPageAnchorRendered(a)}return i}renderScoreGauge(e,t){let r=this.dom.createComponent("gauge"),i=this.dom.find("a.lh-gauge__wrapper",r);E.isPluginCategory(e.id)&&i.classList.add("lh-gauge__wrapper--plugin");let a=Number(e.score),l=this.dom.find(".lh-gauge",r),o=this.dom.find("circle.lh-gauge-arc",l);o&&this._setGaugeArc(o,a);let n=Math.round(a*100),c=this.dom.find("div.lh-gauge__percentage",r);return c.textContent=n.toString(),e.score===null&&(c.classList.add("lh-gauge--error"),c.textContent="",c.title=v.strings.errorLabel),e.auditRefs.length===0||this.hasApplicableAudits(e)?i.classList.add(`lh-gauge__wrapper--${E.calculateRating(e.score)}`):(i.classList.add("lh-gauge__wrapper--not-applicable"),c.textContent="-",c.title=v.strings.notApplicableAuditsGroupTitle),this.dom.find(".lh-gauge__label",r).textContent=e.title,r}renderCategoryFraction(e){let t=this.dom.createComponent("fraction"),r=this.dom.find("a.lh-fraction__wrapper",t),{numPassed:i,numPassableAudits:a,totalWeight:l}=E.calculateCategoryFraction(e),o=i/a,n=this.dom.find(".lh-fraction__content",t),c=this.dom.createElement("span");c.textContent=`${i}/${a}`,n.append(c);let s=E.calculateRating(o);return l===0&&(s="null"),r.classList.add(`lh-fraction__wrapper--${s}`),this.dom.find(".lh-fraction__label",t).textContent=e.title,t}hasApplicableAudits(e){return e.auditRefs.some(t=>t.result.scoreDisplayMode!=="notApplicable")}_setGaugeArc(e,t){let r=2*Math.PI*Number(e.getAttribute("r")),i=Number(e.getAttribute("stroke-width")),a=.25*i/r;e.style.transform=`rotate(${-90+a*360}deg)`;let l=t*r-i/2;t===0&&(e.style.opacity="0"),t===1&&(l=r),e.style.strokeDasharray=`${Math.max(l,0)} ${r}`}_auditHasWarning(e){return!!e.result.warnings?.length}_getClumpIdForAuditRef(e){let t=e.result.scoreDisplayMode;return t==="manual"||t==="notApplicable"?t:E.showAsPassed(e.result)?this._auditHasWarning(e)?"warning":"passed":"failed"}render(e,t={},r){let i=this.dom.createElement("div","lh-category");i.id=e.id,i.append(this.renderCategoryHeader(e,t,r));let a=new Map;a.set("failed",[]),a.set("warning",[]),a.set("manual",[]),a.set("passed",[]),a.set("notApplicable",[]);for(let o of e.auditRefs){if(o.group==="hidden")continue;let n=this._getClumpIdForAuditRef(o),c=a.get(n);c.push(o),a.set(n,c)}for(let o of a.values())o.sort((n,c)=>c.weight-n.weight);let l=a.get("failed")?.length;for(let[o,n]of a){if(n.length===0)continue;if(o==="failed"){let h=this.renderUnexpandableClump(n,t);h.classList.add("lh-clump--failed"),i.append(h);continue}let c=o==="manual"?e.manualDescription:void 0,s=o==="warning"||o==="manual"&&l===0,d=this.renderClump(o,{auditRefsOrEls:n,description:c,openByDefault:s});i.append(d)}return i}},ge=class{static createSegment(e,t,r,i){let a=e[t],l=Object.keys(e),o=l.indexOf(t)===l.length-1,n=!!a.children&&Object.keys(a.children).length>0,c=Array.isArray(r)?r.slice(0):[];return typeof i<"u"&&c.push(!i),{node:a,isLastChild:o,hasChildren:n,treeMarkers:c}}static createChainNode(e,t,r){let i=e.createComponent("crcChain"),a,l,o,n,c;"request"in t.node?(l=t.node.request.transferSize,o=t.node.request.url,a=(t.node.request.endTime-t.node.request.startTime)*1e3,n=!1):(l=t.node.transferSize,o=t.node.url,a=t.node.navStartToEndTime,n=!0,c=t.node.isLongest);let s=e.find(".lh-crc-node",i);s.setAttribute("title",o),c&&s.classList.add("lh-crc-node__longest");let d=e.find(".lh-crc-node__tree-marker",i);t.treeMarkers.forEach(p=>{let g=p?"lh-tree-marker lh-vert":"lh-tree-marker";d.append(e.createElement("span",g),e.createElement("span","lh-tree-marker"))});let h=t.isLastChild?"lh-tree-marker lh-up-right":"lh-tree-marker lh-vert-right",u=t.hasChildren?"lh-tree-marker lh-horiz-down":"lh-tree-marker lh-right";d.append(e.createElement("span",h),e.createElement("span","lh-tree-marker lh-right"),e.createElement("span",u));let f=r.renderTextURL(o),m=e.find(".lh-crc-node__tree-value",i);if(m.append(f),!t.hasChildren||n){let p=e.createElement("span","lh-crc-node__chain-duration");p.textContent=" - "+v.i18n.formatMilliseconds(a)+", ";let g=e.createElement("span","lh-crc-node__chain-size");g.textContent=v.i18n.formatBytesToKiB(l,.01),m.append(p,g)}return i}static buildTree(e,t,r,i){if(r.append(K.createChainNode(e,t,i)),t.node.children)for(let a of Object.keys(t.node.children)){let l=K.createSegment(t.node.children,a,t.treeMarkers,t.isLastChild);K.buildTree(e,l,r,i)}}static render(e,t,r){let i=e.createComponent("crc"),a=e.find(".lh-crc",i);e.find(".lh-crc-initial-nav",i).textContent=v.strings.crcInitialNavigation,e.find(".lh-crc__longest_duration_label",i).textContent=v.strings.crcLongestDurationLabel,e.find(".lh-crc__longest_duration",i).textContent=v.i18n.formatMilliseconds(t.longestChain.duration);let l=t.chains;for(let o of Object.keys(l)){let n=K.createSegment(l,o);K.buildTree(e,n,a,r)}return e.find(".lh-crc-container",i)}},K=ge;function Qe(e,t){return t.left<=e.width&&0<=t.right&&t.top<=e.height&&0<=t.bottom}function de(e,t,r){return e<t?t:e>r?r:e}function Ye(e){return{x:e.left+e.width/2,y:e.top+e.height/2}}var X=class Q{static getScreenshotPositions(t,r,i){let a=Ye(t),l=de(a.x-r.width/2,0,i.width-r.width),o=de(a.y-r.height/2,0,i.height-r.height);return{screenshot:{left:l,top:o},clip:{left:t.left-l,top:t.top-o}}}static renderClipPathInScreenshot(t,r,i,a,l){let o=t.find("clipPath",r),n=`clip-${v.getUniqueSuffix()}`;o.id=n,r.style.clipPath=`url(#${n})`;let c=i.top/l.height,s=c+a.height/l.height,d=i.left/l.width,h=d+a.width/l.width,u=[`0,0             1,0            1,${c}          0,${c}`,`0,${s}     1,${s}    1,1               0,1`,`0,${c}        ${d},${c} ${d},${s} 0,${s}`,`${h},${c} 1,${c}       1,${s}       ${h},${s}`];for(let f of u){let m=t.createElementNS("http://www.w3.org/2000/svg","polygon");m.setAttribute("points",f),o.append(m)}}static installFullPageScreenshot(t,r){!r.data.startsWith("data:image/")||/['"()\\\r\n]/.test(r.data)||t.style.setProperty("--element-screenshot-url",`url('${r.data}')`)}static installOverlayFeature(t){let{dom:r,rootEl:i,overlayContainerEl:a,fullPageScreenshot:l}=t,o="lh-screenshot-overlay--enabled";i.classList.contains(o)||(i.classList.add(o),i.addEventListener("click",n=>{let c=n.target;if(!c)return;let s=c.closest(".lh-node > .lh-element-screenshot");if(!s)return;let d=r.createElement("div","lh-element-screenshot__overlay");a.append(d);let h={width:d.clientWidth*.95,height:d.clientHeight*.8},u={width:Number(s.dataset.rectWidth),height:Number(s.dataset.rectHeight),left:Number(s.dataset.rectLeft),right:Number(s.dataset.rectLeft)+Number(s.dataset.rectWidth),top:Number(s.dataset.rectTop),bottom:Number(s.dataset.rectTop)+Number(s.dataset.rectHeight)},f=Q.render(r,l.screenshot,u,h);if(!f){d.remove();return}d.append(f),d.addEventListener("click",()=>d.remove())}))}static _computeZoomFactor(t,r){let i={x:r.width/t.width,y:r.height/t.height},a=.75*Math.min(i.x,i.y);return Math.min(1,a)}static render(t,r,i,a){if(!Qe(r,i))return null;let l=t.createComponent("elementScreenshot"),o=t.find("div.lh-element-screenshot",l);o.dataset.rectWidth=i.width.toString(),o.dataset.rectHeight=i.height.toString(),o.dataset.rectLeft=i.left.toString(),o.dataset.rectTop=i.top.toString();let n=this._computeZoomFactor(i,a),c={width:a.width/n,height:a.height/n};c.width=Math.min(r.width,c.width),c.height=Math.min(r.height,c.height);let s={width:c.width*n,height:c.height*n},d=Q.getScreenshotPositions(i,c,{width:r.width,height:r.height}),h=t.find("div.lh-element-screenshot__image",o);h.style.width=s.width+"px",h.style.height=s.height+"px",h.style.backgroundPositionY=-(d.screenshot.top*n)+"px",h.style.backgroundPositionX=-(d.screenshot.left*n)+"px",h.style.backgroundSize=`${r.width*n}px ${r.height*n}px`;let u=t.find("div.lh-element-screenshot__element-marker",o);u.style.width=i.width*n+"px",u.style.height=i.height*n+"px",u.style.left=d.clip.left*n+"px",u.style.top=d.clip.top*n+"px";let f=t.find("div.lh-element-screenshot__mask",o);return f.style.width=s.width+"px",f.style.height=s.height+"px",Q.renderClipPathInScreenshot(t,f,d.clip,i,c),o}},Xe=["http://","https://","data:"],et=["bytes","numeric","ms","timespanMs"],tt=class{constructor(e,t={}){this._dom=e,this._fullPageScreenshot=t.fullPageScreenshot,this._entities=t.entities}render(e){switch(e.type){case"filmstrip":return this._renderFilmstrip(e);case"list":return this._renderList(e);case"checklist":return this._renderChecklist(e);case"table":case"opportunity":return this._renderTable(e);case"network-tree":case"criticalrequestchain":return ge.render(this._dom,e,this);case"screenshot":case"debugdata":case"treemap-data":return null;default:return this._renderUnknown(e.type,e)}}_renderBytes(e){let t=v.i18n.formatBytesToKiB(e.value,e.granularity||.1),r=this._renderText(t);return r.title=v.i18n.formatBytes(e.value),r}_renderMilliseconds(e){let t;return e.displayUnit==="duration"?t=v.i18n.formatDuration(e.value):t=v.i18n.formatMilliseconds(e.value,e.granularity||10),this._renderText(t)}renderTextURL(e){let t=e,r,i,a;try{let o=C.parseURL(t);r=o.file==="/"?o.origin:o.file,i=o.file==="/"||o.hostname===""?"":`(${o.hostname})`,a=t}catch{r=t}let l=this._dom.createElement("div","lh-text__url");if(l.append(this._createLink({text:r,url:t})),i){let o=this._renderText(i);o.classList.add("lh-text__url-host"),l.append(o)}return a&&(l.title=t,l.dataset.url=t),l}_renderLink(e){return this._createLink(e)}_createLink(e){let t=this._dom.createElement("a");if(this._dom.safelySetHref(t,e.url),!t.href){let r=this._renderText(e.text);return r.classList.add("lh-link"),r}return t.rel="noopener",t.target="_blank",t.textContent=e.text,t.classList.add("lh-link"),t}_renderText(e){let t=this._dom.createElement("div","lh-text");return t.textContent=e,t}_renderBaselineStatus(e){let t=this._dom.createElement("div","lh-baseline-status"),r=e.status;return t.classList.add(`lh-baseline-status--${r}`),t.textContent=String(e.displayString),t}_renderNumeric(e){let t=v.i18n.formatNumber(e.value,e.granularity||.1),r=this._dom.createElement("div","lh-numeric");return r.textContent=t,r}_renderThumbnail(e){let t=this._dom.createElement("img","lh-thumbnail"),r=e;return this._dom.safelySetImageSrc(t,r),t.title=r,t.alt="",t}_renderUnknown(e,t){console.error(`Unknown details type: ${e}`,t);let r=this._dom.createElement("details","lh-unknown");return this._dom.createChildOf(r,"summary").textContent=`We don't know how to render audit details of type \`${e}\`. The Lighthouse version that collected this data is likely newer than the Lighthouse version of the report renderer. Expand for the raw JSON.`,this._dom.createChildOf(r,"pre").textContent=JSON.stringify(t,null,2),r}_renderTableValue(e,t){if(e==null)return null;if(typeof e=="object")switch(e.type){case"code":return this._renderCode(e.value);case"link":return this._renderLink(e);case"node":return this.renderNode(e);case"numeric":return this._renderNumeric(e);case"text":return this._renderText(e.value);case"source-location":return this.renderSourceLocation(e);case"url":return this.renderTextURL(e.value);case"baseline-status":return this._renderBaselineStatus(e);default:return this._renderUnknown(e.type,e)}switch(t.valueType){case"bytes":{let r=Number(e);return this._renderBytes({value:r,granularity:t.granularity})}case"code":{let r=String(e);return this._renderCode(r)}case"ms":{let r={value:Number(e),granularity:t.granularity,displayUnit:t.displayUnit};return this._renderMilliseconds(r)}case"numeric":{let r=Number(e);return this._renderNumeric({value:r,granularity:t.granularity})}case"text":{let r=String(e);return this._renderText(r)}case"thumbnail":{let r=String(e);return this._renderThumbnail(r)}case"timespanMs":{let r=Number(e);return this._renderMilliseconds({value:r})}case"url":{let r=String(e);return Xe.some(i=>r.startsWith(i))?this.renderTextURL(r):this._renderCode(r)}default:return this._renderUnknown(t.valueType,e)}}_getDerivedSubItemsHeading(e){return e.subItemsHeading?{key:e.subItemsHeading.key||"",valueType:e.subItemsHeading.valueType||e.valueType,granularity:e.subItemsHeading.granularity||e.granularity,displayUnit:e.subItemsHeading.displayUnit||e.displayUnit,label:""}:null}_renderTableRow(e,t){let r=this._dom.createElement("tr");for(let i of t){if(!i||!i.key){this._dom.createChildOf(r,"td","lh-table-column--empty");continue}let a=e[i.key],l;if(a!=null&&(l=this._renderTableValue(a,i)),l){let o=`lh-table-column--${i.valueType}`;this._dom.createChildOf(r,"td",o).append(l)}else this._dom.createChildOf(r,"td","lh-table-column--empty")}return r}_renderTableRowsFromItem(e,t){let r=this._dom.createFragment();if(r.append(this._renderTableRow(e,t)),!e.subItems)return r;let i=t.map(this._getDerivedSubItemsHeading);if(!i.some(Boolean))return r;for(let a of e.subItems.items){let l=this._renderTableRow(a,i);l.classList.add("lh-sub-item-row"),r.append(l)}return r}_adornEntityGroupRow(e){let t=e.dataset.entity;if(!t)return;let r=this._entities?.find(a=>a.name===t);if(!r)return;let i=this._dom.find("td",e);if(r.category){let a=this._dom.createElement("span");a.classList.add("lh-audit__adorn"),a.textContent=r.category,i.append(" ",a)}if(r.isFirstParty){let a=this._dom.createElement("span");a.classList.add("lh-audit__adorn","lh-audit__adorn1p"),a.textContent=v.strings.firstPartyChipLabel,i.append(" ",a)}if(r.homepage){let a=this._dom.createElement("a");this._dom.safelySetHref(a,r.homepage),a.href&&(a.target="_blank",a.rel="noopener",a.title=v.strings.openInANewTabTooltip,a.classList.add("lh-report-icon--external"),i.append(" ",a))}}_renderEntityGroupRow(e,t){let r={...t[0]};r.valueType="text";let i=[r,...t.slice(1)],a=this._dom.createFragment();return a.append(this._renderTableRow(e,i)),this._dom.find("tr",a).classList.add("lh-row--group"),a}_getEntityGroupItems(e){let{items:t,headings:r,sortedBy:i}=e;if(!t.length||e.isEntityGrouped||!t.some(s=>s.entity))return[];let a=new Set(e.skipSumming||[]),l=[];for(let s of r)!s.key||a.has(s.key)||et.includes(s.valueType)&&l.push(s.key);let o=r[0].key;if(!o)return[];let n=new Map;for(let s of t){let d=typeof s.entity=="string"?s.entity:void 0,h=n.get(d)||{[o]:d||v.strings.unattributable,entity:d};for(let u of l)h[u]=Number(h[u]||0)+Number(s[u]||0);n.set(d,h)}let c=[...n.values()];return i&&c.sort(E.getTableItemSortComparator(i)),c}_renderTable(e){if(!e.items.length)return this._dom.createElement("span");let t=this._dom.createElement("table","lh-table"),r=this._dom.createChildOf(t,"thead"),i=this._dom.createChildOf(r,"tr");for(let o of e.headings){let n=`lh-table-column--${o.valueType||"text"}`,c=this._dom.createElement("div","lh-text");c.textContent=o.label,this._dom.createChildOf(i,"th",n).append(c)}let a=this._getEntityGroupItems(e),l=this._dom.createChildOf(t,"tbody");if(a.length)for(let o of a){let n=typeof o.entity=="string"?o.entity:void 0,c=this._renderEntityGroupRow(o,e.headings);for(let d of e.items.filter(h=>h.entity===n))c.append(this._renderTableRowsFromItem(d,e.headings));let s=this._dom.findAll("tr",c);n&&s.length&&(s.forEach(d=>d.dataset.entity=n),this._adornEntityGroupRow(s[0])),l.append(c)}else{let o=!0;for(let n of e.items){let c=this._renderTableRowsFromItem(n,e.headings),s=this._dom.findAll("tr",c),d=s[0];if(typeof n.entity=="string"&&(d.dataset.entity=n.entity),e.isEntityGrouped&&n.entity)d.classList.add("lh-row--group"),this._adornEntityGroupRow(d);else for(let h of s)h.classList.add(o?"lh-row--even":"lh-row--odd");o=!o,l.append(c)}}return t}_renderListValue(e){return e.type==="node"?this.renderNode(e):e.type==="text"?this._renderText(e.value):this.render(e)}_renderList(e){let t=this._dom.createElement("div","lh-list");return e.items.forEach(r=>{if(r.type==="list-section"){let a=this._dom.createElement("div","lh-list-section");r.title&&this._dom.createChildOf(a,"div","lh-list-section__title").append(this._dom.convertMarkdownLinkSnippets(r.title)),r.description&&this._dom.createChildOf(a,"div","lh-list-section__description").append(this._dom.convertMarkdownLinkSnippets(r.description));let l=this._renderListValue(r.value);l&&a.append(l),t.append(a);return}let i=this._renderListValue(r);i&&t.append(i)}),t}_renderChecklist(e){let t=this._dom.createElement("ul","lh-checklist");return Object.values(e.items).forEach(r=>{let i=this._dom.createChildOf(t,"li","lh-checklist-item"),a=r.value?"lh-report-plain-icon--checklist-pass":"lh-report-plain-icon--checklist-fail";this._dom.createChildOf(i,"span",`lh-report-plain-icon ${a}`).textContent=r.label}),t}renderNode(e){let t=this._dom.createElement("span","lh-node");if(e.nodeLabel){let l=this._dom.createElement("div");l.textContent=e.nodeLabel,t.append(l)}if(e.snippet){let l=this._dom.createElement("div");l.classList.add("lh-node__snippet"),l.textContent=e.snippet,t.append(l)}if(e.selector&&(t.title=e.selector),e.path&&t.setAttribute("data-path",e.path),e.selector&&t.setAttribute("data-selector",e.selector),e.snippet&&t.setAttribute("data-snippet",e.snippet),!this._fullPageScreenshot)return t;let r=e.lhId&&this._fullPageScreenshot.nodes[e.lhId];if(!r||r.width===0||r.height===0)return t;let i={width:147,height:100},a=X.render(this._dom,this._fullPageScreenshot.screenshot,r,i);return a&&t.prepend(a),t}renderSourceLocation(e){if(!e.url)return null;let t=`${e.url}:${e.line+1}:${e.column}`,r;e.original&&(r=`${e.original.file||"<unmapped>"}:${e.original.line+1}:${e.original.column}`);let i;if(e.urlProvider==="network"&&r)i=this._createLink({url:e.url,text:r}),i.title=`maps to generated location ${t}`;else if(e.urlProvider==="network"&&!r)i=this.renderTextURL(e.url),this._dom.find(".lh-link",i).textContent+=`:${e.line+1}:${e.column}`;else if(e.urlProvider==="comment"&&r)i=this._renderText(`${r} (from source map)`),i.title=`${t} (from sourceURL)`;else if(e.urlProvider==="comment"&&!r)i=this._renderText(`${t} (from sourceURL)`);else return null;return i.classList.add("lh-source-location"),i.setAttribute("data-source-url",e.url),i.setAttribute("data-source-line",String(e.line)),i.setAttribute("data-source-column",String(e.column)),i}_renderFilmstrip(e){let t=this._dom.createElement("div","lh-filmstrip");for(let r of e.items){let i=this._dom.createChildOf(t,"div","lh-filmstrip__frame"),a=this._dom.createChildOf(i,"img","lh-filmstrip__thumbnail");this._dom.safelySetImageSrc(a,r.data),a.alt="Screenshot"}return t}_renderCode(e){let t=this._dom.createElement("pre","lh-code");return t.textContent=e,t}},rt=class{constructor(e){e==="en-XA"&&(e="de"),this._locale=e,this._cachedNumberFormatters=new Map}_formatNumberWithGranularity(e,t,r={}){if(t!==void 0){let l=-Math.log10(t);Number.isInteger(l)||(console.warn(`granularity of ${t} is invalid. Using 1 instead`),t=1),t<1&&(r={...r},r.minimumFractionDigits=r.maximumFractionDigits=Math.ceil(l)),e=Math.round(e/t)*t,Object.is(e,-0)&&(e=0)}else Math.abs(e)<5e-4&&(e=0);let i,a=[r.minimumFractionDigits,r.maximumFractionDigits,r.style,r.unit,r.unitDisplay,this._locale].join("");return i=this._cachedNumberFormatters.get(a),i||(i=new Intl.NumberFormat(this._locale,r),this._cachedNumberFormatters.set(a,i)),i.format(e).replace(" ","\xA0")}formatNumber(e,t){return this._formatNumberWithGranularity(e,t)}formatInteger(e){return this._formatNumberWithGranularity(e,1)}formatPercent(e){return new Intl.NumberFormat(this._locale,{style:"percent"}).format(e)}formatBytesToKiB(e,t=void 0){return this._formatNumberWithGranularity(e/1024,t)+"\xA0KiB"}formatBytesToMiB(e,t=void 0){return this._formatNumberWithGranularity(e/1048576,t)+"\xA0MiB"}formatBytes(e,t=1){return this._formatNumberWithGranularity(e,t,{style:"unit",unit:"byte",unitDisplay:"long"})}formatBytesWithBestUnit(e,t=.1){return e>=1048576?this.formatBytesToMiB(e,t):e>=1024?this.formatBytesToKiB(e,t):this._formatNumberWithGranularity(e,t,{style:"unit",unit:"byte",unitDisplay:"narrow"})}formatKbps(e,t=void 0){return this._formatNumberWithGranularity(e,t,{style:"unit",unit:"kilobit-per-second",unitDisplay:"short"})}formatMilliseconds(e,t=void 0){return this._formatNumberWithGranularity(e,t,{style:"unit",unit:"millisecond",unitDisplay:"short"})}formatSeconds(e,t=void 0){return this._formatNumberWithGranularity(e/1e3,t,{style:"unit",unit:"second",unitDisplay:"narrow"})}formatDateTime(e){let t={month:"short",day:"numeric",year:"numeric",hour:"numeric",minute:"numeric",timeZoneName:"short"},r;try{r=new Intl.DateTimeFormat(this._locale,t)}catch{t.timeZone="UTC",r=new Intl.DateTimeFormat(this._locale,t)}return r.format(new Date(e))}formatDuration(e){let t=e/1e3;if(Math.round(t)===0)return"None";let r=[],i={day:3600*24,hour:3600,minute:60,second:1};return Object.keys(i).forEach(a=>{let l=i[a],o=Math.floor(t/l);if(o>0){t-=o*l;let n=this._formatNumberWithGranularity(o,1,{style:"unit",unit:a,unitDisplay:"narrow"});r.push(n)}}),r.join(" ")}};function it(e){let t=e.createComponent("explodeyGauge");return e.find(".lh-exp-gauge-component",t)}function at(e,t,r){let i=e.find("div.lh-exp-gauge__wrapper",t);i.className="",i.classList.add("lh-exp-gauge__wrapper",`lh-exp-gauge__wrapper--${E.calculateRating(r.score)}`),lt(e,i,r)}function ot(e,t,r){r=r||e/32;let i=e/r,a=.5*r,l=i+a+r,o=2*Math.PI*i,n=Math.acos(1-.5*Math.pow(.5*r/i,2))*i,c=2*Math.PI*l,s=Math.acos(1-.5*Math.pow(.5*r/l,2))*l;return{radiusInner:i,radiusOuter:l,circumferenceInner:o,circumferenceOuter:c,getArcLength:()=>Math.max(0,Number(t*o)),getMetricArcLength:(d,h=!1)=>{let u=h?0:2*s;return Math.max(0,Number(d*c-a-u))},endDiffInner:n,endDiffOuter:s,strokeWidth:r,strokeGap:a}}function lt(e,t,r){let i=Number(r.score),{radiusInner:a,radiusOuter:l,circumferenceInner:o,circumferenceOuter:n,getArcLength:c,getMetricArcLength:s,endDiffInner:d,endDiffOuter:h,strokeWidth:u,strokeGap:f}=ot(128,i),m=e.find("svg.lh-exp-gauge",t);e.find(".lh-exp-gauge__label",m).textContent=r.title,m.setAttribute("viewBox",[-64,-64/2,128,128/2].join(" ")),m.style.setProperty("--stroke-width",`${u}px`),m.style.setProperty("--circle-meas",(2*Math.PI).toFixed(4));let p=e.find("g.lh-exp-gauge__outer",t),g=e.find("g.lh-exp-gauge__inner",t),b=e.find("circle.lh-cover",p),w=e.find("circle.lh-exp-gauge__arc",g),y=e.find("text.lh-exp-gauge__percentage",g);p.style.setProperty("--scale-initial",String(a/l)),p.style.setProperty("--radius",`${l}px`),b.style.setProperty("--radius",`${.5*(a+l)}px`),b.setAttribute("stroke-width",String(f)),m.style.setProperty("--radius",`${a}px`),w.setAttribute("stroke-dasharray",`${c()} ${(o-c()).toFixed(4)}`),w.setAttribute("stroke-dashoffset",String(.25*o-d)),y.textContent=Math.round(i*100).toString();let S=l+u,k=l-u,F=r.auditRefs.filter(_=>_.group==="metrics"&&_.weight),U=F.reduce((_,x)=>_+=x.weight,0),D=.25*n-h-.5*f,R=-.5*Math.PI;p.querySelectorAll(".metric").forEach(_=>{F.map(x=>`metric--${x.id}`).find(x=>_.classList.contains(x))||_.remove()}),F.forEach((_,x)=>{let A=_.acronym??_.id,I=!p.querySelector(`.metric--${A}`),L=e.maybeFind(`g.metric--${A}`,p)||e.createSVGElement("g"),q=e.maybeFind(`.metric--${A} circle.lh-exp-gauge--faded`,p)||e.createSVGElement("circle"),V=e.maybeFind(`.metric--${A} circle.lh-exp-gauge--miniarc`,p)||e.createSVGElement("circle"),P=e.maybeFind(`.metric--${A} circle.lh-exp-gauge-hovertarget`,p)||e.createSVGElement("circle"),M=e.maybeFind(`.metric--${A} text.metric__label`,p)||e.createSVGElement("text"),z=e.maybeFind(`.metric--${A} text.metric__value`,p)||e.createSVGElement("text");L.classList.add("metric",`metric--${A}`),q.classList.add("lh-exp-gauge__arc","lh-exp-gauge__arc--metric","lh-exp-gauge--faded"),V.classList.add("lh-exp-gauge__arc","lh-exp-gauge__arc--metric","lh-exp-gauge--miniarc"),P.classList.add("lh-exp-gauge__arc","lh-exp-gauge__arc--metric","lh-exp-gauge-hovertarget");let B=_.weight/U,re=s(B),ie=_.result.score?_.result.score*B:0,ae=s(ie),me=B*n,oe=s(B,!0),le=E.calculateRating(_.result.score,_.result.scoreDisplayMode);L.style.setProperty("--metric-rating",le),L.style.setProperty("--metric-color",`var(--color-${le})`),L.style.setProperty("--metric-offset",`${D}`),L.style.setProperty("--i",x.toString()),q.setAttribute("stroke-dasharray",`${re} ${n-re}`),V.style.setProperty("--metric-array",`${ae} ${n-ae}`),P.setAttribute("stroke-dasharray",`${oe} ${n-oe-h}`),M.classList.add("metric__label"),z.classList.add("metric__value"),M.textContent=A,z.textContent=`+${Math.round(ie*100)}`;let ne=R+B*Math.PI,j=Math.cos(ne),W=Math.sin(ne);switch(!0){case j>0:z.setAttribute("text-anchor","end");break;case j<0:M.setAttribute("text-anchor","end");break;case j===0:M.setAttribute("text-anchor","middle"),z.setAttribute("text-anchor","middle");break}switch(!0){case W>0:M.setAttribute("dominant-baseline","hanging");break;case W<0:z.setAttribute("dominant-baseline","hanging");break;case W===0:M.setAttribute("dominant-baseline","middle"),z.setAttribute("dominant-baseline","middle");break}M.setAttribute("x",(S*j).toFixed(2)),M.setAttribute("y",(S*W).toFixed(2)),z.setAttribute("x",(k*j).toFixed(2)),z.setAttribute("y",(k*W).toFixed(2)),I&&(L.appendChild(q),L.appendChild(V),L.appendChild(P),L.appendChild(M),L.appendChild(z),p.appendChild(L)),D-=me,R+=B*2*Math.PI});let T=p.querySelector(".lh-exp-gauge-underhovertarget")||e.createSVGElement("circle");T.classList.add("lh-exp-gauge__arc","lh-exp-gauge__arc--metric","lh-exp-gauge-hovertarget","lh-exp-gauge-underhovertarget");let N=s(1,!0);if(T.setAttribute("stroke-dasharray",`${N} ${n-N-h}`),T.isConnected||p.prepend(T),m.dataset.listenersSetup)return;m.dataset.listenersSetup=!0,O(m),m.addEventListener("pointerover",_=>{if(_.target===m&&m.classList.contains("state--expanded")){m.classList.remove("state--expanded"),m.classList.contains("state--highlight")&&(m.classList.remove("state--highlight"),e.find(".metric--highlight",m).classList.remove("metric--highlight"));return}if(!(_.target instanceof Element))return;let x=_.target.parentNode;if(x instanceof SVGElement){if(x&&x===g){m.classList.contains("state--expanded")?m.classList.contains("state--highlight")&&(m.classList.remove("state--highlight"),e.find(".metric--highlight",m).classList.remove("metric--highlight")):m.classList.add("state--expanded");return}if(x&&x.classList&&x.classList.contains("metric")){let A=x.style.getPropertyValue("--metric-rating");if(t.style.setProperty("--color-highlight",`var(--color-${A}-secondary)`),!m.classList.contains("state--highlight"))m.classList.add("state--highlight"),x.classList.add("metric--highlight");else{let I=e.find(".metric--highlight",m);x!==I&&(I.classList.remove("metric--highlight"),x.classList.add("metric--highlight"))}}}}),m.addEventListener("mouseleave",()=>{m.classList.remove("state--highlight"),m.querySelector(".metric--highlight")?.classList.remove("metric--highlight")});async function O(_){if(await new Promise(P=>setTimeout(P,1e3)),_.classList.contains("state--expanded"))return;let x=e.find(".lh-exp-gauge__inner",_),A=Array.from(x.querySelectorAll("circle")).map(P=>{let M=`uniq-${Math.random()}`;P.setAttribute("id",M);let z=e.createSVGElement("use");return z.setAttribute("href",`#${M}`),_.appendChild(z),z}),I=2.5;_.style.setProperty("--peek-dur",`${I}s`),_.classList.add("state--peek","state--expanded");let L=()=>{_.classList.remove("state--peek","state--expanded"),A.forEach(P=>P.remove())},q=setTimeout(()=>{_.removeEventListener("mouseenter",V),L()},I*1e3*1.5);function V(){clearTimeout(q),L()}_.addEventListener("mouseenter",V,{once:!0})}}var nt=class extends pe{_renderMetric(e){let t=this.dom.createComponent("metric"),r=this.dom.find(".lh-metric",t);r.id=e.result.id;let i=E.calculateRating(e.result.score,e.result.scoreDisplayMode);r.classList.add(`lh-metric--${i}`);let a=this.dom.find(".lh-metric__title",t);a.textContent=e.result.title;let l=this.dom.find(".lh-metric__value",t);l.textContent=e.result.displayValue||"";let o=this.dom.find(".lh-metric__description",t);if(o.append(this.dom.convertMarkdownLinkSnippets(e.result.description)),e.result.scoreDisplayMode==="error"){o.textContent="",l.textContent="Error!";let n=this.dom.createChildOf(o,"span");n.textContent=e.result.errorMessage||"Report error: no metric information"}else e.result.scoreDisplayMode==="notApplicable"&&(l.textContent="--");return r}_getScoringCalculatorHref(e){let t=e.filter(s=>s.group==="metrics"),r=e.find(s=>s.id==="interactive"),i=e.find(s=>s.id==="first-cpu-idle"),a=e.find(s=>s.id==="first-meaningful-paint");r&&t.push(r),i&&t.push(i),a&&typeof a.result.score=="number"&&t.push(a);let l=s=>Math.round(s*100)/100,o=[...t.map(s=>{let d;return typeof s.result.numericValue=="number"?(d=s.id==="cumulative-layout-shift"?l(s.result.numericValue):Math.round(s.result.numericValue),d=d.toString()):d="null",[s.acronym||s.id,d]})];v.reportJson&&(o.push(["device",v.reportJson.configSettings.formFactor]),o.push(["version",v.reportJson.lighthouseVersion]));let n=new URLSearchParams(o),c=new URL("https://googlechrome.github.io/lighthouse/scorecalc/");return c.hash=n.toString(),c.href}overallImpact(e,t){if(!e.result.metricSavings)return{overallImpact:0,overallLinearImpact:0};let r=0,i=0;for(let[a,l]of Object.entries(e.result.metricSavings)){if(l===void 0)continue;let o=t.find(h=>h.acronym===a);if(!o||o.result.score===null)continue;let n=o.result.numericValue;if(!n)continue;let c=l/n*o.weight;i+=c;let s=o.result.scoringOptions;if(!s)continue;let d=(C.computeLogNormalScore(s,n-l)-o.result.score)*o.weight;r+=d}return{overallImpact:r,overallLinearImpact:i}}render(e,t,r){let i=v.strings,a=this.dom.createElement("div","lh-category");a.id=e.id,a.append(this.renderCategoryHeader(e,t,r));let l=e.auditRefs.filter(s=>s.group==="metrics");if(l.length){let[s,d]=this.renderAuditGroup(t.metrics),h=this.dom.createElement("input","lh-metrics-toggle__input"),u=`lh-metrics-toggle${v.getUniqueSuffix()}`;h.setAttribute("aria-label","Toggle the display of metric descriptions"),h.type="checkbox",h.id=u,s.prepend(h);let f=this.dom.find(".lh-audit-group__header",s),m=this.dom.createChildOf(f,"label","lh-metrics-toggle__label");m.htmlFor=u;let p=this.dom.createChildOf(m,"span","lh-metrics-toggle__labeltext--show"),g=this.dom.createChildOf(m,"span","lh-metrics-toggle__labeltext--hide");p.textContent=v.strings.expandView,g.textContent=v.strings.collapseView;let b=this.dom.createElement("div","lh-metrics-container");if(s.insertBefore(b,d),l.forEach(w=>{b.append(this._renderMetric(w))}),a.querySelector(".lh-gauge__wrapper")){let w=this.dom.find(".lh-category-header__description",a),y=this.dom.createChildOf(w,"div","lh-metrics__disclaimer"),S=this.dom.convertMarkdownLinkSnippets(i.varianceDisclaimer);y.append(S);let k=this.dom.createChildOf(y,"a","lh-calclink");k.target="_blank",k.rel="noopener",k.textContent=i.calculatorLink,this.dom.safelySetHref(k,this._getScoringCalculatorHref(e.auditRefs))}s.classList.add("lh-audit-group--metrics"),a.append(s)}let o=this.dom.createChildOf(a,"div","lh-filmstrip-container"),n=e.auditRefs.find(s=>s.id==="screenshot-thumbnails")?.result;if(n?.details){o.id=n.id;let s=this.detailsRenderer.render(n.details);s&&o.append(s)}let c=this.renderFilterableSection(e,t,["insights","diagnostics"],l);if(c&&(c.classList.add("lh-perf-audits"),a.append(c)),(!r||r?.gatherMode==="navigation")&&e.score!==null){let s=it(this.dom);at(this.dom,s,e),this.dom.find(".lh-score__gauge",a).replaceWith(s)}return a}renderFilterableSection(e,t,r,i){if(r=r.filter(p=>!!t[p]),!r.length)return null;let a=this.dom.createElement("div"),l=p=>p.group??"",o=e.auditRefs.filter(p=>r.includes(l(p))).map(p=>{let{overallImpact:g,overallLinearImpact:b}=this.overallImpact(p,i),w=p.result.guidanceLevel||1,y=this.renderAudit(p);return{auditRef:p,auditEl:y,overallImpact:g,overallLinearImpact:b,guidanceLevel:w}}),n=o.filter(p=>!E.showAsPassed(p.auditRef.result)),c=o.filter(p=>E.showAsPassed(p.auditRef.result)),s={};for(let p of r){let g=this.renderAuditGroup(t[p]);g[0].classList.add(`lh-audit-group--${p}`),s[p]=g}function d(p){for(let g of o)if(p==="All")g.auditEl.hidden=!1;else{let b=g.auditRef.result.metricSavings?.[p]===void 0;g.auditEl.hidden=b}n.sort((g,b)=>{let w=g.auditRef.result.score||0,y=b.auditRef.result.score||0;if(w!==y)return w-y;if(p!=="All"){let S=g.auditRef.result.metricSavings?.[p]??-1,k=b.auditRef.result.metricSavings?.[p]??-1;if(S!==k)return k-S}return g.overallImpact!==b.overallImpact?b.overallImpact*b.guidanceLevel-g.overallImpact*g.guidanceLevel:g.overallImpact===0&&b.overallImpact===0&&g.overallLinearImpact!==b.overallLinearImpact?b.overallLinearImpact*b.guidanceLevel-g.overallLinearImpact*g.guidanceLevel:b.guidanceLevel-g.guidanceLevel});for(let g of n){if(!g.auditRef.group)continue;let b=s[l(g.auditRef)];if(!b)continue;let[w,y]=b;w.insertBefore(g.auditEl,y)}}let h=new Set;for(let p of n){let g=p.auditRef.result.metricSavings||{};for(let[b,w]of Object.entries(g))typeof w=="number"&&h.add(b)}let u=i.filter(p=>p.acronym&&h.has(p.acronym));u.length&&this.renderMetricAuditFilter(u,a,d),d("All");for(let p of r)if(n.some(g=>l(g.auditRef)===p)){let g=s[p];if(!g)continue;a.append(g[0])}if(!c.length)return a;let f={auditRefsOrEls:c.map(p=>p.auditEl),groupDefinitions:t},m=this.renderClump("passed",f);return a.append(m),a}renderMetricAuditFilter(e,t,r){let i=this.dom.createElement("div","lh-metricfilter"),a=this.dom.createChildOf(i,"span","lh-metricfilter__text");a.textContent=v.strings.showRelevantAudits;let l=[{acronym:"All",id:"All"},...e],o=v.getUniqueSuffix();for(let n of l){let c=`metric-${n.acronym}-${o}`,s=this.dom.createChildOf(i,"input","lh-metricfilter__radio");s.type="radio",s.name=`metricsfilter-${o}`,s.id=c;let d=this.dom.createChildOf(i,"label","lh-metricfilter__label");d.htmlFor=c,d.title="result"in n?n.result.title:"",d.textContent=n.acronym||n.id,n.acronym==="All"&&(s.checked=!0,d.classList.add("lh-metricfilter__label--active")),t.append(i),s.addEventListener("input",h=>{for(let f of t.querySelectorAll("label.lh-metricfilter__label"))f.classList.toggle("lh-metricfilter__label--active",f.htmlFor===c);t.classList.toggle("lh-category--filtered",n.acronym!=="All"),r(n.acronym||"All");let u=t.querySelectorAll("div.lh-audit-group, details.lh-audit-group");for(let f of u){f.hidden=!1;let m=Array.from(f.querySelectorAll("div.lh-audit")),p=!!m.length&&m.every(g=>g.hidden);f.hidden=p}})}}},st=class{constructor(e){this._dom=e,this._opts={}}renderReport(e,t,r){if(!this._dom.rootEl&&t){console.warn("Please adopt the new report API in renderer/api.js.");let a=t.closest(".lh-root");a?this._dom.rootEl=a:(t.classList.add("lh-root","lh-vars"),this._dom.rootEl=t)}else this._dom.rootEl&&t&&(this._dom.rootEl=t);r&&(this._opts=r),this._dom.setLighthouseChannel(e.configSettings.channel||"unknown");let i=E.prepareReportResult(e);return this._dom.rootEl.textContent="",this._dom.rootEl.append(this._renderReport(i)),this._opts.occupyEntireViewport&&this._dom.rootEl.classList.add("lh-max-viewport"),this._dom.rootEl}_renderReportTopbar(e){let t=this._dom.createComponent("topbar"),r=this._dom.find("a.lh-topbar__url",t);return r.textContent=e.finalDisplayedUrl,r.title=e.finalDisplayedUrl,this._dom.safelySetHref(r,e.finalDisplayedUrl),t}_renderReportHeader(){let e=this._dom.createComponent("heading"),t=this._dom.createComponent("scoresWrapper");return this._dom.find(".lh-scores-wrapper-placeholder",e).replaceWith(t),e}_renderReportFooter(e){let t=this._dom.createComponent("footer");return this._renderMetaBlock(e,t),this._dom.find(".lh-footer__version_issue",t).textContent=v.strings.footerIssue,this._dom.find(".lh-footer__version",t).textContent=e.lighthouseVersion,t}_renderMetaBlock(e,t){let r=E.getEmulationDescriptions(e.configSettings||{}),i=e.userAgent.match(/(\w*Chrome\/[\d.]+)/),a=Array.isArray(i)?i[1].replace("/"," ").replace("Chrome","Chromium"):"Chromium",l=e.configSettings.channel,o=e.environment.benchmarkIndex.toFixed(0),n=e.environment.credits?.["axe-core"],c=e.environment.credits?.ard,s=[`${v.strings.runtimeSettingsBenchmark}: ${o}`,`${v.strings.runtimeSettingsCPUThrottling}: ${r.cpuThrottling}`];r.screenEmulation&&s.push(`${v.strings.runtimeSettingsScreenEmulation}: ${r.screenEmulation}`),n&&s.push(`${v.strings.runtimeSettingsAxeVersion}: ${n}`),c&&s.push(`${v.strings.runtimeSettingsArdVersion}: ${c}`);let d=v.strings.runtimeAnalysisWindow;e.gatherMode==="timespan"?d=v.strings.runtimeAnalysisWindowTimespan:e.gatherMode==="snapshot"&&(d=v.strings.runtimeAnalysisWindowSnapshot);let h=[["date",`Captured at ${v.i18n.formatDateTime(e.fetchTime)}`],["devices",`${r.deviceEmulation} with Lighthouse ${e.lighthouseVersion}`,s.join(`
`)],["samples-one",v.strings.runtimeSingleLoad,v.strings.runtimeSingleLoadTooltip],["stopwatch",d],["networkspeed",`${r.summary}`,`${v.strings.runtimeSettingsNetworkThrottling}: ${r.networkThrottling}`],["chrome",`Using ${a}`+(l?` with ${l}`:""),`${v.strings.runtimeSettingsUANetwork}: "${e.environment.networkUserAgent}"`]],u=Object.keys(e.categories).filter(m=>E.isPluginCategory(m));for(let m of u){let p=e.environment.credits?.[m];h.push(["plugin",p?`${m} ${p}`:m,void 0,`https://www.npmjs.com/package/${m}`])}let f=this._dom.find(".lh-meta__items",t);for(let[m,p,g,b]of h){let w=this._dom.createChildOf(f,"li","lh-meta__item");if(b){let y=this._dom.createChildOf(w,"a");y.rel="noopener",y.target="_blank",y.textContent=p,this._dom.safelySetHref(y,b)}else w.textContent=p;if(g){w.classList.add("lh-tooltip-boundary");let y=this._dom.createChildOf(w,"div","lh-tooltip");y.textContent=g}w.classList.add("lh-report-icon",`lh-report-icon--${m}`)}}_renderReportWarnings(e){if(!e.runWarnings||e.runWarnings.length===0)return this._dom.createElement("div");let t=this._dom.createComponent("warningsToplevel"),r=this._dom.find(".lh-warnings__msg",t);r.textContent=v.strings.toplevelWarningsMessage;let i=[];for(let a of e.runWarnings){let l=this._dom.createElement("li");l.append(this._dom.convertMarkdownLinkSnippets(a)),i.push(l)}return this._dom.find("ul",t).append(...i),t}_renderScoreGauges(e,t,r){let i=[],a=[];for(let l of Object.values(e.categories)){let o=(r[l.id]||t).renderCategoryScore(l,e.categoryGroups||{},{gatherMode:e.gatherMode}),n=this._dom.find("a.lh-gauge__wrapper, a.lh-fraction__wrapper",o);n&&(this._dom.safelySetHref(n,`#${l.id}`),n.addEventListener("click",c=>{if(!n.matches('[href^="#"]'))return;let s=n.getAttribute("href"),d=this._dom.rootEl;if(!s||!d)return;let h=this._dom.find(s,d);c.preventDefault(),h.scrollIntoView()}),this._opts.onPageAnchorRendered?.(n)),E.isPluginCategory(l.id)?a.push(o):i.push(o)}return[...i,...a]}_renderReport(e){v.apply({providedStrings:e.i18n.rendererFormattedStrings,i18n:new rt(e.configSettings.locale),reportJson:e});let t=new tt(this._dom,{fullPageScreenshot:e.fullPageScreenshot??void 0,entities:e.entities}),r=new pe(this._dom,t),i={performance:new nt(this._dom,t)},a=this._dom.createElement("div");a.append(this._renderReportHeader());let l=this._dom.createElement("div","lh-container"),o=this._dom.createElement("div","lh-report");o.append(this._renderReportWarnings(e));let n;Object.keys(e.categories).length===1?a.classList.add("lh-header--solo-category"):n=this._dom.createElement("div","lh-scores-header");let c=this._dom.createElement("div");if(c.classList.add("lh-scorescale-wrap"),c.append(this._dom.createComponent("scorescale")),n){let u=this._dom.find(".lh-scores-container",a);n.append(...this._renderScoreGauges(e,r,i)),u.append(n,c);let f=this._dom.createElement("div","lh-sticky-header");f.append(...this._renderScoreGauges(e,r,i)),l.append(f)}let s=this._dom.createElement("div","lh-categories");o.append(s);let d={gatherMode:e.gatherMode};for(let u of Object.values(e.categories)){let f=i[u.id]||r;f.dom.createChildOf(s,"div","lh-category-wrapper").append(f.render(u,e.categoryGroups,d))}r.injectFinalScreenshot(s,e.audits,c);let h=this._dom.createFragment();return this._opts.omitGlobalStyles||h.append(this._dom.createComponent("styles")),this._opts.omitTopbar||h.append(this._renderReportTopbar(e)),h.append(l),o.append(this._renderReportFooter(e)),l.append(a,o),e.fullPageScreenshot&&X.installFullPageScreenshot(this._dom.rootEl,e.fullPageScreenshot.screenshot),h}};function Y(e,t){let r=e.rootEl;typeof t>"u"?r.classList.toggle("lh-dark"):r.classList.toggle("lh-dark",t)}var ct=typeof btoa<"u"?btoa:e=>Buffer.from(e).toString("base64"),dt=typeof atob<"u"?atob:e=>Buffer.from(e,"base64").toString();async function ht(e,t){let r=new TextEncoder().encode(e);if(t.gzip)if(typeof CompressionStream<"u"){let l=new CompressionStream("gzip"),o=l.writable.getWriter();o.write(r),o.close();let n=await new Response(l.readable).arrayBuffer();r=new Uint8Array(n)}else r=window.pako.gzip(e);let i="",a=5e3;for(let l=0;l<r.length;l+=a)i+=String.fromCharCode(...r.subarray(l,l+a));return ct(i)}function pt(e,t){let r=dt(e),i=Uint8Array.from(r,a=>a.charCodeAt(0));return t.gzip?window.pako.ungzip(i,{toText:!0}):new TextDecoder().decode(i)}var gt={toBase64:ht,fromBase64:pt};function ee(){let e=window.location.host.endsWith(".vercel.app"),t=new URLSearchParams(window.location.search).has("dev");return e?`https://${window.location.host}/gh-pages`:t?"http://localhost:7333":"https://googlechrome.github.io/lighthouse"}function te(e){let t=e.generatedTime,r=e.fetchTime||t;return`${e.lighthouseVersion}-${e.finalDisplayedUrl}-${r}`}function ut(e,t,r){let i=new URL(t).origin;window.addEventListener("message",function l(o){o.origin===i&&a&&o.data.opened&&(a.postMessage(e,i),window.removeEventListener("message",l))});let a=window.open(t,r)}async function ue(e,t,r){let i=new URL(t),a=!!window.CompressionStream;i.hash=await gt.toBase64(JSON.stringify(e),{gzip:a}),a&&i.searchParams.set("gzip","1"),window.open(i.toString(),r)}async function mt(e){let t="viewer-"+te(e),r=ee()+"/viewer/";await ue({lhr:e},r,t)}async function ft(e){let t="viewer-"+te(e),r=ee()+"/viewer/";ut({lhr:e},r,t)}function vt(e){if(!e.audits["script-treemap-data"].details)throw new Error("no script treemap data found");let t={lhr:{mainDocumentUrl:e.mainDocumentUrl,finalUrl:e.finalUrl,finalDisplayedUrl:e.finalDisplayedUrl,audits:{"script-treemap-data":e.audits["script-treemap-data"]},configSettings:{locale:e.configSettings.locale}}},r=ee()+"/treemap/",i="treemap-"+te(e);ue(t,r,i)}var bt=class{constructor(e){this._dom=e,this._toggleEl,this._menuEl,this.onDocumentKeyDown=this.onDocumentKeyDown.bind(this),this.onToggleClick=this.onToggleClick.bind(this),this.onToggleKeydown=this.onToggleKeydown.bind(this),this.onMenuFocusOut=this.onMenuFocusOut.bind(this),this.onMenuKeydown=this.onMenuKeydown.bind(this),this._getNextMenuItem=this._getNextMenuItem.bind(this),this._getNextSelectableNode=this._getNextSelectableNode.bind(this),this._getPreviousMenuItem=this._getPreviousMenuItem.bind(this)}setup(e){this._toggleEl=this._dom.find(".lh-topbar button.lh-tools__button",this._dom.rootEl),this._toggleEl.addEventListener("click",this.onToggleClick),this._toggleEl.addEventListener("keydown",this.onToggleKeydown),this._menuEl=this._dom.find(".lh-topbar div.lh-tools__dropdown",this._dom.rootEl),this._menuEl.addEventListener("keydown",this.onMenuKeydown),this._menuEl.addEventListener("click",e)}close(){this._toggleEl.classList.remove("lh-active"),this._toggleEl.setAttribute("aria-expanded","false"),this._menuEl.contains(this._dom.document().activeElement)&&this._toggleEl.focus(),this._menuEl.removeEventListener("focusout",this.onMenuFocusOut),this._dom.document().removeEventListener("keydown",this.onDocumentKeyDown)}open(e){this._toggleEl.classList.contains("lh-active")?e.focus():this._menuEl.addEventListener("transitionend",()=>{e.focus()},{once:!0}),this._toggleEl.classList.add("lh-active"),this._toggleEl.setAttribute("aria-expanded","true"),this._menuEl.addEventListener("focusout",this.onMenuFocusOut),this._dom.document().addEventListener("keydown",this.onDocumentKeyDown)}onToggleClick(e){e.preventDefault(),e.stopImmediatePropagation(),this._toggleEl.classList.contains("lh-active")?this.close():this.open(this._getNextMenuItem())}onToggleKeydown(e){switch(e.code){case"ArrowUp":e.preventDefault(),this.open(this._getPreviousMenuItem());break;case"ArrowDown":case"Enter":case" ":e.preventDefault(),this.open(this._getNextMenuItem());break;default:}}onMenuKeydown(e){let t=e.target;switch(e.code){case"ArrowUp":e.preventDefault(),this._getPreviousMenuItem(t).focus();break;case"ArrowDown":e.preventDefault(),this._getNextMenuItem(t).focus();break;case"Home":e.preventDefault(),this._getNextMenuItem().focus();break;case"End":e.preventDefault(),this._getPreviousMenuItem().focus();break;default:}}onDocumentKeyDown(e){e.keyCode===27&&this.close()}onMenuFocusOut(e){let t=e.relatedTarget;this._menuEl.contains(t)||this.close()}_getNextSelectableNode(e,t){let r=e.filter(a=>a instanceof HTMLElement).filter(a=>!(a.hasAttribute("disabled")||window.getComputedStyle(a).display==="none")),i=t?r.indexOf(t)+1:0;return i>=r.length&&(i=0),r[i]}_getNextMenuItem(e){let t=Array.from(this._menuEl.childNodes);return this._getNextSelectableNode(t,e)}_getPreviousMenuItem(e){let t=Array.from(this._menuEl.childNodes).reverse();return this._getNextSelectableNode(t,e)}},_t=class{constructor(e,t){this.lhr,this._reportUIFeatures=e,this._dom=t,this._dropDownMenu=new bt(this._dom),this._copyAttempt=!1,this.topbarEl,this.categoriesEl,this.stickyHeaderEl,this.highlightEl,this.onDropDownMenuClick=this.onDropDownMenuClick.bind(this),this.onKeyUp=this.onKeyUp.bind(this),this.onCopy=this.onCopy.bind(this),this.collapseAllDetails=this.collapseAllDetails.bind(this)}enable(e){this.lhr=e,this._dom.rootEl.addEventListener("keyup",this.onKeyUp),this._dom.document().addEventListener("copy",this.onCopy),this._dropDownMenu.setup(this.onDropDownMenuClick),this._setUpCollapseDetailsAfterPrinting(),this._dom.find(".lh-topbar__logo",this._dom.rootEl).addEventListener("click",()=>Y(this._dom)),this._setupStickyHeader()}onDropDownMenuClick(e){e.preventDefault();let t=e.target;if(!(!t||!t.hasAttribute("data-action"))){switch(t.getAttribute("data-action")){case"copy":this.onCopyButtonClick();break;case"print-summary":this.collapseAllDetails(),this._print();break;case"print-expanded":this.expandAllDetails(),this._print();break;case"save-json":{let r=JSON.stringify(this.lhr,null,2);this._reportUIFeatures._saveFile(new Blob([r],{type:"application/json"}));break}case"save-html":{let r=this._reportUIFeatures.getReportHtml();try{this._reportUIFeatures._saveFile(new Blob([r],{type:"text/html"}))}catch(i){this._dom.fireEventOn("lh-log",this._dom.document(),{cmd:"error",msg:"Could not export as HTML. "+i.message})}break}case"open-viewer":{this._dom.isDevTools()?mt(this.lhr):ft(this.lhr);break}case"save-gist":{this._reportUIFeatures.saveAsGist();break}case"toggle-dark":{Y(this._dom);break}case"view-unthrottled-trace":this._reportUIFeatures._opts.onViewTrace?.()}this._dropDownMenu.close()}}onCopy(e){this._copyAttempt&&e.clipboardData&&(e.preventDefault(),e.clipboardData.setData("text/plain",JSON.stringify(this.lhr,null,2)),this._dom.fireEventOn("lh-log",this._dom.document(),{cmd:"log",msg:"Report JSON copied to clipboard"})),this._copyAttempt=!1}onCopyButtonClick(){this._dom.fireEventOn("lh-analytics",this._dom.document(),{name:"copy"});try{this._dom.document().queryCommandSupported("copy")&&(this._copyAttempt=!0,this._dom.document().execCommand("copy")||(this._copyAttempt=!1,this._dom.fireEventOn("lh-log",this._dom.document(),{cmd:"warn",msg:"Your browser does not support copy to clipboard."})))}catch(e){this._copyAttempt=!1,this._dom.fireEventOn("lh-log",this._dom.document(),{cmd:"log",msg:e.message})}}onKeyUp(e){(e.ctrlKey||e.metaKey)&&e.keyCode===80&&this._dropDownMenu.close()}expandAllDetails(){this._dom.findAll(".lh-categories details",this._dom.rootEl).map(e=>e.open=!0)}collapseAllDetails(){this._dom.findAll(".lh-categories details",this._dom.rootEl).map(e=>e.open=!1)}_print(){this._reportUIFeatures._opts.onPrintOverride?this._reportUIFeatures._opts.onPrintOverride(this._dom.rootEl):self.print()}resetUIState(){this._dropDownMenu.close()}_getScrollParent(e){let{overflowY:t}=window.getComputedStyle(e);return t!=="visible"&&t!=="hidden"?e:e.parentElement?this._getScrollParent(e.parentElement):document}_setUpCollapseDetailsAfterPrinting(){"onbeforeprint"in self?self.addEventListener("afterprint",this.collapseAllDetails):self.matchMedia("print").addListener(e=>{e.matches?this.expandAllDetails():this.collapseAllDetails()})}_setupStickyHeader(){this.topbarEl=this._dom.find("div.lh-topbar",this._dom.rootEl),this.categoriesEl=this._dom.find("div.lh-categories",this._dom.rootEl),requestAnimationFrame(()=>requestAnimationFrame(()=>{try{this.stickyHeaderEl=this._dom.find("div.lh-sticky-header",this._dom.rootEl)}catch{return}this.highlightEl=this._dom.createChildOf(this.stickyHeaderEl,"div","lh-highlighter");let e=this._getScrollParent(this._dom.find(".lh-container",this._dom.rootEl));e.addEventListener("scroll",()=>this._updateStickyHeader());let t=e instanceof window.Document?document.documentElement:e;new window.ResizeObserver(()=>this._updateStickyHeader()).observe(t)}))}_updateStickyHeader(){if(!this.stickyHeaderEl)return;let e=this.topbarEl.getBoundingClientRect().bottom,t=this.categoriesEl.getBoundingClientRect().top,r=e>=t,i=Array.from(this._dom.rootEl.querySelectorAll(".lh-category")).filter(s=>s.getBoundingClientRect().top-window.innerHeight/2<0),a=i.length>0?i.length-1:0,l=this.stickyHeaderEl.querySelectorAll(".lh-gauge__wrapper, .lh-fraction__wrapper"),o=l[a],n=l[0].getBoundingClientRect().left,c=o.getBoundingClientRect().left-n;this.highlightEl.style.transform=`translate(${c}px)`,this.stickyHeaderEl.classList.toggle("lh-sticky-header--visible",r)}};function wt(e,t){let r=t?new Date(t):new Date,i=r.toLocaleTimeString("en-US",{hour12:!1}),a=r.toLocaleDateString("en-US",{year:"numeric",month:"2-digit",day:"2-digit"}).split("/");a.unshift(a.pop());let l=a.join("-");return`${e.slice(0,200)}_${l}_${i}`.replace(/[/?<>\\:*|"]/g,"-")}function yt(e){let{hostname:t,pathname:r}=new URL(e.finalDisplayedUrl),i=t+r.replace(/\/$/,"");return wt(i,e.fetchTime)}function xt(e){return Array.from(e.tBodies[0].rows)}var kt=class{constructor(e,t={}){this.json,this._dom=e,this._opts=t,this._topbar=t.omitTopbar?null:new _t(this,e),this.onMediaQueryChange=this.onMediaQueryChange.bind(this)}initFeatures(e){this.json=e,this._fullPageScreenshot=C.getFullPageScreenshot(e),this._topbar&&(this._topbar.enable(e),this._topbar.resetUIState()),this._setupMediaQueryListeners(),this._setupThirdPartyFilter(),this._setupElementScreenshotOverlay(this._dom.rootEl);let t=this._dom.isDevTools()||this._opts.disableDarkMode||this._opts.disableAutoDarkModeAndFireworks;!t&&window.matchMedia("(prefers-color-scheme: dark)").matches&&Y(this._dom,!0);let r=["performance","accessibility","best-practices","seo"].every(a=>{let l=e.categories[a];return l&&l.score===1}),i=this._opts.disableFireworks||this._opts.disableAutoDarkModeAndFireworks;if(r&&!i&&(this._enableFireworks(),t||Y(this._dom,!0)),e.categories.performance&&e.categories.performance.auditRefs.some(a=>!!(a.group==="metrics"&&e.audits[a.id].errorMessage))){let a=this._dom.find("input.lh-metrics-toggle__input",this._dom.rootEl);a.checked=!0}this.json.audits["script-treemap-data"]&&this.json.audits["script-treemap-data"].details&&this.addButton({text:v.strings.viewTreemapLabel,icon:"treemap",onClick:()=>vt(this.json)}),this._opts.onViewTrace&&(e.configSettings.throttlingMethod==="simulate"?this._dom.find('a[data-action="view-unthrottled-trace"]',this._dom.rootEl).classList.remove("lh-hidden"):this.addButton({text:v.strings.viewTraceLabel,onClick:()=>this._opts.onViewTrace?.()})),this._opts.getStandaloneReportHTML&&this._dom.find('a[data-action="save-html"]',this._dom.rootEl).classList.remove("lh-hidden");for(let a of this._dom.findAll("[data-i18n]",this._dom.rootEl)){let l=a.getAttribute("data-i18n");a.textContent=v.strings[l]}}addButton(e){let t=this._dom.rootEl.querySelector(".lh-audit-group--metrics");if(!t)return;let r=t.querySelector(".lh-buttons");r||(r=this._dom.createChildOf(t,"div","lh-buttons"));let i=["lh-button"];e.icon&&(i.push("lh-report-icon"),i.push(`lh-report-icon--${e.icon}`));let a=this._dom.createChildOf(r,"button",i.join(" "));return a.textContent=e.text,a.addEventListener("click",e.onClick),a}resetUIState(){this._topbar&&this._topbar.resetUIState()}getReportHtml(){if(!this._opts.getStandaloneReportHTML)throw new Error("`getStandaloneReportHTML` is not set");return this.resetUIState(),this._opts.getStandaloneReportHTML()}saveAsGist(){throw new Error("Cannot save as gist from base report")}_enableFireworks(){this._dom.find(".lh-scores-container",this._dom.rootEl).classList.add("lh-score100")}_setupMediaQueryListeners(){let e=self.matchMedia("(max-width: 500px)");e.addListener(this.onMediaQueryChange),this.onMediaQueryChange(e)}_resetUIState(){this._topbar&&this._topbar.resetUIState()}onMediaQueryChange(e){this._dom.rootEl.classList.toggle("lh-narrow",e.matches)}_setupThirdPartyFilter(){let e=["uses-rel-preconnect","third-party-facades","network-dependency-tree-insight"],t=["legacy-javascript","legacy-javascript-insight"];Array.from(this._dom.rootEl.querySelectorAll("table.lh-table")).filter(r=>r.querySelector("td.lh-table-column--url, td.lh-table-column--source-location")).filter(r=>{let i=r.closest(".lh-audit");if(!i)throw new Error(".lh-table not within audit");return!e.includes(i.id)}).forEach(r=>{let i=xt(r),a=i.filter(f=>!f.classList.contains("lh-sub-item-row")),l=this._getThirdPartyRows(a,C.getFinalDisplayedUrl(this.json)),o=i.some(f=>f.classList.contains("lh-row--even")),n=this._dom.createComponent("3pFilter"),c=this._dom.find("input",n);c.addEventListener("change",f=>{let m=f.target instanceof HTMLInputElement&&!f.target.checked,p=!0,g=a[0];for(;g;){let b=m&&l.includes(g);do g.classList.toggle("lh-row--hidden",b),o&&(g.classList.toggle("lh-row--even",!b&&p),g.classList.toggle("lh-row--odd",!b&&!p)),g=g.nextElementSibling;while(g&&g.classList.contains("lh-sub-item-row"));b||(p=!p)}});let s=l.filter(f=>!f.classList.contains("lh-row--group")).length;this._dom.find(".lh-3p-filter-count",n).textContent=`${s}`,this._dom.find(".lh-3p-ui-string",n).textContent=v.strings.thirdPartyResourcesLabel;let d=l.length===a.length,h=!l.length;if((d||h)&&(this._dom.find("div.lh-3p-filter",n).hidden=!0),!r.parentNode)return;r.parentNode.insertBefore(n,r);let u=r.closest(".lh-audit");if(!u)throw new Error(".lh-table not within audit");t.includes(u.id)&&!d&&c.click()})}_setupElementScreenshotOverlay(e){this._fullPageScreenshot&&X.installOverlayFeature({dom:this._dom,rootEl:e,overlayContainerEl:e,fullPageScreenshot:this._fullPageScreenshot})}_getThirdPartyRows(e,t){let r=C.getEntityFromUrl(t,this.json.entities),i=this.json.entities?.find(l=>l.isFirstParty===!0)?.name,a=[];for(let l of e){if(i){if(!l.dataset.entity||l.dataset.entity===i)continue}else{let o=l.querySelector("div.lh-text__url");if(!o)continue;let n=o.dataset.url;if(!n||C.getEntityFromUrl(n,this.json.entities)===r)continue}a.push(l)}return a}_saveFile(e){let t=e.type.match("json")?".json":".html",r=yt({finalDisplayedUrl:C.getFinalDisplayedUrl(this.json),fetchTime:this.json.fetchTime})+t;this._opts.onSaveFileOverride?this._opts.onSaveFileOverride(e,r):this._dom.saveFile(e,r)}};function Ct(e,t={}){let r=document.createElement("article");r.classList.add("lh-root","lh-vars");let i=new Ke(r.ownerDocument,r);return new st(i).renderReport(e,r,t),new kt(i,t).initFeatures(e),r}function St(e,t){return{lhr:e,missingIcuMessageIds:[]}}function Et(e,t){}function Lt(e){return!1}var At={registerLocaleData:Et,hasLocale:Lt};export{Ke as DOM,st as ReportRenderer,kt as ReportUIFeatures,At as format,Ct as renderReport,St as swapLocale};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license Copyright 2023 The Lighthouse Authors. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * Dummy text for ensuring report robustness: <\/script> pre$`post %%LIGHTHOUSE_JSON%%
 * (this is handled by terser)
 */
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
//# sourceMappingURL=report.js.map
